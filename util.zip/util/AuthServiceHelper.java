package com.renaissance.app.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.renaissance.app.kafka.EmailProducer;
import com.renaissance.app.kafka.TemplateEmailEvent;
import com.renaissance.app.model.User;
import com.renaissance.app.model.enums.OtpType;
import com.renaissance.app.model.enums.TokenType;
import com.renaissance.app.service.IOtpService;
import com.renaissance.app.util.constants.AppConstants;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class AuthServiceHelper {

	private final JwtUtils jwtUtils;
	private final IOtpService otpService;
//	private final EmailSenderService emailService;
	private final EmailProducer emailProducer;
	

	/**
	 * Determine if an AuthToken is required based on OTP type.
	 */
	public boolean isAuthTokenRequired(OtpType otpType) {
		return resolveTokenType(otpType) == TokenType.AUTH_TOKEN;
	}

	/**
	 * Resolve the token type based on OTP type.
	 */
	public TokenType resolveTokenType(OtpType otpType) {
		return otpType == OtpType.FORGET_PASSWORD ? TokenType.AUTH_TOKEN : TokenType.ACCESS_TOKEN;
	}

	/**
	 * Generate access and refresh tokens.
	 */
	public Map<String, Object> generateAccessAndRefreshTokens(String email, String role, OtpType otpType) {
		String accessToken = jwtUtils.generateToken(email, role, resolveTokenType(otpType), otpType, true);
		String refreshToken = jwtUtils.generateRefreshToken(email, role);

		Map<String, Object> tokens = new HashMap<>();
		tokens.put(AppConstants.ACCESS_TOKEN, accessToken);
		tokens.put(AppConstants.REFRESH_TOKEN, refreshToken);
		return tokens;
	}

	public Map<String, Object> generateAuthTokenWithOtp(User user, OtpType otpType, boolean isOtpVerified) {
		String token = jwtUtils.generateToken(user.getEmail(), user.getRole().getRole(), TokenType.AUTH_TOKEN, otpType,
				isOtpVerified);
		String otp = otpService.generateOtp(user.getEmail(), otpType);	
		
//		emailService.sendEmail(user.getEmail(),user.getUsername(), otp, EmailType.OTP);
		Map<String, String> variables = Map.of(
	            "username", user.getUsername(),
	            "otp", otp,
	            "universityName", "Renaissance University"
	    );

		emailProducer.publishTemplateEmail(
    	        new TemplateEmailEvent(
    	        		"OTP_REQUEST",
    		            user.getEmail(),
    		            variables, 
    		            false,
    		            false,null,false
    	        )
    	);
		
		return Map.of(AppConstants.AUTH_TOKEN, token, AppConstants.OTP, otp);
	}
	
	public String generateAccessToken(User user) {
		return jwtUtils.generateToken(user.getEmail(), user.getRole().getRole(), TokenType.ACCESS_TOKEN, OtpType.LOGIN,
				true);
	}

}

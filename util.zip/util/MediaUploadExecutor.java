package com.renaissance.app.util;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class MediaUploadExecutor {

    private final ExecutorService executor =
            Executors.newFixedThreadPool(6); // bounded, intentional

    private final ServiceHelper serviceHelper;

    public MediaUploadExecutor(ServiceHelper serviceHelper) {
        this.serviceHelper = serviceHelper;
    }

    public CompletableFuture<String> uploadAsync(MultipartFile file, String folder) {
        if (file == null || file.isEmpty()) {
            return CompletableFuture.completedFuture(null);
        }

        return CompletableFuture.supplyAsync(
                () -> serviceHelper.uploadMandatoryMedia(file, folder),
                executor
        );
    }
}

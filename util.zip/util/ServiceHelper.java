package com.renaissance.app.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.dto.request.FeatureUpdateRequest;
import com.renaissance.app.dto.request.PromoSectionRequest;
import com.renaissance.app.dto.request.PromoSectionUpdateRequest;
import com.renaissance.app.dto.request.SeoConfigRequest;
import com.renaissance.app.dto.request.UniqueSellingPointRequest;
import com.renaissance.app.dto.request.UniqueSellingPointUpdateRequest;
import com.renaissance.app.exception.BadRequestException;
import com.renaissance.app.model.Blog;
import com.renaissance.app.model.Category;
import com.renaissance.app.model.Course;
import com.renaissance.app.model.Event;
import com.renaissance.app.model.Feature;
import com.renaissance.app.model.News;
import com.renaissance.app.model.PressRelease;
import com.renaissance.app.model.PromoSection;
import com.renaissance.app.model.SchoolProgram;
import com.renaissance.app.model.SeoConfig;
import com.renaissance.app.model.StoryAndPictures;
import com.renaissance.app.model.UniqueSellingPoint;
import com.renaissance.app.model.enums.CategoryType;
import com.renaissance.app.repository.CategoryRepository;
import com.renaissance.app.util.constants.S3FolderConstants;

import io.jsonwebtoken.lang.Collections;
import lombok.RequiredArgsConstructor;


@Component
@RequiredArgsConstructor
public class ServiceHelper {

    private final MediaUtil mediaUtil;
    private final CategoryRepository categoryRepository;

    private static final String DEFAULT_CATEGORY_NAME = "Uncategorized";

    /**
     * Returns the default "Uncategorized" category for the given type,
     * creating and persisting it if it doesn't already exist.
     */
    public Category getOrCreateDefaultCategory(CategoryType type) {
        return categoryRepository
                .findByNameIgnoreCaseAndTypeAndIsDeletedFalse(DEFAULT_CATEGORY_NAME, type)
                .orElseGet(() -> categoryRepository.save(
                        Category.builder()
                                .name(DEFAULT_CATEGORY_NAME)
                                .type(type)
                                .build()
                ));
    }
    
    // -------------------- Media Upload --------------------
    public String uploadSingleMedia(MultipartFile file, String folderPath) {
        return (file == null || file.isEmpty()) ? null : mediaUtil.processAndUploadMedia(file, folderPath);
    }

    public List<String> uploadMultipleMedia(List<MultipartFile> files, String folderPath) {
        return files.stream()
                .map(f -> f == null ? null : mediaUtil.processAndUploadMedia(f, folderPath))
                .filter(url -> url != null)
                .toList();
    }

        // -------------------- PromoSection --------------------
        public PromoSection buildPromoSection(PromoSectionRequest request, String folderPath) {
            return PromoSection.builder()
                    .title(request.getTitle())
                    .description(request.getDescription())
                    .mediaUrl(uploadMandatoryMedia(request.getMediaFile(), folderPath))
                    .mediaAltText(request.getMediaAltText()) // Retained new alt text field
                    .build();
        }

        public PromoSection buildPromoSectionForUpdate(
                PromoSectionUpdateRequest request,
                PromoSection existing,
                String folderPath
        ) {
            String title = request.getTitle() != null ? request.getTitle() : existing.getTitle();
            String description = request.getDescription() != null ? request.getDescription() : existing.getDescription();

            String mediaUrl = existing.getMediaUrl();
            if (Boolean.TRUE.equals(request.getRemoveExistingMedia())) {
                mediaUrl = null;
            }
            if (request.getMediaFile() != null) {
                mediaUrl = uploadMandatoryMedia(request.getMediaFile(), folderPath);
            }

            // handle alt text
            String mediaAltText = request.getMediaAltText() != null
                    ? request.getMediaAltText()
                    : existing.getMediaAltText();

            return PromoSection.builder()
                    .title(title)
                    .description(description)
                    .mediaUrl(mediaUrl)
                    .mediaAltText(mediaAltText)
                    .build();
        }

        // -------------------- UniqueSellingPoint --------------------
        public UniqueSellingPoint buildUniqueSellingPoint(UniqueSellingPointRequest request) {
            List<Feature> features = request.getFeatures().stream()
                    .limit(8)
                    .map(f -> Feature.builder()
                    		.mediaUrl(uploadMandatoryMedia(f.getMediaFile(), S3FolderConstants.FEATURE_ICONS))
                    		.mediaAltText(f.getMediaAltText())
                    		.title(f.getTitle())
                    		.description(f.getDescription())
                            .build())
                    .collect(Collectors.toList());

            return UniqueSellingPoint.builder()
                    .title(request.getTitle())
                    .description(request.getDescription())
                    .features(features)
                    .build();
        }

        public UniqueSellingPoint buildUniqueSellingPointForUpdate(
                UniqueSellingPointUpdateRequest req,
                UniqueSellingPoint existing
        ) {
            if (req == null) {
                return existing;
            }

            UniqueSellingPoint usp =
                    existing != null ? existing : new UniqueSellingPoint();

            // ---------- SCALAR FIELDS ----------
            if (req.getTitle() != null) {
                usp.setTitle(req.getTitle());
            }

            if (req.getDescription() != null) {
                usp.setDescription(req.getDescription());
            }

            // ---------- FEATURES (ID-BASED HARD REPLACE) ----------
            if (req.getFeatures() != null) {

                Map<String, Feature> existingMap =
                        existing != null
                                ? existing.getFeatures().stream()
                                    .collect(Collectors.toMap(
                                            Feature::getFeatureId,
                                            Function.identity()
                                    ))
                                : Collections.emptyMap();

                Set<String> seenIds = new HashSet<>();
                List<Feature> newFeatures = new ArrayList<>();

                for (FeatureUpdateRequest featureReq : req.getFeatures()) {

                    Feature feature;

                    // ---------- EXISTING FEATURE ----------
                    if (featureReq.getFeatureId() != null) {

                        if (!seenIds.add(featureReq.getFeatureId())) {
                            throw new BadRequestException(
                                    "Duplicate USP feature ID: " + featureReq.getFeatureId()
                            );
                        }

                        feature = existingMap.get(featureReq.getFeatureId());
                        if (feature == null) {
                            throw new BadRequestException(
                                    "Invalid USP feature ID: " + featureReq.getFeatureId()
                            );
                        }
                    }
                    // ---------- NEW FEATURE ----------
                    else {
                        feature = new Feature();
                    }

                    // ---------- UPDATE FIELDS ----------
                    if (featureReq.getTitle() != null) {
                        feature.setTitle(featureReq.getTitle());
                    }

                    if (featureReq.getDescription() != null) {
                        feature.setDescription(featureReq.getDescription());
                    }

                    if (featureReq.getMediaAltText() != null) {
                        feature.setMediaAltText(featureReq.getMediaAltText());
                    }

                    if (featureReq.getMediaFile() != null && !featureReq.getMediaFile().isEmpty()) {
                        feature.setMediaUrl(
                                uploadMandatoryMedia(
                                        featureReq.getMediaFile(),
                                        S3FolderConstants.FEATURE_ICONS
                                )
                        );
                    }

                    newFeatures.add(feature);
                }

                // ---------- HARD REPLACE ----------
                usp.getFeatures().clear();
                usp.getFeatures().addAll(newFeatures);
                // Hibernate sets usp_id automatically
                // orphanRemoval = true deletes removed features
            }

            return usp;
        }


        public String uploadMandatoryMedia(MultipartFile file, String folderPath) {
            if (file == null || file.isEmpty()) {
                throw new BadRequestException(
                        String.format("File is required, Please provide a valid file.")
                );
            }

            return mediaUtil.processAndUploadMedia(file, folderPath);
        }
        
        /**
         * Creates or updates the SEO config for any supported entity type.
         *
         * @param existing Existing SeoConfig instance (may be null)
         * @param seoRequest DTO carrying metaTitle, metaKeywords, and metaDescription
         * @param ownerEntity The parent entity (SchoolProgram, Course, StoryAndPictures)
         * @return Updated or newly created SeoConfig
         */
        public SeoConfig buildOrUpdateSeoConfig(
                SeoConfig existing,
                SeoConfigRequest seoRequest,
                Object ownerEntity) {

            if (seoRequest == null) return existing; // nothing to do

            boolean hasValues =
                    (seoRequest.getMetaTitle() != null && !seoRequest.getMetaTitle().isBlank()) ||
                    (seoRequest.getMetaKeywords() != null && !seoRequest.getMetaKeywords().isBlank()) ||
                    (seoRequest.getMetaDescription() != null && !seoRequest.getMetaDescription().isBlank());

            if (!hasValues) return existing; // skip if all null or blank

            if (existing == null) {
                existing = new SeoConfig();
            }

            // 🔹 Partial updates
            if (seoRequest.getMetaTitle() != null && !seoRequest.getMetaTitle().isBlank()) {
                existing.setMetaTitle(seoRequest.getMetaTitle());
            }
            if (seoRequest.getMetaKeywords() != null && !seoRequest.getMetaKeywords().isBlank()) {
                existing.setMetaKeywords(seoRequest.getMetaKeywords());
            }
            if (seoRequest.getMetaDescription() != null && !seoRequest.getMetaDescription().isBlank()) {
                existing.setMetaDescription(seoRequest.getMetaDescription());
            }

            // 🔹 Set parent reference based on type
            if (ownerEntity instanceof SchoolProgram program) {
                existing.setSchoolProgram(program);
            } else if (ownerEntity instanceof Course course) {
                existing.setCourse(course);
            } else if (ownerEntity instanceof StoryAndPictures story) {
                existing.setStory(story);
            } else if (ownerEntity instanceof News news) {
            	existing.setNews(news);
            } else if (ownerEntity instanceof Blog blog) {
        	existing.setBlog(blog);
         	}else if (ownerEntity instanceof Event event) {
            	existing.setEvent(event);
         	}else if (ownerEntity instanceof PressRelease release) {
            	existing.setPressRelease(release);
         	}else {
                throw new IllegalArgumentException("Unsupported SEO owner type: " + ownerEntity.getClass().getSimpleName());
            }

            return existing;
        }
}
package com.renaissance.app.util;

import java.util.Map;

public final class CoursePriorityRegistry {

    private CoursePriorityRegistry() {}

    private static final Map<String, Integer> PRIORITY_MAP = Map.of(
        "BBA Advance", 1,
        "MBA + PGP in Business Analytics", 2,
        "B.Tech Computer Science Engineering (CSE)", 3,
        "B.Sc Agriculture (Hons.)", 4,
        "BA in Mass Communication", 5,
        "B.Design (International Exposure)", 6,
        "BA in Psychology", 7,
        "B.sc Forensic Science", 8,
        "M.Sc Food Technology", 9
    );

    public static Integer basePriority(String courseName) {
        return PRIORITY_MAP.get(courseName);
    }
}

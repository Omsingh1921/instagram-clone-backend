package com.renaissance.app.util;

import java.util.Map;

public final class SchoolProgramPriorityRegistry {

    private SchoolProgramPriorityRegistry() {}

    private static final Map<String, Integer> PRIORITY_MAP =
            Map.ofEntries(
                Map.entry("School of Management", 1),
                Map.entry("School of Commerce", 2),
                Map.entry("School of Engineering", 3),
                Map.entry("School of Law", 4),
                Map.entry("School of Social Science", 5),
                Map.entry("School of Agriculture", 6),
                Map.entry("School of Fashion", 7),
                Map.entry("School of Nursing & Paramedical Science", 8),
                Map.entry("School of Science", 9),
                Map.entry("School of Journalism", 10),
                Map.entry("School of Library Science", 11),
                Map.entry("School of Music", 12),
                Map.entry("School of Vocational Studies", 13)
            );

    public static Integer basePriority(String programName) {
        return PRIORITY_MAP.get(programName);
    }
}

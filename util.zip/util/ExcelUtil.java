package com.renaissance.app.util;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.exception.BadRequestException;

public final class ExcelUtil {

    private ExcelUtil() {}
    
    public static Sheet getSheet(MultipartFile file, String sheetName) {
        try (InputStream is = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(is)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new BadRequestException("Sheet not found: " + sheetName);
            }
            return sheet;

        } catch (Exception e) {
            throw new BadRequestException("Failed to read Excel file");
        }
    }


    // -------------------- SAFE CELL READ --------------------

    public static String get(Row row, int index) {
        if (row == null) return null;

        Cell cell = row.getCell(index);
        if (cell == null) return null;

        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();

            case NUMERIC -> {
                double val = cell.getNumericCellValue();
                // avoid "10.0" for whole numbers
                if (val == Math.floor(val)) {
                    yield String.valueOf((long) val);
                }
                yield String.valueOf(val);
            }

            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());

            case FORMULA -> cell.getCellFormula();

            case BLANK, _NONE -> null;

            default -> null;
        };
    }

    // -------------------- BLOCK SPLITTING --------------------
    
    public static List<List<Row>> splitIntoSchoolBlocks(Sheet sheet) {

        List<List<Row>> blocks = new ArrayList<>();
        List<Row> current = null;

        for (Row row : sheet) {

            if (row.getRowNum() < 1) continue; // skip header

            String schoolName   = get(row, 0);
            String featureTitle = get(row, 9);
            String featureDesc  = get(row, 10);

            // New school
            if (schoolName != null && !schoolName.isBlank()) {
                current = new ArrayList<>();
                current.add(row);
                blocks.add(current);
                continue;
            }

            // Feature row
            if (current != null &&
                ((featureTitle != null && !featureTitle.isBlank()) ||
                 (featureDesc  != null && !featureDesc.isBlank()))) {

                current.add(row);
                continue;
            }

            current = null;
        }

        return blocks;
    }

    public static List<List<Row>> splitIntoCourseBlocks(Sheet sheet) {

        List<List<Row>> blocks = new ArrayList<>();
        List<Row> current = null;

        for (Row row : sheet) {

            if (row.getRowNum() < 1) continue; // skip header

            String courseName = get(row, 0);          // ✅ Course Name
            String featureTitle = get(row, 16);       // Feature Title
            String featureDesc  = get(row, 17);

            // 1️⃣ New course block
            if (courseName != null && !courseName.isBlank()) {
                current = new ArrayList<>();
                current.add(row);
                blocks.add(current);
                continue;
            }

            // 2️⃣ Continuation rows (features / eligibility / FO)
            if (current != null &&
                ((featureTitle != null && !featureTitle.isBlank()) ||
                 (featureDesc  != null && !featureDesc.isBlank()))) {

                current.add(row);
                continue;
            }

            // 3️⃣ Empty spacer row
            current = null;
        }

        return blocks;
    }


}

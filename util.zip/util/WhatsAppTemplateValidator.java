package com.renaissance.app.util;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.renaissance.app.model.WhatsAppTemplate;
import com.renaissance.app.repository.WhatsAppTemplateRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class WhatsAppTemplateValidator {

    private final WhatsAppTemplateRepository templateRepo;
    private final ObjectMapper mapper = new ObjectMapper();

    /**
     * Validates and orders parameters based on DB template metadata.
     */
    public Map<String, String> validateAndOrderParams(String templateName, Map<String, String> inputParams) {

        WhatsAppTemplate template = templateRepo.findByTemplateName(templateName)
                .orElseThrow(() -> new IllegalArgumentException("Invalid template: " + templateName));

        List<String> paramOrder;
        try {
            paramOrder = mapper.readValue(template.getParamOrderJson(), new TypeReference<List<String>>() {});
        } catch (Exception ex) {
            throw new RuntimeException("Invalid paramOrderJson in DB for template: " + templateName);
        }

        if (paramOrder.size() != template.getParamCount()) {
            throw new IllegalStateException("DB paramCount does not match paramOrderJson for template: " + templateName);
        }

        // Format: LinkedHashMap to maintain order
        Map<String, String> orderedParams = new LinkedHashMap<>();

        for (String key : paramOrder) {
            if (!inputParams.containsKey(key)) {
                throw new IllegalArgumentException("Missing required param: " + key + " for template: " + templateName);
            }
            orderedParams.put(key, inputParams.get(key));
        }

        return orderedParams;
    }

    public WhatsAppTemplate getTemplate(String templateName) {
        return templateRepo.findByTemplateName(templateName)
                .orElseThrow(() -> new IllegalArgumentException("Invalid template: " + templateName));
    }
}

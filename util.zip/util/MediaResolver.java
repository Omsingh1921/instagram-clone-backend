package com.renaissance.app.util;

import java.io.File;

import org.springframework.stereotype.Component;

import com.renaissance.app.service.batch.GoogleDriveDownloader;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Component
@RequiredArgsConstructor
@Slf4j
public class MediaResolver {

    private final MediaUtil mediaUtil;
    private final GoogleDriveDownloader driveDownloader;
    
    public String resolve(String input, String folder) {

        if (input == null || input.isBlank()) {
            return null;
        }

        // Already hosted media (S3, CDN, Cloudinary, etc.)
        if (isHostedUrl(input)) {
            return input;
        }

        // Google Drive links must be downloaded and re-uploaded
        if (isGoogleDriveUrl(input)) {
            File temp = driveDownloader.download(input);
            try {
                return mediaUtil.processAndUploadMedia(temp, folder);
            } finally {
                if (temp != null && temp.exists()) {
                    temp.delete();
                }
            }
        }

        return null;
    }

    private boolean isHostedUrl(String url) {
        return url.startsWith("http")
                && !url.contains("drive.google.com");
    }

    private boolean isGoogleDriveUrl(String url) {
        return url.contains("drive.google.com");
    }


}

package com.renaissance.app.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.renaissance.app.kafka.EmailProducer;
import com.renaissance.app.kafka.TemplateEmailEvent;
import com.renaissance.app.model.Course;
import com.renaissance.app.model.Fee;
import com.renaissance.app.model.StudentRegistration;
import com.renaissance.app.model.enums.StudentType;
import com.renaissance.app.repository.StudentRegistrationRepository;
import com.renaissance.app.service.IFeeService;
import com.renaissance.app.service.impl.WhatsAppService;
import com.renaissance.app.util.constants.OraiConstants;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class WhatsappMessageSender {
	
	private final WhatsAppService whatsAppService;  
//	private final EmailSenderService emailService;  
	private final IFeeService feeService;
	private final EmailProducer emailProducer;
	private final StudentRegistrationRepository registrationRepository;
	
	 /**
     * Sends WhatsApp & Email confirmation messages after a successful payment.
     * Used by both frontend verification and webhook auto-payments.
     */
	
	public void sendConfirmationMessages(StudentRegistration reg) {

	    double registrationFee = resolveRegistrationAmount(reg);
	    String registrationFeeStr = String.valueOf((int) registrationFee);

	    StudentType studentType = resolveStudentType(reg.getCountry());
	    Double fee = getCourseFeeByStudentType(reg.getCourse(), studentType);

	    String phone = reg.getWhatsappNumber();

	    // =========================================================
	    // 1. REGISTRATION CONFIRMATION — ALWAYS FIRST
	    // =========================================================
	    try {

	        Map<String, String> regParams = Map.of(
	                "name", reg.getFullName(),
	                "userId", reg.getSourceUniqueId(),
	                "fullName", reg.getFullName(),
	                "email", reg.getEmail(),

	                "courseSession",
	                reg.getSchoolProgram() != null
	                        ? reg.getSchoolProgram().getName()
	                        : "",

	                "courseCategory",
	                (reg.getCourse() != null
	                        && reg.getCourse().getSchoolProgram() != null)
	                        ? reg.getCourse().getSchoolProgram().getName()
	                        : "-",

	                "course",
	                reg.getCourse() != null
	                        ? reg.getCourse().getName()
	                        : "-",

	                "courseFees",
	                fee != null ? String.valueOf(fee.intValue()) : "0",

	                "registrationFees", registrationFeeStr,
	                "feeStructure", reg.getCourse().getCourseFeeStructureUrl()
	        );

	        whatsAppService.sendTemplate(
	                phone,
	                OraiConstants.TEMPLATE_APPLY_NOW,
	                regParams
	        );

	    } catch (Exception ex) {
	        log.error(
	                "Failed sending WhatsApp registration confirmation for {}: {}",
	                reg.getSourceUniqueId(),
	                ex.getMessage(),
	                ex
	        );
	    }

	    // =========================================================
	    // 2. CONDITIONAL OFFER — SEND ONLY ONCE EVER
	    // =========================================================s

	    boolean conditionalSent = false;
	    if (reg.getConditionalOfferSent()==null || !reg.getConditionalOfferSent()) {

	        // ---------- WHATSAPP CONDITIONAL ----------
	        try {
	            whatsAppService.sendTemplate(
	                    reg.getContactNumber(),
	                    OraiConstants.TEMPLATE_RU_CONDITIONAL,
	                    Map.of("name", reg.getFullName())
	            );
	            conditionalSent = true;

	        } catch (Exception ex) {
	            log.error(
	                    "Failed sending conditional admission WhatsApp to {}: {}",
	                    reg.getContactNumber(),
	                    ex.getMessage(),
	                    ex
	            );
	        }

	        // ---------- EMAIL CONDITIONAL ----------
	        try {
	            Course course = reg.getCourse();

	            Map<String, String> offerVars = new HashMap<>();
	            offerVars.put(OraiConstants.PARAM_STUDENT_NAME, reg.getFullName());
	            offerVars.put(OraiConstants.PARAM_COURSE_NAME, course.getName());
	            offerVars.put(OraiConstants.PARAM_COURSE_DURATION,
	                    course.getDuration().getYears() + " Years");
	            offerVars.put(OraiConstants.PARAM_SESSION_YEAR,
	                    course.getCourseStartDate());
	            offerVars.put(OraiConstants.PARAM_FEE_STRUCTURE_ALT,
	                    course.getCourseFeeStructureUrl());

	            emailProducer.publishTemplateEmail(
	                    new TemplateEmailEvent(
	                            "CONDITIONAL_OFFER",
	                            reg.getEmail(),
	                            offerVars,
	                            true,
	                            false,
	                            null,false
	                    )
	            );

	            conditionalSent = true;

	        } catch (Exception ex) {
	            log.error(
	                    "Failed sending conditional offer email to {}: {}",
	                    reg.getEmail(),
	                    ex.getMessage(),
	                    ex
	            );
	        }

	        // ---------- UPDATE DB FLAG ----------
	        if (conditionalSent) {
	            reg.setConditionalOfferSent(true);
	            registrationRepository.save(reg);
	        }
	    }

	    // =========================================================
	    // 3. REGISTRATION CONFIRMATION EMAIL (ALWAYS)
	    // =========================================================
	    try {
	        Course course = reg.getCourse();
	        Map<String, String> fees =
	                feeService.getCourseAndPerDayFee(course.getCourseId());

	        String totalFee = fees.get("totalFee");

            Map<String, String> emailVars = new HashMap<>();
            emailVars.put(OraiConstants.PARAM_STUDENT_NAME, reg.getFullName());
            emailVars.put(OraiConstants.PARAM_USER_ID_ALT, reg.getSourceUniqueId());
            emailVars.put(OraiConstants.PARAM_FULL_NAME_ALT, reg.getFullName());
            emailVars.put(OraiConstants.PARAM_DATE_OF_BIRTH, String.valueOf(reg.getDob()));
            emailVars.put(OraiConstants.PARAM_GENDER, reg.getGender());
            emailVars.put(OraiConstants.PARAM_CONTACT_NUMBER, reg.getContactNumber());
            emailVars.put(OraiConstants.PARAM_CONTACT_WHATSAPP, reg.getWhatsappNumber());
            emailVars.put(OraiConstants.PARAM_EMAIL_ALT, reg.getEmail());
            emailVars.put(OraiConstants.PARAM_CASTE, reg.getCategoryCaste());
            emailVars.put(OraiConstants.PARAM_MOTHER_NAME, reg.getMotherName());
            emailVars.put(OraiConstants.PARAM_FATHER_NAME, reg.getFatherName());
            emailVars.put(OraiConstants.PARAM_PARENT_CONTACT_NUMBER, reg.getParentsContactNumber());
            emailVars.put(OraiConstants.PARAM_PERMANENT_COUNTRY, reg.getCountry());
            emailVars.put(OraiConstants.PARAM_PERMANENT_STATE, reg.getState());
            emailVars.put(OraiConstants.PARAM_PERMANENT_CITY, reg.getPermanentCity());
            emailVars.put(OraiConstants.PARAM_CITY, reg.getCity());
            emailVars.put(OraiConstants.PARAM_PERMANENT_ADDRESS,
                    reg.getState() + ", " +
                    reg.getCountry() + " - " +
                    reg.getPincode());
            emailVars.put(OraiConstants.PARAM_PINCODE, reg.getPincode());
            emailVars.put(OraiConstants.PARAM_LAST_EDUCATION, reg.getRecentEducation());
            emailVars.put(OraiConstants.PARAM_LAST_EDUCATION_STATUS, reg.getEduStatus());
            emailVars.put(OraiConstants.PARAM_EDUCATION_BOARD, reg.getBoard());
            emailVars.put(OraiConstants.PARAM_SCHOOL_COLLEGE_NAME, reg.getSchoolOrCollegeName());
            emailVars.put(OraiConstants.PARAM_COURSE_SESSION_ALT, course.getCourseStartDate());
            emailVars.put(OraiConstants.PARAM_COURSE_CATEGORY_ALT, cleanString(course.getSchoolProgram().getName()));
            emailVars.put(OraiConstants.PARAM_COURSE_ALT, course.getName());
            emailVars.put(OraiConstants.PARAM_REGISTRATION_FEES_ALT, registrationFeeStr);
            emailVars.put(OraiConstants.PARAM_COURSE_FEES_ALT, totalFee +" "+ "per year");

            emailVars.put(OraiConstants.PARAM_REGISTRATION_PAYMENT, reg.getPayment().getPaymentStatus().name());
            emailVars.put(OraiConstants.PARAM_REFERRED_BY_NAME, reg.getCounselledBy());
            emailVars.put(OraiConstants.PARAM_CREATED_DATE, reg.getCreatedDate().toLocalDate().toString());

	        emailProducer.publishTemplateEmail(
	                new TemplateEmailEvent(
	                        "REGISTRATION_CONFIRMATION",
	                        reg.getEmail(),
	                        emailVars,
	                        true,
	                        false,
	                        null,false
	                )
	        );

	    } catch (Exception ex) {
	        log.error("Failed sending registration email: {}", ex.getMessage());
	    }
	}

	
    private Double getCourseFeeByStudentType(Course course, StudentType studentType) {

        if (course == null || course.getFees() == null) {
            return null;
        }

        // 1️⃣ Exact student type match
        Optional<Double> fee = course.getFees().stream()
                .filter(f -> f.getStudentType() == studentType)
                .map(Fee::getTotalFee)
                .findFirst();

        if (fee.isPresent()) {
            return fee.get();
        }

        // 2️⃣ Fallback → INDIAN
        return course.getFees().stream()
                .filter(f -> f.getStudentType() == StudentType.INDIAN)
                .map(Fee::getTotalFee)
                .findFirst()
                .orElse(null); // 3️⃣ Nothing found → null
    }


	private StudentType resolveStudentType(String country) {
	    if (country == null) {
	        return StudentType.INDIAN;
	    }
	    return "india".equalsIgnoreCase(country.trim())
	            ? StudentType.INDIAN
	            : StudentType.INTERNATIONAL;
	}
	
	
	 private String cleanString(String input) {
	        if (input == null) return null;

	        return input
	                .replaceAll("[\\u200B-\\u200D\\uFEFF\\u2060]", "") // remove invisible chars
	                .trim();
	    }
	
private double resolveRegistrationAmount(StudentRegistration reg) {
		return reg.getCourse().getRegistrationFee();
	}
}
package com.renaissance.app.util;


public final class SlugUtil {

    private SlugUtil() {}

    public static String slugify(String input) {
        return input.toLowerCase()
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("(^-|-$)", "");
    }
}

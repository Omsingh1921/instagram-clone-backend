package com.renaissance.app.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.renaissance.app.dto.request.WhatsAppMessageRequest;
import com.renaissance.app.util.constants.OraiConstants;

public final class WhatsAppPayloadBuilder {

    private WhatsAppPayloadBuilder() {}

    public static Map<String, Object> build(WhatsAppMessageRequest req) {

        Map<String, Object> body = new LinkedHashMap<>();
        body.put(OraiConstants.KEY_MESSAGING_PRODUCT, OraiConstants.VAL_WHATSAPP);
        body.put(OraiConstants.KEY_TYPE, OraiConstants.TYPE_TEMPLATE);
        body.put(OraiConstants.KEY_TO, req.getTo());

        Map<String, Object> template = new LinkedHashMap<>();
        template.put(OraiConstants.KEY_NAMESPACE, req.getNamespace());
        template.put(OraiConstants.KEY_NAME, req.getTemplateName());
//        template.put(OraiConstants.KEY_LANGUAGE, Map.of(
//                OraiConstants.KEY_POLICY, OraiConstants.VAL_POLICY_DETERMINISTIC,
//                OraiConstants.KEY_CODE, OraiConstants.LANGUAGE_CODE
//        )
        String language =
                OraiConstants.TEMPLATE_LANGUAGE
                        .getOrDefault(req.getTemplateName(), "en");

        template.put(OraiConstants.KEY_LANGUAGE, Map.of(
                OraiConstants.KEY_POLICY, OraiConstants.VAL_POLICY_DETERMINISTIC,
                OraiConstants.KEY_CODE, language
        )    
    );

        List<Object> components = new ArrayList<>();

        addHeader(components, req);
        addBodyParameters(components, req);
        addButton(components, req);

        template.put(OraiConstants.KEY_COMPONENTS, components);
        body.put(OraiConstants.KEY_TEMPLATE, template);

        return body;
    }

    private static void addHeader(List<Object> components, WhatsAppMessageRequest req) {
        if (req.getMediaUrl() == null) return;

        Map<String, Object> header = new LinkedHashMap<>();
        header.put(OraiConstants.KEY_TYPE, OraiConstants.COMPONENT_HEADER);

        Map<String, Object> media = new LinkedHashMap<>();

        if (req.getFileName() != null) {
            media.put(OraiConstants.KEY_TYPE, OraiConstants.MEDIA_DOCUMENT);
            media.put(OraiConstants.MEDIA_DOCUMENT, Map.of(
                    OraiConstants.KEY_LINK, req.getMediaUrl(),
                    OraiConstants.KEY_FILENAME, req.getFileName()
            ));
        } else {
            media.put(OraiConstants.KEY_TYPE, OraiConstants.MEDIA_IMAGE);
            media.put(OraiConstants.MEDIA_IMAGE, Map.of(
                    OraiConstants.KEY_LINK, req.getMediaUrl()
            ));
        }

        header.put(OraiConstants.KEY_PARAMETERS, List.of(media));
        components.add(header);
    }

    private static void addBodyParameters(List<Object> components, WhatsAppMessageRequest req) {
        if (req.getParams() == null || req.getParams().isEmpty()) return;

        Map<String, Object> body = new LinkedHashMap<>();
        body.put(OraiConstants.KEY_TYPE, OraiConstants.COMPONENT_BODY);

        List<Object> paramsList = new ArrayList<>();

        req.getParams().forEach((k, v) -> {
            paramsList.add(Map.of(
                    "type", "text",
                    "text", v
            ));
        });

        body.put(OraiConstants.KEY_PARAMETERS, paramsList);
        components.add(body);
    }

    private static void addButton(List<Object> components, WhatsAppMessageRequest req) {
        if (req.getButton() == null) return;

        Map<String, Object> button = new LinkedHashMap<>();

        button.put(OraiConstants.KEY_TYPE, OraiConstants.COMPONENT_BUTTON);
        button.put(OraiConstants.KEY_SUB_TYPE, OraiConstants.SUB_TYPE_URL);
        button.put(OraiConstants.KEY_INDEX, req.getButton().getIndex());

        button.put(OraiConstants.KEY_PARAMETERS, List.of(
                Map.of(
                        OraiConstants.KEY_TYPE, OraiConstants.KEY_TEXT,
                        OraiConstants.KEY_TEXT, req.getButton().getUrl()
                )
        ));

        components.add(button);
    }
}
package com.renaissance.app.util;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.renaissance.app.dto.response.ProgramFacultyGroupResponse;
import com.renaissance.app.dto.response.SchoolProgramBasicResponse;
import com.renaissance.app.model.Faculty;
import com.renaissance.app.model.SchoolProgram;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ProgramPriorityUtil {

    /**
     * Builds SchoolProgramBasicResponse list in strict priority order
     * filtered by programs present in the given faculties.
     */
    public static List<SchoolProgramBasicResponse> buildSchoolProgramsInPriorityOrder(
            Collection<Faculty> faculties,
            List<SchoolProgram> priorityPrograms
    ) {

        Set<String> programIdsInFaculties = faculties.stream()
                .flatMap(f -> f.getSchoolPrograms().stream())
                .map(SchoolProgram::getProgramId)
                .collect(Collectors.toSet());

        return priorityPrograms.stream()
                .filter(p -> programIdsInFaculties.contains(p.getProgramId()))
                .map(p -> SchoolProgramBasicResponse.builder()
                        .id(p.getProgramId())
                        .programName(p.getName())
                        .courseCount(
                                p.getCourses() != null
                                        ? (long) p.getCourses().size()
                                        : 0L
                        )
                        .build())
                .toList();
    }

    /**
     * Sorts ProgramFacultyGroupResponse strictly by program priority.
     */
    public static List<ProgramFacultyGroupResponse> sortProgramFacultiesByPriority(
            List<ProgramFacultyGroupResponse> programFaculties,
            List<SchoolProgram> priorityPrograms
    ) {

        Map<String, Integer> priorityIndex =
                IntStream.range(0, priorityPrograms.size())
                        .boxed()
                        .collect(Collectors.toMap(
                                i -> priorityPrograms.get(i).getProgramId(),
                                i -> i
                        ));

        return programFaculties.stream()
                .sorted(Comparator.comparingInt(
                        pf -> priorityIndex.getOrDefault(
                                pf.getSchoolProgramId(),
                                Integer.MAX_VALUE
                        )
                ))
                .toList();
    }
    
    /**
     * Sort faculties by the highest priority school program they belong to.
     */
    public static List<Faculty> sortFacultiesByProgramPriority(
            Collection<Faculty> faculties,
            List<SchoolProgram> priorityPrograms
    ) {

        Map<String, Integer> priorityIndex =
                IntStream.range(0, priorityPrograms.size())
                        .boxed()
                        .collect(Collectors.toMap(
                                i -> priorityPrograms.get(i).getProgramId(),
                                i -> i
                        ));

        return faculties.stream()
                .sorted(Comparator.comparingInt(faculty ->
                        faculty.getSchoolPrograms().stream()
                                .map(sp -> priorityIndex.get(sp.getProgramId()))
                                .filter(Objects::nonNull)
                                .min(Integer::compareTo)
                                .orElse(Integer.MAX_VALUE)
                ))
                .toList();
    }

}

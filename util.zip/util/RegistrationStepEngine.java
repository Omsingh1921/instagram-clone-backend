package com.renaissance.app.util;

import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.renaissance.app.exception.BadRequestException;
import com.renaissance.app.model.StudentRegistration;
import com.renaissance.app.model.enums.RegistrationStep;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class RegistrationStepEngine {

    private static final Map<RegistrationStep, Set<RegistrationStep>> ALLOWED = Map.of(
        RegistrationStep.NONE, Set.of(RegistrationStep.PERSONAL_DETAILS),
        RegistrationStep.PERSONAL_DETAILS, Set.of(RegistrationStep.ADDRESS_DETAILS),
        RegistrationStep.ADDRESS_DETAILS, Set.of(RegistrationStep.EDUCATION_DETAILS),
        RegistrationStep.EDUCATION_DETAILS, Set.of(RegistrationStep.REVIEW_VIEWED),
        RegistrationStep.REVIEW_VIEWED, Set.of(RegistrationStep.REVIEW_COMPLETED),
        RegistrationStep.REVIEW_COMPLETED, Set.of(RegistrationStep.PAYMENT_INITIATED),
        RegistrationStep.PAYMENT_INITIATED, Set.of(RegistrationStep.PAYMENT_COMPLETED)
    );

    /** STRICT FSM — WEB only */
    public void moveTo(StudentRegistration reg, RegistrationStep target) {

        RegistrationStep current = reg.getLastCompletedStep();

        if (current == target) return;

        if (target.ordinal() < current.ordinal()) {
            throw new BadRequestException(
                "Backward transition not allowed: " + current + " → " + target
            );
        }

        RegistrationStep step = current;

        while (step != target) {
            RegistrationStep next = getNextStep(step);

            if (next == null) {
                throw new BadRequestException(
                    "Cannot advance from " + step + " to " + target
                );
            }

            if (!ALLOWED.getOrDefault(step, Set.of()).contains(next)) {
                throw new BadRequestException(
                    "Illegal step transition: " + step + " → " + next
                );
            }

            step = next;
        }

        reg.setLastCompletedStep(target);
    }

    /** BYPASS FSM — WhatsApp + Webhook */
    public void forceMoveTo(StudentRegistration reg, RegistrationStep target) {
        reg.setLastCompletedStep(target);
    }

    /** Deterministic next-step resolver (core) */
    public RegistrationStep getNextStep(RegistrationStep current) {

        RegistrationStep[] steps = RegistrationStep.values();
        int idx = current.ordinal();

        if (idx + 1 >= steps.length) {
            return null;
        }

        RegistrationStep next = steps[idx + 1];

        return ALLOWED.getOrDefault(current, Set.of()).contains(next)
                ? next
                : null;
    }

    /** Convenience overload for services */
    public RegistrationStep getNextStep(StudentRegistration reg) {
        if (reg == null || reg.getLastCompletedStep() == null) {
            return null;
        }
        return getNextStep(reg.getLastCompletedStep());
    }
}

package com.renaissance.app.util;

import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.renaissance.app.model.Course;
import com.renaissance.app.model.Profile;
import com.renaissance.app.model.SchoolProgram;
import com.renaissance.app.repository.ProfileRepository;
import com.renaissance.app.service.ICourseService;
import com.renaissance.app.service.ISchoolProgramService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LeadMapperHelper {

    private final ProfileRepository profileRepository;
    private final ISchoolProgramService schoolProgramService;
    private final ICourseService courseService;

    // -----------------------------------------
    // NORMALIZATION
    // -----------------------------------------
    public void normalize(Map<String, Object> map) {

        // NAME
        map.computeIfAbsent("name", k ->
                firstNonNull(
                        map.get("fullName"),
                        map.get("studentName"),
                        concat(map.get("firstName"), map.get("lastName"))
                )
        );

        // PHONE
        map.computeIfAbsent("phone", k ->
                firstNonNull(
                        map.get("contact"),
                        map.get("contactNumber"),
                        map.get("mobile"),
                        map.get("whatsappNumber")
                )
        );

        // EMAIL
        map.computeIfAbsent("email", k ->
                firstNonNull(
                        map.get("mail"),
                        map.get("studentEmail"),
                        map.get("gmail")
                )
        );

        // COURSE / PROGRAM IDS
        map.computeIfAbsent("courseId", k -> map.get("course"));
        map.computeIfAbsent("programId", k ->
                firstNonNull(map.get("program"), map.get("schoolProgramId"))
        );

        // Trim ONLY strings
        map.replaceAll((k, v) ->
                v instanceof String s ? s.trim() : v
        );
    }

    // -----------------------------------------
    // RELATION LOADING
    // -----------------------------------------
    public Course loadCourse(Map<String, Object> map) {
        String id = getString(map.get("courseId"));
        return id == null ? null : courseService.findCourseEntityById(id);
    }

    public SchoolProgram loadProgram(Map<String, Object> map) {
        String id = getString(map.get("programId"));
        return id == null ? null : schoolProgramService.findProgramEntityById(id);
    }

    // -----------------------------------------
    // PROFILE UPSERT
    // -----------------------------------------
    public Profile upsertProfile(
            Map<String, Object> map,
            Course course,
            SchoolProgram program
            
    ) {

        String email = getString(map.get("email"));
        String phone = getString(map.get("phone"));
        String name  = getString(map.get("name"));

        if (email == null && phone == null) {
            throw new IllegalArgumentException("Email or phone is required");
        }

        Optional<Profile> existing = Optional.empty();

        if (email != null)
            existing = profileRepository.findByEmailIgnoreCase(email);

//        if (existing.isEmpty() && phone != null)
//            existing = profileRepository.findByPhone(phone);

        Profile profile = existing.orElseGet(() ->
                Profile.builder()
                        .email(email)
                        .phone(phone)
                        .name(name != null ? name : "Unknown")
                        .build()
        );

        if (name != null) profile.setName(name);
        if (email != null) profile.setEmail(email);
        if (phone != null) profile.setPhone(phone);

        profile.setGender(getString(map.get("gender")));
        profile.setCity(getString(map.get("city")));
        profile.setState(getString(map.get("state")));

        if (course != null) profile.setPreferredCourse(course);
        if (program != null) profile.setPreferredProgram(program);

        return profileRepository.save(profile);
    }

    // -----------------------------------------
    // HELPERS
    // -----------------------------------------
    private String getString(Object o) {
        return o instanceof String s && !s.isBlank() ? s.trim() : null;
    }

    private Object firstNonNull(Object... values) {
        for (Object v : values) if (v != null) return v;
        return null;
    }

    private String concat(Object a, Object b) {
        if (a == null || b == null) return null;
        return a.toString() + " " + b.toString();
    }
}

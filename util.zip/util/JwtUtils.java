package com.renaissance.app.util;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.renaissance.app.exception.ResourceNotFoundException;
import com.renaissance.app.exception.UnauthorizedException;
import com.renaissance.app.model.Profile;
import com.renaissance.app.model.User;
import com.renaissance.app.model.enums.OtpType;
import com.renaissance.app.model.enums.TokenType;
import com.renaissance.app.repository.ProfileRepository;
import com.renaissance.app.repository.UserRepository;
import com.renaissance.app.util.constants.AppConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpServletRequest;

@Component
public class JwtUtils {

    @Value("${jwt.secret}")
    private String jwtSecret;
    
	@Value("${jwt.issuer}")
	private String issuer;

	@Value("${jwt.auth.expiration}")
	private long authTokenExpiry;

	@Value("${jwt.access.expiration}")
	private long accessTokenExpiry;

	@Value("${jwt.refresh.expiration}")
	private long refreshTokenExpiry;

    @Autowired
    private ProfileRepository profileRepository;
    
    @Autowired
    private UserRepository userRepository;

	private SecretKey getSecretKey() {
		return Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
	}

	public String generateToken(String email, String role, TokenType tokenType, OtpType otpType,
			Boolean isOtpVerified) {
		Map<String, Object> claims = new HashMap<>();
		claims.put(AppConstants.ROLE, role);
		claims.put(AppConstants.TOKEN_TYPE, tokenType.name());
		claims.put(AppConstants.OTP_TYPE, otpType != null ? otpType.name() : null);
		claims.put(AppConstants.IS_OTP_VERIFIED, isOtpVerified);
		return buildToken(claims, email, tokenType);
	}

	public String buildToken(Map<String, Object> claims, String subject, TokenType tokenType) {
		long expiry;

		switch (tokenType) {
		case AUTH_TOKEN:
			expiry = authTokenExpiry;
			break;
		case ACCESS_TOKEN:
			expiry = accessTokenExpiry;
			break;
		default:
			expiry = authTokenExpiry;
			break;
		}

		return Jwts.builder().claims(claims).subject(subject).issuedAt(new Date()).issuer(issuer)
				.expiration(new Date(System.currentTimeMillis() + expiry)).signWith(getSecretKey()).compact();
	}

	public String generateRefreshToken(String email, String role) {
		Map<String, Object> claims = new HashMap<>();
		claims.put(AppConstants.ROLE, role);
		claims.put(AppConstants.TOKEN_TYPE, TokenType.REFRESH_TOKEN.name());

		return Jwts.builder().claims(claims).subject(email).issuedAt(new Date())
				.expiration(new Date(System.currentTimeMillis() + refreshTokenExpiry)).signWith(getSecretKey())
				.compact();
	}
	
	public String buildProfileToken(Profile profile) {
		

        Map<String, Object> claims = new HashMap<>();
        claims.put(AppConstants.TOKEN_TYPE, TokenType.PROFILE_TOKEN.name());
        claims.put("profileId", profile.getId());
        claims.put("email", profile.getEmail());
        claims.put("phone", profile.getPhone());
        claims.put("name", profile.getName());
        //if null set it to null
//        claims.put("preferred_program_id", profile.getPreferredProgram()
//        		.getProgramId() != null 
//        		? profile.getPreferredProgram().getProgramId() 
//        				: null);
//        claims.put("preferred_course_Id", profile.getPreferredCourse().getCourseId() != null ? profile.getPreferredCourse().getCourseId() : null);
//        
        return Jwts.builder()
        		.claims(claims)
        		.subject(profile.getEmail())
        		.issuedAt(new Date())
        		.issuer(issuer)
        		.signWith(getSecretKey())
        		.compact();
	}

	public Claims extractClaims(String token) {
		return Jwts.parser().verifyWith(getSecretKey()).build().parseSignedClaims(token).getPayload();
	}

	public String extractEmail(String token) {
		return extractClaims(token).getSubject();
	}

	public TokenType extractTokenType(String token) {
		return TokenType.valueOf((String) extractClaims(token).get(AppConstants.TOKEN_TYPE));
	}

	public Boolean extractIsOtpVerified(String token) {
		return (Boolean) extractClaims(token).get(AppConstants.IS_OTP_VERIFIED);
	}

	public OtpType extractOtpType(String token) {
		String otpType = (String) extractClaims(token).get(AppConstants.OTP_TYPE);
		return otpType != null ? OtpType.valueOf(otpType) : null;
	}

	public String extractRole(String token) {
		return (String) extractClaims(token).get(AppConstants.ROLE);
	}

	public boolean isTokenExpired(String token) {
		return extractClaims(token).getExpiration().before(new Date());
	}

	public boolean isAccessToken(String token) {
		return extractTokenType(token) == TokenType.ACCESS_TOKEN;
	}

	public boolean isRefreshToken(String token) {
		return extractTokenType(token) == TokenType.REFRESH_TOKEN;
	}

	public boolean validateRefreshToken(String refreshToken) {
			return isRefreshToken(refreshToken) && !isTokenExpired(refreshToken);
	}

	public String getToken() {
		// Get current request
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
		if (authHeader != null && authHeader.startsWith("Bearer ")) {
			return authHeader.substring(7); // Remove "Bearer " prefix
		}

		throw new UnauthorizedException(AppConstants.INVALID_TOKEN);
	}
	 /**
     * Retrieves the currently authenticated User from the JWT token in the request header.
     */
    public User getCurrentUser() {
        // Extract token from the Authorization header
        String token = getToken();

        // Extract email (subject) from the token
        String email = extractEmail(token);

        // Fetch the user from the database
//        return userRepository.findByEmail(email)
//                .orElseThrow(() -> new ResourceNotFoundException(AppConstants.USER_NOT_FOUND));
        return userRepository.findByEmailAndIsDeletedFalse(email)
                .orElseThrow(() -> new ResourceNotFoundException(AppConstants.USER_NOT_FOUND));
    }
    
    public User getCurrentUserIfExists() {

        try {

            String token = getToken();

            if (token == null || token.isBlank()) {
                return null;
            }

            String email = extractEmail(token);

            if (email == null || email.isBlank()) {
                return null;
            }

            return userRepository.findByEmailAndIsDeletedFalse(email)
                    .orElseThrow(() -> new ResourceNotFoundException(AppConstants.USER_NOT_FOUND));

        } catch (Exception e) {
            return null;   // Token invalid / expired / parsing error
        }
    }
    
    
    public Profile getProfileFromToken() {
        String token = getToken();
        Claims claims = extractClaims(token);

        String type = (String) claims.get("tokenType");
        if (!"PROFILE_TOKEN".equals(type)) {
            throw new UnauthorizedException("Invalid token type");
        }

        String profileId = (String) claims.get("profileId");

        return profileRepository.findById(profileId)
                .orElseThrow(() -> new ResourceNotFoundException("Profile not found"));
    }

}
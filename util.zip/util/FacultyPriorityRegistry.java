package com.renaissance.app.util;

import java.util.Map;

public final class FacultyPriorityRegistry {

    private FacultyPriorityRegistry() {}

    private static final Map<String, Integer> PRIORITY_MAP = Map.of(
            "Pratik Uppal", 1,
            "Prof. Prakhar Shroti", 2,
            "Dr. Pooja Yadav", 3,
            "Manish Ramani", 4,
            "Dr. Anand Bhatt", 5
            
           
    );

    public static Integer basePriority(String facultyName) {
        return PRIORITY_MAP.get(facultyName);
    }
}


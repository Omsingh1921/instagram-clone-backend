package com.renaissance.app.util;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class EmailTemplateEngine {

    public String render(String templateText, Map<String, String> variables) {
        if (templateText == null) return null;
        String result = templateText;

        for (Map.Entry<String, String> entry : variables.entrySet()) {
            String placeholder = "{{" + entry.getKey() + "}}";
            result = result.replace(placeholder, entry.getValue() == null ? "" : entry.getValue());
        }

        return result;
    }
}

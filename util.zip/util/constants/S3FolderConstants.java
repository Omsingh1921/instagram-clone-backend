package com.renaissance.app.util.constants;


public class S3FolderConstants {

    private S3FolderConstants() {}

    // ------------------ BLOGS ------------------
    public static final String BLOGS_THUMBNAILS = "blogs/thumbnails";
    public static final String BLOGS_GALLERY = "blogs/gallery";
    public static final String BLOGS_COVER_IMAGES = "blogs/covers";

    // ------------------ NEWS ------------------
    public static final String NEWS_THUMBNAILS = "news/thumbnails";
    public static final String NEWS_GALLERY = "news/gallery";
    public static final String NEWS_COVER_IMAGES = "news/covers";
    public static final String NEWS_RELATED_MEDIA = "news/related_media";

    // ------------------ COURSES ------------------
    public static final String COURSES_THUMBNAILS = "courses/thumbnails";
    public static final String COURSES_GALLERY = "courses/gallery";
    public static final String COURSES_BROCHURES = "courses/brochures";
    public static final String COURSES_FEE = "courses/fee";
    public static final String COURSES_PROMO_MEDIA = "courses/promo";
    public static final String COURSES_ELIGIBILITY = "courses/eligibility";
    public static final String COURSES_FUTURE_OPPORTUNITIES = "courses/future_opportunities";

    // ------------------ SCHOOL PROGRAMS ------------------
    public static final String SCHOOL_PROGRAMS = "school_programs";
    public static final String SCHOOL_PROGRAMS_FACULTIES = "faculties";
    public static final String SCHOOL_THUMBNAILS = "school/thumbnails";
    public static final String SCHOOL_ICONS = "school/icons";

    // ------------------ EVENTS ------------------
    public static final String EVENTS_THUMBNAILS = "events/thumbnails";
    public static final String EVENTS_COVER_IMAGES = "events/covers";
    public static final String EVENTS_GALLERY = "events/gallery";
    public static final String EVENTS_GUESTS = "events/guests";

    // ------------------ FEATURES ------------------
    public static final String FEATURE_ICONS = "features/icons";

    // ------------------ SUBJECTS ------------------
    public static final String SUBJECT_IMAGES = "subjects/images";

    // ------------------ PLACEMENTS ------------------
    public static final String PLACEMENTS = "placements";

    // ------------------ STORIES ------------------
    public static final String STORIES_THUMBNAILS = "stories/thumbnails";
    public static final String STORIES_GALLERY = "stories/gallery";

    // ------------------ ALUMNI ------------------
    public static final String ALUMNI = "alumni";

    // ------------------ PRESS ------------------
    public static final String PRESS_RELEASES = "press_releases";

    // ------------------ INTERNSHIPS ------------------
    public static final String INHOUSE_INTERNSHIP_RESUMES = "internships/inhouse/resumes";

    // ------------------ COUNSELLORS ------------------
    public static final String COUNSELLOR_PROFILES = "counsellors/profiles";
	public static final String EVENTS_ABOUT_MEDIA = "events/about_media";
	public static final String JOB_LOGOS = "jobs/logos";
	public static final String CHANCELLOR_HIGHLIGHTS = "chancellor/highlights";
	public static final String BLOGS_AUTHORS = "blogs/authors";
	public static final String ICC_REPORT_IMAGES = "icc";
	public static final String JOB_RESUMES = "jobs/resume";
	public static final String TIMELINE_MEMORIES = "timelines/memories";
}
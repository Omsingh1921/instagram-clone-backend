package com.renaissance.app.util.constants;

public class AppConstants {
	// ================== PERMISSION ==================
	public static final String PERMISSION_NOT_FOUND = "Permission not found.";
	public static final String PERMISSION_UPDATE_SUCCESSFULLY = "Permission updated successfully.";
	public static final String PERMISSION_FETCHED_SUCCESSFULLY = "Permissions fetched successfully.";
	public static final String PERMISSION_REMOVED_SUCCESSFULLY = "Permission removed successfully";
	public static final String PERMISSION_DELETE_SUCCESS = "Permission deleted successfully";
	public static final String PERMISSION_ALREADY_EXISTS = "Permission already exists for this role";
	public static final String PERMISSION_CREATED = "Permission successfully Created";
	public static final String ROLE_PERMISSION_UPDATED = "Role permissions updated successfully";
	public static final String PLACEMENT_TYPE = "placementType";

	// ================== EMAIL ==================
	public static final String EMAIL_ALREADY_REGISTERED = "Email already registered.";
	public static final String MOBILE_ALREADY_REGISTERED = "Mobile already registered.";

	// ================== ROLE ==================
	public static final String ROLE_NOT_FOUND = "Selected role does not exist.";
	public static final String ADMIN_ROLE_NOT_FOUND = "Admin role not found.";
	public static final String INVALID_USER_ROLE = "Invalid user role.";
	public static final String ROLE_ALREADY_EXISTS = "Role already exists";
	public static final String ROLE_CREATED = "Role Successfully Created";
	public static final String ROLE_NOT_CREATED = "Role could not be created";
	public static final String PERMISSIONS_UPDATED_SUCCESS = "Permissions updated successfully for role: ";
	public static final String PERMISSIONS_NOT_UPDATED = "Permissions could not be updated for role: ";
	public static final String PERMISSION_ADDED_SUCCESS = "Permission added successfully";
	public static final String PERMISSION_NOT_ADDED = "Permission could not be added";
	public static final String ROLE_UPDATED = "Role updated successfully";
	public static final String ROLE_DELETE_SUCCESS = "Role deleted successfully";

	// ================== COMMON KEYS ==================
	public static final String ERROR = "error";
	public static final String MESSAGE = "message";
	public static final String STATUS = "status";
	public static final String STATUS_CODE = "statusCode";
	public static final String DATE = "date";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String EVENT_TYPE = "eventType";
	public static final String PAYLOAD = "payload";
	public static final String ID = "id";
	public static final String PERMISSION_ID = "permissionId";
	public static final String ROLE_ID = "roleId";
	public static final String BLOG_POST_ID = "blogPostId";
	public static final String COMMENT_ID = "commentId";
	public static final String IS_ACTIVE = "isActive";
	public static final String DOCUMENT_TYPE = "documentType";
	public static final String SUBMITTED_AT = "submittedAt";
	public static final String ADMIN_PASSWORD = "Admin@123";
	public static final String ADMIN_EMAIL = "admin@gmail.com";
	public static final String ROLE = "role";
	public static final String TOKEN_TYPE = "tokenType";
	public static final String IS_OTP_VERIFIED = "isOtpVerified";
	public static final String OTP_TYPE = "otpType";
	public static final String AUTH_TOKEN = "authToken";
	public static final String OTP = "otp";
	public static final String USER_AGENT = "User-Agent";
	public static final String ACCESS_TOKEN = "accessToken";
	public static final String REFRESH_TOKEN = "refreshToken";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer ";
	public static final String APPLICATION_JSON = "application/json";
	public static final String ADMIN = "ADMIN";
	public static final String USER = "USER";
	public static final String COMPANY_NAME = "Renaissance University";
	public static final String COMPANY_EMAIL = "contact@renaissance.com";
	public static final String COMPANY_SUPPORT_LINK = "mailto:" + COMPANY_EMAIL;
	public static final String FILE = "file";

	// ================== PAGINATION / SORT ==================
	public static final String PAGE_SIZE = "pageSize";
	public static final String PAGE_NUMBER = "pageNumber";
	public static final String SORT_DIRECTION = "sortDirection";
	public static final String SORT_KEY = "sortKey";
	public static final String SEARCH_VALUE = "searchValue";
	public static final String DESC = "DESC";
//	public static final String ROLE = "Role";

	// ================== OTP ==================
	public static final String OTP_SENT_FOR_LOGIN = "OTP sent to your registered email. Please verify.";
	public static final String OTP_SENT_FOR_RESET_PASSWORD = "OTP sent to your registered email for password reset.";
	public static final String OTP_SENT = "OTP sent. Please verify to continue.";
	public static final String OTP_ALREADY_VERIFIED = "OTP already verified. Cannot resend.";
	public static final String OTP_NOT_VERIFIED = "OTP is not verified.";
	public static final String INVALID_OR_EXPIRED_OTP = "Invalid or expired OTP.";
	public static final String RESEND_OTP_NOT_ALLOWED_FOR_THIS_TYPE = "OTP resend not allowed for this OTP type.";
	public static final String OTP_VERIFIED_SUCCESSFULLY = "OTP verified successfully.";

	// ================== ADMIN ==================
	public static final String ADMIN_NOT_FOUND = "Admin not found.";
	public static final String ADMIN_CREATED_SUCCESSFULLY = "Admin created successfully.";
	public static final String ADMIN_NOT_CREATED = "Admin could not be created";

	public static final String INVALID_CREDENTIALS = "Invalid credentials.";
	public static final String ADMIN_DELETED = "Admin deleted successfully.";
	public static final String ADMIN_PROFILE_UPDATED = "Admin Profile Successfully Updated";
	public static final String ADMIN_PROFILE_NOT_UPDATED = "Admin profile could not be updated.";
	public static final String ADMIN_SUCCESSFULLY_FATCH = "Admin successfully get";
	public static final String ADMIN_ALREDY_DELETED = "Admin is already deleted";
	public static final String ADMIN_STATUS_UPDATED = "Admin status updated successfully";
	public static final String ADMIN_STATUS_NOT_UPDATED = "Admin status has not been updated";
	public static final String ADMIN_ALREADY_DELETED = "Admin is already deleted";
	public static final String ADMIN_ALREADY_ACTIVE = "Admin status is already ACTIVE";
	public static final String ADMIN_ALREADY_INACTIVE = "Admin status is already INACTIVE";
	public static final String ADMIN_ALREADY_EXISTS = "Admin already exists";
	public static final String ADMIN_REACTIVATED = "Deleted admin account reactivated successfully.";

	// ================== TOKEN ==================
	public static final String MISSING_TOKEN = "Missing token.";
	public static final String TOKEN_EXPIRED = "Token expired.";
	public static final String INVALID_TOKEN_TYPE_FOR_VERIFICATION = "Invalid token type or OTP type for verification.";
	public static final String INVALID_TOKEN_TYPE = "Invalid token type.";
	public static final String TOKEN_NOT_BELONG_TO_USER = "Token does not belong to this user.";
	public static final String REFRESH_TOKEN_NOT_FOUND = "Refresh token not found.";
	public static final String INVALID_TOKEN = "Invalid token.";
	public static final String REFRESH_TOKEN_NOT_RECOGNIZED = "Refresh token is invalid, expired, or revoked.";
	public static final String ACCESS_TOKEN_GENERATED = "Access token generated.";

	// ================== SESSION ==================
	public static final String SESSION_NOT_FOUND = "Session not found.";
	public static final String SESSION_ALREADY_LOGGED_OUT = "Session is already logged out.";
	public static final String ALL_SESSION_LOGGED_OUT = "All other sessions logged out successfully.";
	public static final String CURRENT_SESSION_LOGGED_OUT = "Current session logged out successfully.";

	// ================== LOGOUT ==================
	public static final String LOGOUT = "Logout successful";

	// ================== PASSWORD ==================
	public static final String PASSWORD_SHOULD_BE_DIFFERENT = "New password must be different from the old password.";
	public static final String PASSWORD_RESET_SUCCESS = "Your password has been updated successfully.";

	// ================== ERRORS ==================
	public static final String REQUEST_BODY_MISSING = "Required request body is missing.";
	public static final String METHOD_NOT_ALLOWED = "Method not allowed.";
	public static final String VALIDATION_FAILED = "Validation failed.";
	public static final String ACCESS_DENIED = "Access denied.";
	public static final String SERVICE_DOWN = "Downstream service is unavailable. Please try again later.";
	public static final String SERVICE_UNAVAILABLE = "Service is temporarily unavailable.";
	public static final String REQUEST_TIME_OUT = "Request timed out. Please try again.";
	public static final String SOMETHING_WRONG = "Something went wrong.";
	public static final String READ_TIME_OUT = "Read timed out.";
	public static final String UNAUTHORIZED = "Unauthorized.";
	public static final String FAILED_TO_SEND_KAFKA_MESSAGE = "Failed to send Kafka message";
	public static final String UNAUTHORIZED_ACCESS = "Unauthorized Access";
	public static final String REFRESH_TOKEN_NOT_ALLOWED = "Refresh token not allowed.";

	// ================== POLICY ==================
	public static final String POLICY_ALREADY_EXISTS = "Policy document with version '%s' already exists.";
	public static final String POLICY_NOT_FOUND = "Policy document not found.";
	public static final String POLICY_UPDATE_ONLY_ACTIVE = "Only active policy documents can be updated.";
	public static final String POLICY_DOCUMENT_NOT_FOUND = "Policy document not found.";
	public static final String POLICY_DOCUMENT_DELETED_SUCCESSFULLY = "Policy document deleted successfully.";
	public static final String POLICY_CREATED_SUCCESS = "Policy document created successfully.";
	public static final String POLICY_UPDATED_SUCCESS = "Policy document updated successfully.";
	public static final String DOCUMENT_STATUS_UPDATED_SUCCESSFULLY = "Document status updated successfully";
	public static final String DATA_FATCH_SUCCESSFULLY = "Data retrieved successfully";
	public static final String POLICY_NOT_CREATED = "Policy Document could not be created";
	public static final String POLICY_NOT_UPDATED = "Policy Document update failed";

	// ================== CONTACT US ==================
	public static final String CONTACT_US_SUBMITTED_SUCCESSFULLY = "Your message has been submitted successfully.";
	public static final String CONTACT_STATUS_UPDATED_SUCCESSFULLY = "Contact status updated successfully.";
	public static final String IGNORED_CANNOT_CHANGE_TO_RESOLVED_OR_SUBMITTED = "Cannot change IGNORED status to RESOLVED or SUBMITTED";
	public static final String OPEN_CANNOT_CHANGE_TO_SUBMITTED = "Cannot change OPEN status back to SUBMITTED";
	public static final String SUBMITTED_CANNOT_CHANGE_DIRECTLY_TO_RESOLVED_OR_IGNORED = "Cannot move SUBMITTED directly to RESOLVED or IGNORED. Must be OPEN first.";
	public static final String STATUS_ALREADY_SAME = "Status is already ";
	public static final String IGNORED_CANNOT_CHANGE_TO_RESOLVED_OR_SUBMITTED_OR_OPEN = "Cannot change IGNORED status to RESOLVED, SUBMITTED, or OPEN";
	public static final String RESOLVED_CANNOT_CHANGE_TO_SUBMITTED_OR_OPEN_OR_IGNORED = "Cannot change RESOLVED status back to SUBMITTED or OPEN or IGNORED";

	public static final String CONTACT_SAVED_SUCCESS = "Contact saved successfully";
	public static final String CONTACT_NOT_SAVED = "Contact not saved";
	public static final String CONTACT_UPDATED_SUCCESS = "Contact updated successfully";
	public static final String CONTACT_NOT_UPDATED = "Contact not updated";
	public static final String CONTACT_NOT_FOUND = "Contact not found";
	public static final String CONTACT_RETRIEVED_SUCCESS = "Contact retrieved successfully";
	public static final String CONTACT_DELETED_SUCCESS = "Contact deleted successfully";
	public static final String CONTACT_ALREADY_DELETED = "Contact is already deleted";
	public static final String CONTACT_NOT_DELETED = "Contact could not be deleted";

	// ================== ABOUT US ==================
	public static final String NO_CONTANT_AVAILABLE = "No content available.";
	public static final String ABOUT_US_UPDATED = "About us successfully updated";
	public static final String ABOUT_US_NOT_UPDATED = "About Us could not be updated";

	public static final String ABOUT_US_SUCCESSFULLY_GET = "About Us retrieved successfully";
	public static final String ABOUT_US_ADDED_SUCCESSFULLY = "About Us added successfully";
	public static final String ABOUT_US_NOT_ADDED = "About Us could not be added";

	// ================== USER ==================
	public static final String USER_SUCCESSFULLY_FATCH = "User successfully get";
	public static final String USER_CREATED_SUCCESSFULLY = "User created successfully";
	public static final String USER_NOT_CREATED = "User could not be created";
	public static final String USER_NOT_FOUND = "User not found.";
	public static final String AUTHENTICATION_FAILED = "Authentication failed: ";
	public static final String USER_SUCCESSFULLY_GET = "User fetched successfully";
	public static final String USER_ALREADY_ACTIVE = "User status is already ACTIVE";
	public static final String USER_ALREADY_INACTIVE = "User status is already INACTIVE";
	public static final String USER_PROFILE_SUCCESSFULLY_UPDATED = "User profile updated successfully";
	public static final String USER_DELETED_SUCCESSFULLY = "User deleted successfully";
	public static final String USER_NOT_DELETED = "User could not be deleted";
	public static final String USER_SUCCESSFULLY_REGISTERED = "User successfully created";
	public static final String USER_ALREDY_DELETED = "User is already deleted";
	public static final String USER_ALREADY_EXISTS = "User already exists";
	public static final String USER_PROFILE_NOT_UPDATED = "User profile could not be updated";
	public static final String USER_STATUS_UPDATED_SUCCESSFULLY = "User status updated successfully";
	public static final String USER_STATUS_NOT_UPDATED = "User status could not be updated";
	public static final String UNAUTHORIZED_DELETE = "You are not authorized to delete this account";
	public static final String USER_ACCOUNT_DELETED_SUCCESSFULLY = "Your account deleted successfully";
	public static final String USER_FOLDER = "users";
	public static final String PHD_SCHOLLAR = "PHD-Schollar";
	public static final String USER_UPDATED_SUCCESSFULLY = "User updated successfully";
	public static final String USER_FETCH_SUCCESS = "User fetched successfully";
	public static final String USER_UPDATE_DELETED = "Cannot update a deleted user";
	public static final String USER_TOGGLE_DELETED = "Cannot change active status of a deleted user";
	public static final String USER_STATUS_UPDATED = "User %s successfully";

	// ================== BLOG_POST ==================
	public static final String BLOG_POST_NOT_FOUND = "Blog post not found";
	public static final String BLOG_POST_CREATED = "Blog post created successfully";
	public static final String BLOG_POST_NOT_CREATED = "Blog post could not be created";
	public static final String BLOG_POST_DELETED = "Blog post deleted successfully";
	public static final String BLOG_POST_NOT_DELETED = "Blog post could not be deleted";
	public static final String BLOG_POST_ALREADY_DELETED = "Blog post is already deleted";
	public static final String BLOG_POST_UPDATED = "Blog post updated successfully";
	public static final String BLOG_POST_NOT_UPDATED = "Blog post could not be updated";
	public static final String BLOG_POST_FETCHED = "Blog post fetched successfully";

	// ================== FAQ ==================
	public static final String FAQ_CREATED_SUCCESS = "FAQ created successfully";
	public static final String FAQ_NOT_CREATED = "FAQ could not be created";
	public static final String FAQ_UPDATED_SUCCESS = "FAQ updated successfully";
	public static final String FAQ_NOT_UPDATED = "FAQ could not be updated";
	public static final String FAQ_DELETED_SUCCESS = "FAQ deleted successfully";
	public static final String FAQ_NOT_FOUND = "FAQ not found with id: ";

	public static final String TOO_MANY_REQUESTS = "Too many requests from IP: ";
	public static final String LOGGED_OUT_SUCCESSFULLY = "Logged out successfully.";
	public static final String TOKEN_EXPIRED_OR_REVOKED = "Token has expired or has been revoked.";
	public static final String INVALID_EMAIL_OR_PASSWORD = "Invalid email or password.";
	public static final String TOKEN_USER_MISMATCH = "Token does not match the authenticated user.";
	public static final String ACCESS_TOKEN_REQUIRED = "Access token is required for this operation.";
	public static final String INVALID_OR_MISSING_AUTH_HEADER = "Invalid or missing Authorization header";

	public static final String AUTHOR_NOT_FOUND = "Author not found";
	public static final String CATEGORY_NOT_FOUND = "Category not found";
	public static final String CATEGORY_REQUIRED = "Category information is required";
	public static final String CATEGORY_TYPE_MISMATCH = "Category type mismatch";

	// -------------------- Success Messages --------------------
	public static final String BLOG_CREATED_SUCCESS = "Blog created successfully";
	public static final String BLOG_UPDATED_SUCCESS = "Blog updated successfully";
	public static final String BLOG_DELETED_CANNOT_UPDATE = "Cannot update deleted blog";
	public static final String BLOG_NOT_FOUND = "Blog not found";
	public static final String BLOG_DELETED_CANNOT_TOGGLE = "Cannot change active status of a deleted blog";
	public static final String BLOG_FETCHED_SUCCESS = "Blog fetched successfully";
	public static final String BLOG_DELETED_SUCCESS = "Blog deleted successfully";
	public static final String BLOG_ACTIVATED_SUCCESS = "Blog activated successfully";
	public static final String BLOG_DEACTIVATED_SUCCESS = "Blog deactivated successfully";

	public static final String EVENT_NOT_FOUND = "Event not found";
	public static final String EVENT_DELETED_CANNOT_UPDATE = "Cannot update deleted event";
	public static final String EVENT_DELETED_CANNOT_TOGGLE = "Cannot toggle a deleted event";
	public static final String EVENT_CREATED_SUCCESS = "Event created successfully";
	public static final String EVENT_UPDATED_SUCCESS = "Event updated successfully";
	public static final String EVENT_DELETED_SUCCESS = "Event deleted successfully";
	public static final String EVENT_FETCHED_SUCCESS = "Event fetched successfully";
	public static final String ALL_EVENTS_FETCHED_SUCCESS = "All events fetched successfully";
	public static final String EVENTS_BY_CATEGORY_FETCHED_SUCCESS = "Events by category fetched successfully";
	public static final String EVENT_ACTIVATED_SUCCESS = "Event activated successfully";
	public static final String EVENT_DEACTIVATED_SUCCESS = "Event deactivated successfully";

	// -------------------- CONTACT QUERY CONSTANTS --------------------
	public static final String QUERY_SUBMITTED_SUCCESS = "Query submitted successfully.";
	public static final String QUERY_FETCHED_SUCCESS = "Query fetched successfully.";
	public static final String ALL_QUERIES_FETCHED_SUCCESS = "All queries fetched successfully.";
	public static final String ADMIN_RESPONSE_UPDATED_SUCCESS = "Admin response updated successfully.";
	public static final String QUERY_DELETED_SUCCESS = "Query deleted successfully.";
	public static final String QUERY_ACTIVATED_SUCCESS = "Query activated successfully.";
	public static final String QUERY_DEACTIVATED_SUCCESS = "Query deactivated successfully.";

	public static final String QUERY_NOT_FOUND = "Query not found.";
	public static final String QUERY_ALREADY_DELETED = "This query has already been deleted.";

	public static final String QUERY_NAME_REQUIRED = "Query name is required.";
	public static final String QUERY_EMAIL_REQUIRED = "Query email is required.";
	public static final String QUERY_MESSAGE_REQUIRED = "Query message is required.";
	public static final String EMPTY_ADMIN_RESPONSE = "Admin response cannot be empty.";

	// -------------------- CONTACT US CONSTANTS --------------------
	public static final String CONTACT_CREATED_SUCCESS = "Contact created successfully.";
	public static final String CONTACT_FETCHED_SUCCESS = "Contact fetched successfully.";
	public static final String ALL_CONTACTS_FETCHED_SUCCESS = "All contacts fetched successfully.";
	public static final String CONTACT_ACTIVATED_SUCCESS = "Contact activated successfully.";
	public static final String CONTACT_DEACTIVATED_SUCCESS = "Contact deactivated successfully.";

	public static final String CONTACT_NAME_REQUIRED = "Contact name is required.";
	public static final String CONTACT_PHONE_REQUIRED = "Contact phone number is required.";
	public static final String CONTACT_EMAIL_REQUIRED = "Contact email is required.";

	public static final String CONTACT_CANNOT_UPDATE_DELETED = "Cannot update deleted contact";

	// -------------------- QUERY --------------------
	public static final String QUERY_UPDATED_RESPONSE_SUCCESS = "Admin response updated successfully";

	// -------------------- COURSES --------------------
	public static final String COURSE_CREATED_SUCCESS = "Course created successfully";
	public static final String COURSE_UPDATED_SUCCESS = "Course updated successfully";
	public static final String COURSE_DELETED_SUCCESS = "Course deleted successfully";
	public static final String COURSE_FETCHED_SUCCESS = "Course fetched successfully";
	public static final String COURSE_ALREADY_EXISTS = "Active course already exists with the same name under this program";
	public static final String COURSE_NOT_FOUND_FOR_PROGRAM = "Course not found for the given school program.";
	public static final String COURSE_NOT_FOUND = "Course not found with id: ";
	public static final String COURSE_NOT_FOUND_WITH_NAME = "Course not found with this name";
	public static final String COURSE_ACTIVATED_SUCCESS = "Course activated successfully.";
	public static final String COURSE_DEACTIVATED_SUCCESS = "Course deactivated successfully.";
	public static final String COURSE_DELETED_CANNOT_TOGGLE = "Deleted course cannot be activated or deactivated.";
	public static final String COURSE_ENDPOINT_ALREADY_EXISTS = "Course endpoint already exists";

	public static final String FEE_CREATED_SUCCESS = "Fee structure created successfully";
	public static final String FEE_NOT_FOUND_FOR_COURSE = "Fee structure not found for the given course.";
	public static final String FEE_UPDATED_SUCCESS = "Fee updated successfully";
	public static final String FEE_FETCHED_SUCCESS = "Fee fetched successfully";
	public static final String FEE_DELETED_SUCCESS = "Fee deleted successfully";
	public static final String FEE_NOT_FOUND = "Fee not found";
	public static final String FEE_INACTIVE_OR_DELETED = "Fees inactive or deleted";

	// News-related constants
	public static final String NEWS_CREATED_SUCCESS = "News created successfully";
	public static final String NEWS_UPDATED_SUCCESS = "News updated successfully";
	public static final String NEWS_FETCHED_SUCCESS = "News fetched successfully";
	public static final String NEWS_DELETED_CANNOT_UPDATE = "Cannot update deleted news";
	public static final String NEWS_CATEGORIES_FETCHED_SUCCESS = "News categories fetched successfully";
	public static final String ALL_NEWS_FETCHED_SUCCESS = "All news fetched successfully";
	public static final String NEWS_DELETED_SUCCESS = "News deleted successfully";
	public static final String NEWS_ACTIVATED_SUCCESS = "News activated successfully";
	public static final String NEWS_DEACTIVATED_SUCCESS = "news deactivated successfully";
	public static final String NEWS_NOT_FOUND = "News not found";
	public static final String NEWS_DELETED_CANNOT_TOGGLE = "Cannot change active status of a deleted news";
	public static final String NEWS_BY_CATEGORY_FETCHED_SUCCESS = "News by category fetched successfully";

	public static final String SUBJECT_NOT_FOUND = "Subject not found with ID: ";
	public static final String SUBJECT_ALREADY_EXISTS = "Subject already exists for this course and year.";
	public static final String SUBJECT_CREATED_SUCCESS = "Subject created successfully.";
	public static final String SUBJECT_UPDATED_SUCCESS = "Subject updated successfully.";
	public static final String SUBJECT_FETCHED_SUCCESS = "Subject fetched successfully.";
	public static final String SUBJECT_DELETED_SUCCESS = "Subject deleted successfully.";
	public static final String SUBJECT_DEACTIVATED_SUCCESS = "Subject deactivated successfully.";
	public static final String SUBJECT_ACTIVATED_SUCCESS = "Subject activated successfully.";
	public static final String SUBJECT_DELETED_CANNOT_TOGGLE = "Deleted subject cannot be activated or deactivated.";

	// Policy Document Constants
	public static final String DATA_FETCH_SUCCESSFULLY = "Policy document data fetched successfully";

	// School Program Constants
	public static final String SCHOOL_PROGRAM_CREATED_SUCCESS = "School program added successfully";
	public static final String SCHOOL_PROGRAM_FETCHED_SUCCESS = "School program fetched successfully";
	public static final String SCHOOL_PROGRAM_UPDATED_SUCCESS = "School program updated successfully";
	public static final String SCHOOL_PROGRAM_DELETED_SUCCESS = "School program deleted successfully";
	public static final String SCHOOL_PROGRAM_ALREADY_EXISTS = "Active school program already exists with the same name";
	public static final String SCHOOL_PROGRAM_CANNOT_UPDATE = "Cannot update a deleted or inactive program";
	public static final String SCHOOL_PROGRAM_INACTIVE_OR_DELETED = "School program is deleted or inactive.";
	public static final String SCHOOL_PROGRAM_CREATED_SUCCESSFULLY = "School program added successfully.";
	public static final String SCHOOL_PROGRAM_ENDPOINT_ALREADY_EXISTS = "School program end point already exists";
	public static final String SCHOOL_PROGRAM_FETCH_SUCCESS = "School program(s) fetched successfully.";
	public static final String SCHOOL_PROGRAM_UPDATED_SUCCESSFULLY = "School program updated successfully.";
	public static final String SCHOOL_PROGRAM_DELETED_SUCCESSFULLY = "School program deleted successfully.";
	public static final String SCHOOL_PROGRAM_UPDATE_NOT_ALLOWED = "Cannot update a deleted or inactive program.";
	public static final String SCHOOL_PROGRAM_ACTIVATED_SUCCESS = "School program activated successfully.";
	public static final String SCHOOL_PROGRAM_DEACTIVATED_SUCCESS = "School program deactivated successfully.";
	public static final String SCHOOL_PROGRAM_DELETED_CANNOT_TOGGLE = "Deleted program cannot be activated or deactivated.";
	public static final String SCHOOL_PROGRAM_NOT_FOUND = "School program not found with id: ";

	// --- Student Messages ---
	public static final String STUDENT_CREATED_SUCCESSFULLY = "Student created successfully.";
	public static final String STUDENT_UPDATED_SUCCESSFULLY = "Student updated successfully.";
	public static final String STUDENT_DELETED_SUCCESSFULLY = "Student deleted successfully.";
	public static final String STUDENT_FETCH_SUCCESSFULLY = "Student fetched successfully.";
	public static final String STUDENT_NOT_FOUND = "Student not found with id: ";

	// --- Testimonial Messages ---
	public static final String TESTIMONIAL_FOLDER = "testimonials";
	public static final String TESTIMONIAL_CREATED_AND_PUBLISHED = "Testimonial created and published successfully.";
	public static final String TESTIMONIAL_CREATED_PENDING_APPROVAL = "Testimonial created successfully; it will be available once approved by the authority.";
	public static final String TESTIMONIAL_UPDATED_SUCCESSFULLY = "Testimonial updated successfully.";
	public static final String TESTIMONIAL_DELETED_SUCCESSFULLY = "Testimonial deleted successfully.";
	public static final String TESTIMONIAL_FETCH_SUCCESS = "Testimonial fetched successfully.";
	public static final String TESTIMONIAL_FETCH_ALL_SUCCESS = "All testimonials fetched successfully.";
	public static final String TESTIMONIAL_VISIBILITY_UPDATED = "Testimonial visibility updated to %s.";
	public static final String TESTIMONIAL_NOT_FOUND = "Testimonial not found with id: ";

	// --- Email / Username ---
	public static final String EMAIL_ALREADY_EXISTS = "Email already in use";
	public static final String EMAIL_AVAILABLE = "Email is available";
	public static final String USERNAME_ALREADY_EXISTS = "Username already in use";
	public static final String USERNAME_AVAILABLE = "Username is available";
	public static final String CONTACT_NUMBER_ALREADY_EXISTS = "contach-number already in use";

	// ---highlights
	public static final String HIGHLIGHT_CREATED_SUCCESS = "Highlight created successfully";
	public static final String HIGHLIGHT_NOT_FOUND = "Highlight not found";
	public static final String HIGHLIGHT_DELETED_CANNOT_UPDATE = "Cannot update deleted highlight";
	public static final String HIGHLIGHT_UPDATED_SUCCESS = "Highlight updated successfully";
	public static final String HIGHLIGHT_FETCHED_SUCCESS = "Highlight fetched successfully";
	public static final String HIGHLIGHT_DELETED_SUCCESS = "Highlight deleted successfully";
	public static final String HIGHLIGHT_DELETED_CANNOT_TOGGLE = "Deleted highlight cannot toggled";
	public static final String HIGHLIGHT_ACTIVATED_SUCCESS = "Highlight activated succefully";
	public static final String HIGHLIGHT_DEACTIVATED_SUCCESS = "Highlight deactivated successfully";

	public static final String PLACEMENT_CREATED_SUCCESS = "Placement created successfully";
	public static final String PLACEMENT_NOT_FOUND = "Placememnt not found";
	public static final String PLACEMENT_UPDATED_SUCCESS = "Placement updated successfully";
	public static final String PLACEMENT_DELETED_SUCCESS = "Placement deleted successfully";
	public static final String PLACEMENT_FETCHED_SUCCESS = "Placement fetched successfully";

	public static final String STORY_CREATED_SUCCESS = "Story created successfully";
	public static final String STORY_NOT_FOUND = "Story not found";
	public static final String STORY_DELETED_CANNOT_UPDATE = "Cannot update deleted story";
	public static final String STORY_UPDATED_SUCCESS = "Story updated successfully";
	public static final String STORY_FETCHED_SUCCESS = "Story fetched successfully";
	public static final String STORY_DELETED_SUCCESS = "Story deleted successfully";
	public static final String STORY_DELETED_CANNOT_TOGGLE = "Cannot change active status of a deleted story";
	public static final String STORY_ACTIVATED_SUCCESS = "Story activated successfully";
	public static final String STORY_DEACTIVATED_SUCCESS = "Story deactivated successfully";

	public static final String CATEGORY_FETCHED_SUCCESS = "Category feetched successfully";
	public static final String CATEGORY_CREATED_SUCCESS = "Category created successfully";
	public static final String CATEGORY_DELETED_SUCCESS = "Category created successfully";
	public static final String CATEGORY_UPDATED_SUCCESS = "Category updated successfully";
	public static final String CATEGORY_ALREADY_EXISTS = "Category already exists";
	public static final String CATEGORY_ACTIVATED_SUCCESS = "Category activated successfully";
	public static final String CATEGORY_DEACTIVATED_SUCCESS = "Category deactivated successfully";

	public static final String ENDPOINT_NOT_FOUND = "EndPoint not found";

	public static final String PRESS_RELEASE_CREATED_SUCCESS = "Press-release created successfully";
	public static final String PRESS_RELEASE_NOT_FOUND = "Press-release not found ";
	public static final String PRESS_RELEASE_DELETED_CANNOT_UPDATE = "Cannot update deleted press-release";
	public static final String PRESS_RELEASE_UPDATED_SUCCESS = "Press-release updated successfully";
	public static final String PRESS_RELEASE_FETCHED_SUCCESS = "Press-release fetched successfullly";
	public static final String PRESS_RELEASE_DELETED_SUCCESS = "Press-release deleted successfully";
	public static final String PRESS_RELEASE_DELETED_CANNOT_TOGGLE = "Cannot active or deactive deleted news";
	public static final String PRESS_RELEASE_ACTIVATED_SUCCESS = "Press-release actived successfully";
	public static final String PRESS_RELEASE_DEACTIVATED_SUCCESS = "Press-release deactived successfully";

	public static final String GRIEVANCE_ALREADY_DELETED = "Grievance already deleted";
	public static final String GRIEVANCE_NOT_FOUND = "Grievance not found ";
	public static final String GRIEVANCE_DELETED_SUCCESS = "Grievance deleted successfully";
	public static final String GRIEVANCE_ACTIVATED_SUCCESS = "Grievance activated successfully";
	public static final String GRIEVANCE_DEACTIVATED_SUCCESS = "Grievaance deactivated successfully";
	public static final String GRIEVANCE_FETCHED_SUCCESS = "Grievance fetched successfully";
	public static final String GRIEVANCE_SUBMITTED_SUCCESS = "Grievance subimitted successfully";

	public static final String CAMPUS_TOUR_ACTIVATED_SUCCESS = "Campus tour request activated successfully";
	public static final String CAMPUS_TOUR_DEACTIVATED_SUCCESS = "Campus tour request deactivated successfully";
	public static final String CAMPUS_TOUR_DELETED_SUCCESS = "Campus tour request deleted successfully";
	public static final String CAMPUS_TOUR_NOT_FOUND = "Campus tour request not found";
	public static final String CAMPUS_TOUR_ALREADY_DELETED = "Campus tour request already deleted";
	public static final String CAMPUS_TOUR_FETCHED_SUCCESS = "Campus tour request fetched successfully";
	public static final String CAMPUS_TOUR_BOOKED_SUCCESS = "Campus tour requested successfullly";
	public static final String VISIT_DATE_CANNOT_BE_PAST = "Visit date cannot be in the past.";
	public static final String VISIT_TIME_CANNOT_BE_PAST = "Visit time cannot be earlier than the current time.";

	public static final String INHOUSE_INTERNSHIP_APPLIED_SUCCESS = "Applied for the internship successfully";
	public static final String INHOUSE_INTERNSHIP_NOT_FOUND = "Internship request not found";
	public static final String INHOUSE_INTERNSHIP_FETCHED_SUCCESS = "Internship request fetched successfully";
	public static final String INHOUSE_INTERNSHIP_ACTIVATED_SUCCESS = "Internship request activated successfully";
	public static final String INHOUSE_INTERNSHIP_DEACTIVATED_SUCCESS = "Internship deactivated successfully";
	public static final String INHOUSE_INTERNSHIP_DELETED_SUCCESS = "INternship request deleted successfully";
	public static final String INHOUSE_INTERNSHIP_ALREADY_DELETED = "Internship request already deleted ";

	public static final String EVENT_DATE_INVALID = "Invalid event date ";
	public static final String ENQUIRY_SUBMITTED_SUCCESS = "Enquiry submitted successfully";

	// --- Response Messages ---
	public static final String PERSONAL_DETAILS_SAVED = "Personal details saved.";
	public static final String ADDRESS_DETAILS_SAVED = "Address details saved.";
	public static final String EDUCATION_DETAILS_SAVED = "Education details saved.";
	public static final String REVIEW_DATA_FETCHED = "Review data fetched.";

	// --- Review Keys ---
	public static final String PERSONAL_DETAILS = "personalDetails";
	public static final String ADDRESS_DETAILS = "addressDetails";
	public static final String EDUCATION_DETAILS = "educationDetails";
	public static final String PROGRAM = "program";
	public static final String COURSE = "course";
	public static final String FEES = "fees";
	public static final String REGISTRATION_ID = "registrationId";

	// ---- Response messages ----
	public static final String MSG_PERSONAL_DETAILS_SAVED = "Personal details saved.";
	public static final String MSG_ADDRESS_DETAILS_SAVED = "Address details saved.";
	public static final String MSG_EDUCATION_DETAILS_SAVED = "Education details saved.";
	public static final String MSG_REVIEW_DATA_FETCHED = "Review data fetched.";
	public static final String REGISTRATION_NOT_FOUND = "Registration not founnd";

	public static final String DEFAULT_SUBJECT_IMAGE_PATH = "/static/images/default-subject.png";
	public static final String DEFAULT_SUBJECT_IMAGE_BASE_NAME = "default-subject";
	public static final String DEFAULT_SUBJECT_IMAGE_EXTENSION = "png";
	public static final String DEFAULT_SUBJECT_IMAGE_CONTENT_TYPE = "image/png";

	// BULK UPLOAD
	public static final String EXCEL_FILE_REQUIRED = "Excel file is missing or empty.";
	public static final String SCHOOLS = "schools";
	public static final String COURSES = "courses";
	public static final String OUR_FACULTY = "our faculty";
	public static final String OUR_PLACEMENTS = "our placements";
	public static final String OUR_COUNSELLORS = "our counsellors";
	public static final String EXCEL_IMPORT_SUCCESS = "Excel import completed successfully.";
	public static final String BROCHURE_REQUEST_SUCCESS = "Brochure request accepted successfully";
	public static final String ROLE_UPDATED_SUCCESSFULLY = "Role updated successfully";
	public static final String INVALID_CURRENT_PASSWORD = "Current password is invalid";
	public static final String PASSWORD_CHANGED_SUCCESS = "Password changed successfully";

	// TIMELINE & TIMELINE_MEMORIES
	public static final String TIMELINE_CREATED_SUCCESS = "Timeline year created successfully.";
	public static final String TIMELINE_UPDATED_SUCCESS = "Timeline year updated successfully.";
	public static final String TIMELINE_DELETED_SUCCESS = "Timeline year deleted successfully.";
	public static final String TIMELINE_FETCHED_SUCCESS = "Timeline year fetched successfully.";
	public static final String TIMELINE_NOT_FOUND = "Timeline year not found.";
	public static final String TIMELINE_ALREADY_EXISTS = "Timeline for this year already exists.";
	public static final String TIMELINE_MEMORY_CREATED_SUCCESS = "Timeline memory created successfully.";
	public static final String TIMELINE_MEMORY_UPDATED_SUCCESS = "Timeline memory updated successfully.";
	public static final String TIMELINE_MEMORY_DELETED_SUCCESS = "Timeline memory deleted successfully.";
	public static final String TIMELINE_MEMORY_FETCHED_SUCCESS = "Timeline memory fetched successfully.";
	public static final String TIMELINE_MEMORY_NOT_FOUND = "Timeline memory not found with ID: ";
	public static final String TIMELINE_MEMORY_DEFAULT_SET_SUCCESS = "Default memory updated successfully.";
	public static final String TIMELINE_MEMORY_CANNOT_UNSET_DEFAULT = "Cannot unset default memory. Please set another memory as default.";

	// ================== VAPI ==================
	public static final String VAPI_WEBHOOK_RECEIVED   = "Webhook received";
	public static final String VAPI_CALL_FETCHED       = "Call record fetched successfully";
	public static final String VAPI_CALLS_FETCHED      = "Call records fetched successfully";
	public static final String VAPI_CALL_NOT_FOUND     = "Vapi call record not found";

	// ================== PLACEMENT LEADS ==================
	public static final String PLACEMENT_LEAD_SUBMITTED_SUCCESS = "Placement lead submitted successfully";
	public static final String PLACEMENT_LEAD_NOT_FOUND = "Placement lead request not found";
	public static final String PLACEMENT_LEAD_ALREADY_DELETED = "Placement lead request already deleted";
	public static final String PLACEMENT_LEAD_FETCHED_SUCCESS = "Placement lead request fetched successfully";
	public static final String PLACEMENT_LEAD_DELETED_SUCCESS = "Placement lead request deleted successfully";
	public static final String PLACEMENT_LEAD_ACTIVATED_SUCCESS = "Placement lead request activated successfully";
	public static final String PLACEMENT_LEAD_DEACTIVATED_SUCCESS = "Placement lead request deactivated successfully";
}

package com.renaissance.app.util.constants;

import java.util.Set;

public final class S3Constants {

    private S3Constants() {}

    // -------------------- Keys --------------------
    public static final String SECURE_URL = "secure_url";
    public static final String RESOURCE_TYPE = "resource_type";
    public static final String RESULT_KEY = "result";
    public static final String PUBLIC_ID = "public_id";
    public static final String FOLDER = "folder";
    public static final String QUALITY = "quality";
    public static final String FETCH_FORMAT = "fetch_format";
    public static final String PROGRESSIVE = "progressive";

    // -------------------- Values --------------------
    public static final String DEFAULT_RESOURCE_TYPE = "image";
    public static final String IMAGE_TYPE = "image";
    public static final String VIDEO_TYPE = "video";
    public static final String RAW_TYPE = "raw";
    public static final String AUTO = "auto";

    // -------------------- Supported Extensions --------------------
    public static final Set<String> RAW_FILE_TYPES = Set.of("pdf", "docx", "txt", "csv", "zip", "json");
    public static final Set<String> VIDEO_FILE_TYPES = Set.of("mp4", "avi", "mov", "mkv");

    // -------------------- Validation Messages --------------------
    public static final String EMPTY_FILE_BYTES = "File content cannot be empty.";
    public static final String FILE_NAME_REQUIRED = "File name is required.";
    public static final String FOLDER_NAME_REQUIRED = "Folder name is required.";
    public static final String FILE_EXTENSION_REQUIRED = "File extension is required.";
    public static final String PUBLIC_ID_REQUIRED = "Public ID cannot be null or empty.";
}

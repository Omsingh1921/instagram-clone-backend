package com.renaissance.app.util.constants;

public final class EmailTemplateKeys {

    private EmailTemplateKeys() {}

    public static final String REGISTRATION_CONFIRMATION = "REGISTRATION_CONFIRMATION";
    public static final String CONDITIONAL_OFFER = "CONDITIONAL_OFFER";
    public static final String ENQUIRY_FORM = "ENQUIRY_FORM";
    public static final String FEES_CALCULATOR = "FEES_CALCULATOR";
    public static final String GRIEVANCE = "GRIEVANCE";
    public static final String ONLINE_VIRTUAL_COUNSELLING = "ONLINE_VIRTUAL_COUNSELLING";
    public static final String IN_HOUSE_INTERNSHIP = "IN_HOUSE_INTERNSHIP";
    public static final String CAMPUS_TOUR = "CAMPUS_TOUR";
    public static final String CONTACT_US = "CONTACT_US";
    public static final String CAREER_VACANCY = "CAREER_VACANCY";
}

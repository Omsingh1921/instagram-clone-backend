package com.renaissance.app.util.constants;

public class ValidationConstants {

	// User Validation
	public static final String USERNAME_REQUIRED = "Username is required";
	public static final String FIRST_NAME_REQUIRED = "First Name is required";
	public static final String LAST_NAME_REQUIRED = "Last Name is required";
	public static final String FULL_NAME_REQUIRED = "Full Name is required";
	public static final String FIRST_NAME_LENGTH = "First name must be at most 50 characters";
	public static final String LAST_NAME_LENGTH = "Last name must be at most 50 characters";

	// Email Validation
	public static final String EMAIL_REQUIRED = "Email is required";
	// public static final String EMAIL_PATTERN =
	// "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
	public static final String EMAIL_PATTERN = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
	public static final String EMAIL_PATTERN_MESSAGE = "Invalid email format";

	// Contact Number Validation
	public static final String MOBILE_NUMBER_REQUIRED = "Mobile number is required";
	public static final int MOBILE_NUMBER_LENGTH = 10;
	public static final String MOBILE_NUMBER_PATTERN = "^[0-9]{10}$"; // Matches only number
	public static final String MOBILE_NUMBER_PATTERN_MESSAGE = "Mobile number is invalid";

	// Password Validation
	public static final String PASSWORD_REQUIRED = "Password is required";
	public static final int PASSWORD_MIN_LENGTH = 8;
	public static final int PASSWORD_MAX_LENGTH = 30;
	public static final String PASSWORD_SIZE_MESSAGE = "Password must be between 8 and 30 characters long";
	public static final String PASSWORD_PATTERN = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
	public static final String PASSWORD_PATTERN_MESSAGE = "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.";
	public static final String NEW_PASSWORD_REQUIRED = "New password is required";

	// Role Validation
	public static final String ROLE_REQUIRED = "Role is required";
	public static final String ROLE_NAME_REQUIRED = "Role name is required";
	public static final String ROLE_TYPE_REQUIRED = "Role type is required";
	public static final String ROLE_CREATOR_ID_REQUIRED = "Role creator ID is required";
	public static final String ROLE_ID_REQUIRED = "Role ID is required";
	public static final String PERMISSION_ID_REQUIRED = "Permission ID is required";
	public static final String PERMISSION_TITLE_REQUIRED = "Permission title required";
	public static final String DESCRIPTION_REQUIRED = "Description is required";
	public static final String ROLE_NAME_SIZE = "Role name must be between 5 and 200 characters";
	public static final String DESCRIPTION_SIZE = "Description Size must be between 3 and 50 characters";
	public static final String PERMISSION_IDS_REQUIRED = "At least one permission must be selected";

	// UUID Validation
	public static final String INVALID_UUID = "Invalid UUID format";
	public static final String ID_REQUIRED = "Id is Required";

	/* ===================== PAGINATION & SORTING ===================== */
	public static final String PAGE_SIZE_REQUIRED = "Page size is required";
	public static final String PAGE_INDEX_REQUIRED = "Page index is required";
	public static final String SORT_ORDER_PATTERN_MESSAGE = "Sort order must be either 'ASC' or 'DESC'";
	public static final String SORT_ORDER_PATTERN = "ASC|DESC|asc|desc";

	/* ===================== OTP ===================== */
	public static final String OTP_REQUIRED = "OTP is required";
	public static final String OTP_REGEX_PATTERN = "^[0-9]{6}$";
	public static final String OTP_LENGTH_VALIDATION = "OTP must be a 6-digit number";

	/* ===================== POLICY ===================== */
	public static final String DOCUMENT_TYPE_REQUIRED = "Document type is required";
	public static final String POLICY_DOCUMENT_ID_REQUIRED = "Policy Document id is required";
	public static final String DOCUMENT_CONTENT_REQUIRED = "Document content must not be blank";
	public static final String TITLE_REQUIRED = "Title is required";
	public static final String IMAGE_REQUIRED = "Image is required";
	public static final String DOCUMENT_ALREADY_ACTIVE = "Document is already active";
	public static final String DOCUMENT_ALREADY_INACTIVE = "Document is already inactive";

	/* ===================== STATIC PAGES ===================== */
	public static final String TYPE_REQUIRED = "Static page type is required";
	public static final String CONTENT_REQUIRED = "Content must not be blank";

	/* ===================== ABOUT US ===================== */
	public static final String MODIFIED_BY_REQUIRED = "Modified by is required";

	/* ===================== CONTACT US ===================== */
	public static final String NAME_REQUIRED = "Name is required";
	public static final String NAME_LENGTH = "Name must be at most 50 characters";
	public static final String MESSAGE_REQUIRED = "Message is required";
	public static final String MESSAGE_LENGTH = "Message must be at most 500 characters";
	public static final String STATUS_NOT_NULL = "Status must not be null";
	public static final String UPDATED_BY_NOT_BLANK = "UpdatedBy must not be blank";

	// Course Eligibility
	public static final String ELIGIBILITY_TITLE_REQUIRED = "Eligibility title is required";;

	/* ===================== COURSE ===================== */
	public static final String DESCRIPTION_LENGTH = "Description must be at most 2000 characters";
	public static final String COURSE_NAME_REQUIRED = "Course name is required";
	public static final String COURSE_NAME_LENGTH = "Course name must be at most 200 characters";
	public static final String SCHOOL_PROGRAM_ID_REQUIRED = "SchoolProgramId is required";
	public static final String DESCRIPTION_LENGTH_2000 = "Description must be at most 2000 characters";
	public static final String COURSE_START_DATE_REQUIRED = "Corse start date is required";
	public static final String COURSE_START_DATE_FUTURE_OR_PRESENT = "Course start date must be in the present or future";

	// Student
	public static final String STUDENT_NAME_REQUIRED = "Student name is required";
	public static final String COURSE_ID_REQUIRED = "Course ID is required";

	// Installment
	public static final String SEQUENCE_REQUIRED = "Sequence is required";
	public static final String AMOUNT_REQUIRED = "Amount is required";
	public static final String AMOUNT_POSITIVE = "Amount must be positive";

	// User
	public static final String USERNAME_LENGTH = "Username must be between 3 and 50 characters";
	public static final String NAME_LENGTH_100 = "Name cannot exceed 100 characters";
	public static final String PROFILE_PICTURE_REQUIRED = "Profile picture is required";

	// Pagination
	public static final String PAGE_SIZE_POSITIVE = "Page size must be positive";
	public static final String PAGE_INDEX_POSITIVE = "Page index must be positive";

	// FEES
	public static final String TOTAL_FEE_REQUIRED = "Total fee is required";
	public static final String INSTALLMENTS_REQUIRED = "Installments are required";

	// Blog
	public static final String BLOG_TITLE_REQUIRED = "Blog title is required.";
	public static final String BLOG_TITLE_MAX_LENGTH = "Blog title must not exceed 150 characters.";

	public static final String BLOG_PREVIEW_REQUIRED = "Preview content is required.";
	public static final String BLOG_PREVIEW_MAX_LENGTH = "Preview content must not exceed 500 characters.";

	public static final String BLOG_DETAIL_REQUIRED = "Detailed content is required.";

	public static final String BLOG_TYPE_REQUIRED = "Blog type is required.";
	public static final String BLOG_TYPE_PATTERN_MESSAGE = "Blog type must contain only letters, spaces, hyphens, or underscores, and be between 3–50 characters.";

	public static final String CATEGORY_NAME_MAX_LENGTH = "Category name must not exceed 100 characters.";

	public static final String CONTACT_EMAIL_REQUIRED = "Email is required.";
	public static final String CONTACT_EMAIL_INVALID = "Invalid email format.";

	public static final String CONTACT_MESSAGE_REQUIRED = "Message is required.";
	public static final String CONTACT_MESSAGE_MAX_LENGTH = "Message must not exceed 1000 characters.";

	public static final String NAME_PATTERN = "^[A-Za-zÀ-ÿ'\\-\\s]{2,100}$";
	public static final String NAME_PATTERN_MESSAGE = "Name must contain only letters, spaces, hyphens, or apostrophes.";

	public static final String PHONE_PATTERN = "^(\\+\\d{1,3}[- ]?)?\\d{10,15}$";
	public static final String PHONE_PATTERN_MESSAGE = "Invalid phone number format.";

	public static final String CONTACT_NAME_REQUIRED = "Name is required.";
	public static final String CONTACT_NAME_MAX_LENGTH = "Name must not exceed 100 characters.";

	public static final String RESOURCE_REQUIRED = "Resource title required";
	public static final String ACTION_REQUIRED = "Action is required";
	public static final String PATTERN_FOR_CAPITAL = "^[A-Z_]+$";
	public static final String PATTERN_FOR_CAPITAL_PATTERN_MESSAGE = "Resource must be uppercase and use underscores instead of spaces";
	public static final String PERMISSION_TYPE_REQUIRED = "Permission Type is required";

	public static final String TITLE_MAX_LENGTH = "Title cannot exceed 200 characters";
	public static final String DESCRIPTION_MAX_LENGTH = "Description cannot exceed 500 characters";
	public static final String NAME_MAX_LENGTH = "Name must be at most 200 characters";
	public static final String REFRESH_TOKEN_REQUIRED = "Refresh token is required";

	public static final String FACEBOOK_URL_MAX_LENGTH = "Facebook URL cannot exceed 200 characters";
	public static final String INSTAGRAM_URL_MAX_LENGTH = "Instagram URL cannot exceed 200 characters";
	public static final String LINKEDIN_URL_MAX_LENGTH = "LinkedIn URL cannot exceed 200 characters";
	public static final String TWITTER_URL_MAX_LENGTH = "Twitter URL cannot exceed 200 characters";
	public static final String YOUTUBE_URL_MAX_LENGTH = "YouTube URL cannot exceed 200 characters";

	public static final String DESIGNATION_MAX_LENGTH = "Designation cannot exceed 100 characters";
	public static final String SPECIALIZATION_MAX_LENGTH = "Specialization cannot exceed 150 characters";
	public static final String BIO_MAX_LENGTH = "Bio cannot exceed 1000 characters";
	public static final String INVALID_EMAIL = "Invalid email address";

	public static final String AUTHOR_NAME_REQUIRED = "Author name is required";
	public static final String AUTHOR_NAME_MAX_LENGTH = "Author name cannot exceed 100 characters";

	// PlacementRequest messages
	public static final String STUDENT_ID_REQUIRED = "Student ID is required";
	public static final String COMPANY_NAME_REQUIRED = "Company name is required";
	public static final String COMPANY_NAME_MAX_LENGTH = "Company name cannot exceed 200 characters";
	public static final String PACKAGE_OFFERED_REQUIRED = "Package offered is required";
	public static final String PACKAGE_OFFERED_POSITIVE = "Package offered must be positive";
	public static final String COUNTRY_REQUIRED = "Country is required";
	public static final String COUNTRY_MAX_LENGTH = "Country cannot exceed 100 characters";

	// NewsRequest messages
	public static final String PREVIEW_CONTENT_REQUIRED = "Preview content is required";
	public static final String PREVIEW_CONTENT_MAX_LENGTH = "Preview content cannot exceed 500 characters";

	public static final String DETAILED_CONTENT_REQUIRED = "Detailed content is required";

	public static final String NEWS_TYPE_REQUIRED = "News type is required";

	public static final String PUBLISH_DATE_REQUIRED = "Publish date is required";

	public static final String CATEGORY_ID_OR_NAME_REQUIRED = "Either existing category ID or new category name must be provided";
	public static final String CONTENT_MAX_LENGTH = "Content maximum length cannot exceed 1000 characters";

	public static final String EVENT_DATE_REQUIRED = "Event date is required";

	public static final String ADDITIONAL_INFO_MAX_LENGTH = "Additional info cannot exceed 1000 characters";

	public static final String PHONE_REQUIRED = "At least one phone number is required";

	public static final String DURATION_MAX_LENGTH = "Duration cannot exceed 50 characters";

	public static final String GUEST_NAME_REQUIRED = "Guest name is required";
	public static final String START_DATE_REQUIRED = "Start date is required";
	public static final String END_DATE_REQUIRED = "End date is required";
	public static final String VENUE_REQUIRED = "Venue is required";
	public static final String EVENT_TYPE_REQUIRED = "Event type is required";

	public static final String VENUE_MAX_LENGTH = "Venue cannot exceed 200 characters";
	public static final String EVENT_TYPE_MAX_LENGTH = "Event type cannot exceed 100 characters";
	public static final String SHORT_DESCRIPTION_MAX_LENGTH = "Short description cannot exceed more than 500 words";
	public static final String DESCRIPTION_LENGTH_500 = "Description cannot exceed more than 500 words";
	public static final String LONG_DESCRIPTION_MAX_LENGTH = "Description cannot exceed more than 2000 words";
	public static final String THUMBNAIL_DESCRIPTION_MAX_LENGTH = "Thumbnail description cannot exceed more than 500 words";
	public static final String COURSE_TYPE_REQUIRED = "Course Type required";
	public static final String COURSE_TYPE_MAX_LENGTH = "Course Type maximum length exceeded";

	public static final String SUBJECT_NAME_REQUIRED = "Subject name is required";
	public static final String SUBJECT_NAME_LENGTH = "Subject name cannot exceed 200 characters";
	public static final String SUBJECT_DESCRIPTION_LENGTH = "Subject description cannot exceed 500 characters";
	public static final String SUBJECT_CODE_LENGTH = "Subject code cannot exceed 100 characters";
	public static final String YEAR_MIN = "Year must be at least 1";
	public static final String YEAR_MAX = "Year cannot exceed 10";
	public static final String MEDIA_FILE_REQUIRED = "Media file required";
	public static final String VISIBLE_REQUIRED = "visibility required";
	public static final String SUBJECT_ID_REQUIRED = "Subject ID is required";
	public static final String ACADEMIC_YEAR_REQUIRED = "Academic year is required";
	public static final String COMPANY_PLACE_TYPE_REQUIRED = "Company place type is required";
	public static final String STUDENT_TYPE_REQUIRED = "Student type is required";
	public static final String BLOG_AUTHOR_REQUIRED = "Author is required";
	public static final String BLOG_AUTHOR_MAX_LENGTH = "Author name cannot exceed 100 characters";
	public static final String AUTHOR_REQUIRED = "Author is required";
	public static final String ALT_TEXT_REQUIRED = "Alt text is required";
	public static final String CONTACT_CITY_MAX_LENGTH = "City must not exceed 100 characters";
	public static final String CONTACT_CITY_REQUIRED = "City is required";
	public static final String CATEGORY_ID_REQUIRED = "Category ID is required";
	public static final String ORGANIZER_REQUIRED = "Organizer is required";
	public static final String CONTACT_QUERY_TYPE_REQUIRED = "Query type is required";
	public static final String CONTACT_MESSAGE_REQUIRED_FOR_GENERAL_ENQUIRY = "Message is required for General Enquiry type";
	public static final String START_TIME_REQUIRED = "Start time is required";
	public static final String END_TIME_REQUIRED = "End time is required";
	public static final String SUBJECT_IDS_REQUIRED = "Subject ids required";
	public static final String PUBLISHER_REQUIRED = "Media Publisher required";
	public static final String MEDIA_DETAIL_LINK_REQUIRED = "Media Detail Link required";
	public static final String EMAIL_MAX_LENGTH = "Email can not greater than 15o characcters";
	public static final String PHONE_MAX_LENGTH = "Phone cannot be more more than 20 digits";
	public static final String DEPARTMENT_YEAR_REQUIRED = "Department and year is required";
	public static final String SUBJECT_REQUIRED = "Subject or title is required";
	public static final String GRIEVANCE_DETAIL_REQUIRED = "Grievance details required";
	public static final String CITY_REQUIRED = "City name is required";
	public static final String VISIT_DATE_REQUIRED = "Visit date is required";
	public static final String VISIT_DATE_FUTURE = "Visit date must be today or in the future.";
	public static final String CITY_MAX_LENGTH = "City maximum length exceed";
	public static final String VISIT_TIME_REQUIRED = "Visit time is required";
	public static final String BATCH_REQUIRED = "Batch required";

	// -------------------- ALUMNI VALIDATION --------------------
	public static final String ALUMNI_NAME_REQUIRED = "Alumni name is required.";
	public static final String ALUMNI_NAME_MAX_LENGTH = "Alumni name must not exceed 100 characters.";

	public static final String ALUMNI_IMAGE_REQUIRED = "Alumni image is required.";

	public static final String ALUMNI_ALT_TEXT_REQUIRED = "Alt text for the alumni image is required.";
	public static final String ALUMNI_ALT_TEXT_MAX_LENGTH = "Alt text must not exceed 150 characters.";

	public static final String DESIGNATION_REQUIRED = "Designation is required.";

	public static final String THUMBNAIL_FILE_REQUIRED = "Thumbnail image is required.";
	public static final String COVER_IMAGE_FILE_REQUIRED = "Cover image is required.";
	public static final String ALT_TEXT_MAX_LENGTH = "Alt text must not exceed 150 characters.";

	// -------------------- SEO CONFIG VALIDATION --------------------
	public static final String SEO_CONFIG_REQUIRED = "SEO configuration is required.";
	public static final String META_TITLE_REQUIRED = "Meta title is required.";
	public static final String META_TITLE_MAX_LENGTH = "Meta title must not exceed 255 characters.";
	public static final String META_KEYWORDS_REQUIRED = "Meta keywords are required.";
	public static final String META_KEYWORDS_MAX_LENGTH = "Meta keywords must not exceed 500 characters.";
	public static final String META_DESCRIPTION_REQUIRED = "Meta description is required.";
	public static final String META_DESCRIPTION_MAX_LENGTH = "Meta description must not exceed 1000 characters.";
	public static final String BLOG_ID_REQUIRED = "Blog ID is required for update.";

	// -------------------- COUNSELLOR VALIDATION --------------------
	public static final String COUNSELLOR_NAME_REQUIRED = "Counsellor name is required.";
	public static final String COUNSELLOR_NAME_MAX_LENGTH = "Counsellor name must not exceed 150 characters.";

	public static final String COUNSELLOR_EMAIL_REQUIRED = "Email is required.";
	public static final String COUNSELLOR_EMAIL_INVALID = "Invalid email format.";
	public static final String COUNSELLOR_EMAIL_MAX_LENGTH = "Email must not exceed 150 characters.";

	public static final String COUNSELLOR_PHONE_REQUIRED = "Phone number is required.";
	public static final String COUNSELLOR_PHONE_INVALID = "Phone number contains invalid characters.";
	public static final String COUNSELLOR_PHONE_MAX_LENGTH = "Phone number must not exceed 15 digits.";

	public static final String COUNSELLOR_IS_GENERAL_REQUIRED = "The 'isGeneral' flag is required.";
	public static final String COUNSELLOR_VIRTUAL_ENABLED_REQUIRED = "The 'virtualCounsellingEnabled' flag is required.";

	public static final String COUNSELLOR_PROGRAMS_REQUIRED = "At least one school program ID must be provided.";
	public static final String COUNSELLOR_PROGRAM_ID_NOT_BLANK = "School program ID cannot be blank.";

	public static final String COUNSELLOR_AVAILABILITY_REQUIRED = "At least one availability slot must be provided.";

	// -------------------- AVAILABILITY VALIDATION --------------------
	public static final String AVAILABILITY_DAY_REQUIRED = "Day of week is required.";
	public static final String AVAILABILITY_START_TIME_REQUIRED = "Start time is required.";
	public static final String AVAILABILITY_END_TIME_REQUIRED = "End time is required.";
	public static final String AVAILABILITY_TIME_ORDER_INVALID = "End time must be after start time.";

	// --- Unique Selling Point (USP) ---
	public static final String FEATURES_REQUIRED = "Features list is required.";
	public static final String USP_FEATURES_MAX = "A USP can have a maximum of 8 features.";

	// --- Future Opportunities ---
	public static final String OPPORTUNITY_TITLE_REQUIRED = "Opportunity title is required.";
	public static final String OPPORTUNITY_DESCRIPTION_REQUIRED = "Opportunity description is required.";
	public static final String FUTURE_OPPORTUNITY_REQUIRED = "Future opportunity required";
	public static final String COURSE_ENDPOINT_INVALID = "Invalid course end point";

	// --- Unique Selling Point ---
	public static final String FEATURES_COUNT_LIMIT = "A USP must have between 1 and 8 features.";

	// --- Eligibility Section ---
	public static final String ELIGIBILITY_TITLE_MAX_LENGTH = "Eligibility title must not exceed 200 characters.";
	public static final String ELIGIBILITY_ITEMS_REQUIRED = "Eligibility items list is required.";
	public static final String ELIGIBILITY_ITEMS_MIN = "At least one eligibility item must be provided.";

	// --- Eligibility Items ---
	public static final String ASSET_TITLE_REQUIRED = "Item title is required.";
	public static final String ASSET_TITLE_MAX_LENGTH = "Item title must not exceed 200 characters.";

	// --- Future Opportunity Section ---
	public static final String OPPORTUNITIES_REQUIRED = "At least 3 opportunity items are required.";
	public static final String OPPORTUNITIES_SIZE_RANGE = "You must provide between 3 and 5 opportunities.";
	public static final String DESCRIPTION_LENGTH_1000 = "Description canot exceet 1000 characters";

	// --- Future Opportunity Update ---
	public static final String OPPORTUNITIES_MAX_COUNT = "A maximum of 5 opportunities can be listed.";

	public static final String COVER_IMAGE_REQUIRED = "Cover image is required.";
	public static final String EVENT_TIME_MAX_LENGTH = "Event time must not exceed 100 characters.";
	public static final String THUMBNAIL_REQUIRED = "Thumbnail is required.";
	public static final String EVENT_TIME_REQUIRED = "Event time is required.";
	public static final String ORGANIZER_NAME_MAX_LENGTH = "Organizer name cannot exceed 150 characters";
	public static final String GALLERY_LIMIT = "More than 10 imaages are not allowed";
	public static final String EVENT_ID_REQUIRED = "Event id is required";
	public static final String BIO_REQUIRED = "Bio required";
	public static final String PROFILE_IMAGE_REQUIRED = "Profile image isrequired";
	public static final String NEWS_ID_REQUIRED = "News id is required";
	public static final String STUDENT_NAME_MAX_LENGTH = "Studnet name maximum length exceeded";
	public static final String PROFILE_PHOTO_REQUIRED = "Profile photo is required";
	public static final String INSUPPORTED_MEDIA_TYPE = "Unsupported media type";
	public static final String STATE_ID_REQUIRED = "State id is required";
	public static final String COUNTRY_ID_REQUIRED = "Country id is required";

	// ---- Generic ----
	public static final String MSG_NOT_BLANK = "Field must not be blank";
	public static final String MSG_NOT_NULL = "Field must not be null";
	public static final String MSG_INVALID_EMAIL = "Invalid email format";
	public static final String MSG_INVALID_UUID = "Invalid UUID format";

	// ---- Personal Details ----
	public static final String DOB_REQUIRED = "Date of birth is required";
	public static final String FATHER_NAME_REQUIRED = "Father's name is required";
	public static final String MOTHER_NAME_REQUIRED = "Mother's name is required";
	public static final String CONTACT_REQUIRED = "Contact number is required";
	public static final String WHATSAPP_REQUIRED = "WhatsApp number is required";
	public static final String PARENT_CONTACT_REQUIRED = "Parent contact number is required";
	public static final String GENDER_REQUIRED = "Gender selection is required";
	public static final String CATEGORY_REQUIRED = "Category/Caste is required";
	public static final String PROGRAM_REQUIRED = "Program selection is required";
	public static final String COURSE_REQUIRED = "Course selection is required";

	// ---- Address ----
	public static final String STATE_REQUIRED = "State is required";
	public static final String PINCODE_REQUIRED = "Pincode is required";

	// ---- Education ----
	public static final String REGISTRATION_ID_REQUIRED = "Registration ID is required";
	public static final String RECENT_EDU_REQUIRED = "Recent education is required";
	public static final String BOARD_REQUIRED = "Board is required";
	public static final String PASSING_YEAR_REQUIRED = "Passing year is required";

	// ---- Review ----
	public static final String AGREEMENT_REQUIRED = "You must accept the terms to continue";
	public static final String NOT_NULL = "Education status must not be null";
	public static final String DURATION_REQUIRED = "Course Duration required";

	// Counsellor & Program
	public static final String INVALID_COUNSELLOR_ID = "Counsellor ID is required.";
	public static final String INVALID_PROGRAM_ID = "Program ID must not be empty.";

	// User
	public static final String INVALID_USER_NAME = "User name is required.";
	public static final String INVALID_PHONE = "Phone number must contain 7 to 15 digits.";
	public static final String INVALID_GENDER = "Gender must be specified.";

	// Friends
	public static final String FRIEND_LIST_REQUIRED = "At least one friend must be provided.";

	// Session Time
	public static final String INVALID_SESSION_DATE = "Session date is required.";
	public static final String INVALID_START_TIME = "Session start time is required.";
	public static final String INVALID_END_TIME = "Session end time is required.";
	public static final String ENROLLMENT_OR_ROLL_REQUIRED = "Enrollment or roll number is required";
	public static final String ENROLLMENT_OR_ROLL_MAX_LENGTH = "Enrollment or roll number cannot exceed 100 characters";
	public static final String INFO_TRUE_CONFIRMATION_REQUIRED = "Confirmation that the information provided is true is required";
	public static final String FALSE_REPORTING_ACK_REQUIRED = "Acknowledgment of penalties for false reporting is required";

	public static final String FULL_NAME_SIZE = "Full name must be between 3 and 100 characters";

	public static final String CONTACT_INVALID = "Contact number must be 10 digits";

	public static final String WHATSAPP_SAME_REQUIRED = "WhatsApp-same flag is required";
	public static final String ELIGIBILITY_REQUIRED = "Eligibility criteria is required";
	public static final String ABOUT_THE_EVENT_MEDIA_REQUIRED = "About the event media is required";

	// -------------------- JOB VALIDATIONS --------------------

	public static final String JOB_NAME_REQUIRED = "Job name is required";

	public static final String JOB_NAME_LENGTH = "Job name must not exceed 200 characters";

	public static final String JOB_DESCRIPTION_REQUIRED = "Job description is required";

	public static final String EXPERIENCE_LEVEL_REQUIRED = "Experience level is required";

	public static final String JOB_TYPE_REQUIRED = "Job type is required";

	public static final String SALARY_AMOUNT_REQUIRED = "Salary amount is required";

	public static final String SALARY_AMOUNT_POSITIVE = "Salary amount must be greater than zero";

	public static final String SALARY_PERIOD_REQUIRED = "Salary period is required";

	public static final String COURSE_IDS_INVALID = "One or more course IDs are invalid";

	public static final String JOB_LOGO_INVALID = "Invalid job logo file";
	public static final String FAQ_QUESTION_REQUIRED = "FAQ question is required";

	public static final String FAQ_QUESTION_MAX_LENGTH = "FAQ question must not exceed 300 characters";

	public static final String FAQ_ANSWER_REQUIRED = "FAQ answer is required";
	public static final String FAQ_STATUS_REQUIRED = "Faq status required";
	public static final String FAQ_ALREADY_EXISTS = "FAQ already exists";
	public static final String AUTHOR_BIO_MAX_LENGTH = "Author bio cannot exceeed 2000 characters";
	public static final String AUTHOR_IMAGE_REQUIRED = "Author image is required";
	
	
	 // -------- GENERIC --------
    public static final String INVALID_MOBILE = "Invalid mobile number";
    public static final String INVALID_PINCODE = "Invalid pincode";

    // -------- PERSONAL --------
    public static final String FULL_NAME_INVALID =
            "Full name must be between 2 and 100 characters";

    public static final String GENDER_INVALID =
            "Gender value is invalid";

    public static final String CATEGORY_INVALID =
            "Category / caste value is invalid";

    // -------- PROGRAM / COURSE --------
    public static final String PROGRAM_ID_INVALID =
            "Invalid program id";

    public static final String COURSE_ID_INVALID =
            "Invalid course id";

    // -------- EDUCATION --------
    public static final String PASSING_YEAR_INVALID =
            "Passing year must be a valid year";

    public static final String BOARD_INVALID =
            "Board name must not exceed 100 characters";

    public static final String SCHOOL_NAME_INVALID =
            "School / College name must not exceed 150 characters";
    
    // -------- COMMON --------
    public static final String REQUIRED = "This field is required";
 
    // -------- EDUCATION --------
    public static final String EDU_STATUS_REQUIRED = "Education status is required";
    public static final String SCHOOL_REQUIRED = "School or college name is required";
	public static final String SEMESTER_MIN_INVALID = "Minimum value for semester is 1";
	public static final String SEMESTER_MAX_INVALID = "Maximum value for semester is 8";
	public static final String PROGRAM_ID_REQUIRED = "program must be  required ";

	// TIMELINE & TIMELINE_MEMORIES
	public static final String TIMELINE_YEAR_REQUIRED = "Timeline year is required";
	public static final String TIMELINE_YEAR_INVALID = "Timeline year must be a valid year";
	public static final String TIMELINE_MEMORY_TITLE_REQUIRED = "Memory title is required";
	public static final String TIMELINE_MEMORY_TITLE_LENGTH = "Memory title cannot exceed 200 characters";
	public static final String TIMELINE_MEMORY_DESCRIPTION_REQUIRED = "Memory description is required";
	public static final String TIMELINE_ID_REQUIRED = "Timeline ID is required";
}

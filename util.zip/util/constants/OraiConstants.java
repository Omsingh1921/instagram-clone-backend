package com.renaissance.app.util.constants;

import java.util.Map;

/**
 * SINGLE SOURCE OF TRUTH For all WhatsApp Template Configurations
 */
public final class OraiConstants {

	private OraiConstants() {
	}

	/*
	 * ===================================================== WhatsApp Core Config
	 * =====================================================
	 */

	public static final String MESSAGING_PRODUCT = "whatsapp";
	public static final String MESSAGE_TYPE = "template";

//    public static final String LANGUAGE_CODE = "en";
	public static final String LANGUAGE_POLICY = "deterministic";

	public static final String NAMESPACE = "a742775c_24d2_43d8_ad20_5d75ea7e81e8";

	public static final String TEMPLATE_APPLY_NOW = "apply_now_06feb2026";

	public static final String TEMPLATE_ENQUIRY_FORM = "enquiry_form_06feb2026";

	public static final String TEMPLATE_CAMPUS_VISIT = "campus_visit_06feb2026";

	public static final String TEMPLATE_VIRTUAL_COUNSELLING = "virtual_counselling_04feb";

	// virtual_tour_06feb2026 (1)
	public static final String TEMPLATE_VIRTUAL_TOUR = "virtual_tour_06feb2026";
	
	public static final String TEMPLATE_RU_CONDITIONAL = "conditional_16feb";

	public static final String TEMPLATE_COUNSELLOR_INFO = "infor_2026";

	public static final String TEMPLATE_FEE_CALCULATOR = "fee_calc_13feb";

	public static final String TEMPLATE_CONTACT_US ="conntact_us_13feb";

	public static final String[] VIRTUAL_TOUR_PARAMS = 
		{ 
			"name" // {{1}} -> A
	    };

	public static final String[] APPLY_NOW_PARAMS = 
		{ 
			"name", 
			"userId",
			"fullName",
			"email", 
			"courseSession",
			"courseCategory",
			"course",
			"courseFees", 
			"registrationFees", 
			"feeStructure"	
		};

	// enquiry_form_05feb (5)
	// enquiry_form_06feb2026 (6)
	public static final String[] ENQUIRY_FORM_PARAMS = { 
			"greetingName", 
			"name", 
			"email", 
			"contact",
			"city",
			"courseInterest" 
	};

	// campus_visit_06feb2026 (3)
	public static final String[] CAMPUS_VISIT_PARAMS =
		{ 
			"name",
			"date", 
			"time"
			
		};

	// virtual_counselling_04feb (4)
	public static final String[] VIRTUAL_COUNSELLING_PARAMS =
		{
				"name",
				"date", 
				"time", 
				"meetLink"
				
		};


	public static final String[] COUNSELLOR_INFO_PARAMS = { 
			"counsellorName", 
			"studentName", 
			"studentContact", 
			"date",
			"time", 
			"meetingLink" 		
	};


	public static final String[] FEE_CALCULATOR_PARAMS = 
	{
			"name", // {{1}} Greeting name
			"course", // {{2}} Course name
			"fullFee", // {{3}} Full course fee
			"perDayFee" // {{4}} Per-day fee
	};


	
	public static final String[] CONTACT_US_PARAMS = 
	{	
			"name" 
	};
	
	
// Conditional admission template (1 param)

	public static final String[] RU_CONDITIONAL_PARAMS =
	{ 
			"name" // {{1}}
	};


	public static final Map<String, String> TEMPLATE_LANGUAGE = Map.of(

			TEMPLATE_APPLY_NOW, "en", 
			TEMPLATE_ENQUIRY_FORM, "en", 
			TEMPLATE_CAMPUS_VISIT, "en",
			TEMPLATE_VIRTUAL_COUNSELLING, "en",
			TEMPLATE_VIRTUAL_TOUR, "en",
			TEMPLATE_COUNSELLOR_INFO, "en_US",
			TEMPLATE_CONTACT_US, "en",			// NEW
			TEMPLATE_RU_CONDITIONAL, "en");
	
	
	public static final int FEE_CALCULATOR_PARAM_COUNT = FEE_CALCULATOR_PARAMS.length; // = 4
	
	public static final int CONTACT_US_PARAM_COUNT = CONTACT_US_PARAMS.length; 
	
	public static final int RU_CONDITIONAL_PARAM_COUNT = RU_CONDITIONAL_PARAMS.length; // = 1
	
	public static final int APPLY_NOW_PARAM_COUNT = APPLY_NOW_PARAMS.length;

	public static final int ENQUIRY_FORM_PARAM_COUNT = ENQUIRY_FORM_PARAMS.length;

	public static final int CAMPUS_VISIT_PARAM_COUNT = CAMPUS_VISIT_PARAMS.length;

	public static final int VIRTUAL_COUNSELLING_PARAM_COUNT = VIRTUAL_COUNSELLING_PARAMS.length;

	public static final int VIRTUAL_TOUR_PARAM_COUNT = VIRTUAL_TOUR_PARAMS.length;
//==========================================================================================================//

	public static final String KEY_MESSAGING_PRODUCT = "messaging_product";

	public static final String VAL_WHATSAPP = "whatsapp";

	public static final String KEY_TYPE = "type";

	public static final String TYPE_TEMPLATE = "template";

	public static final String KEY_TO = "to";

	public static final String KEY_TEMPLATE = "template";

	public static final String KEY_NAMESPACE = "namespace";

	public static final String KEY_NAME = "name";

	public static final String KEY_LANGUAGE = "language";

	public static final String KEY_POLICY = "policy";

	public static final String KEY_CODE = "code";

	public static final String VAL_POLICY_DETERMINISTIC = "deterministic";

	public static final String KEY_COMPONENTS = "components";

	public static final String KEY_PARAMETERS = "parameters";

	public static final String COMPONENT_HEADER = "header";

	public static final String COMPONENT_BODY = "body";

	public static final String COMPONENT_BUTTON = "button";

	public static final String MEDIA_IMAGE = "image";
	public static final String MEDIA_DOCUMENT = "document";

	public static final String KEY_LINK = "link";
	public static final String KEY_FILENAME = "filename";

	public static final String KEY_TEXT = "text";

	public static final String KEY_SUB_TYPE = "sub_type";
	public static final String SUB_TYPE_URL = "url";

	public static final String KEY_INDEX = "index";

	public static final String HEADER_API_KEY = "API-KEY";

	public static final String TEMPLATE_CAMPUS_VISIT_NOTIFICATION = "campus_visit_notification";

	public static final String DATE_KEY = "date";

	public static final String TIME_KEY = "time";
	public static final String MEET_KEY = "meet_link";

	public static final String TEMPLATE_VIRTUAL_COUNSELING_CONFIRMATION = "virtual_counseling_confirmation";

	public static final String TEMPLATE_ENQUIRY_FORM_CONFIRMATION = "enquir_form_confirmation";

	public static final String EMAIL_KEY = "email";

	public static final String CONTACT_KEY = "contact";

	public static final String CITY = "city";

	public static final String INTRESTED_COURSE = "courseInterest";

	public static final String TEMPLATE_FEE_NOTIFICATION = "fee_notification";
	// "grevience_template"
	public static final String TEMPLATE_GREVIENCE_TEMPLATE = "grevience_template";

	// Template names
	public static final String TEMPLATE_RU_CONFIRM_BUTTON_NEW = "ru_confirm_button_new";

	// Parameter keys used in templates
	public static final String PARAM_NAME = "name";

	public static final String PARAM_USER_ID = "userId";

	public static final String PARAM_FULL_NAME = "fullName";

	public static final String PARAM_EMAIL = "email";

	public static final String PARAM_COURSE_SESSION = "courseSession";

	public static final String PARAM_COURSE_CATEGORY = "courseCategory";

	public static final String PARAM_COURSE = "course";

	public static final String PARAM_COURSE_FEES = "courseFees";

	public static final String PARAM_REGISTRATION_FEES = "registrationFees";

	public static final String PARAM_FEE_STRUCTURE = "feeStructure";
	public static final String PARAM_FEE_STRUCTURE_ALT = "fees_structure";

	public static final String TEMPLATE_IN_HOUSE_INTERNSHIP = "in_house_internship";
//	public static final String TEMPLATE_IN_HOUSE_INTERNSHIP = "virtual_counseling_confirmation";

	public static final String NAMESPACE_WHATSAPP_TEMPLATES = "a742775c_24d2_43d8_ad20_5d75ea7e81e8";

	public static final String PARAM_STUDENT_NAME = "student_name";
	public static final String PARAM_USER_ID_ALT = "user_id";
	public static final String PARAM_FULL_NAME_ALT = "full_name";
	public static final String PARAM_DATE_OF_BIRTH = "date_of_birth";
	public static final String PARAM_GENDER = "gender";
	public static final String PARAM_CONTACT_NUMBER = "contact_number";
	public static final String PARAM_CONTACT_WHATSAPP = "contact_whatsapp";
	public static final String PARAM_EMAIL_ALT = "email";
	public static final String PARAM_CASTE = "caste";
	public static final String PARAM_MOTHER_NAME = "mother_name";
	public static final String PARAM_FATHER_NAME = "father_name";
	public static final String PARAM_PARENT_CONTACT_NUMBER = "parent_contact_number";
	public static final String PARAM_PERMANENT_COUNTRY = "permanent_country";
	public static final String PARAM_PERMANENT_STATE = "permanent_state";
	public static final String PARAM_PERMANENT_CITY = "permanent_city";
	public static final String PARAM_PERMANENT_ADDRESS = "permanent_address";
	public static final String PARAM_PINCODE = "pincode";
	public static final String PARAM_LAST_EDUCATION = "last_education";
	public static final String PARAM_LAST_EDUCATION_STATUS = "last_education_status";
	public static final String PARAM_EDUCATION_BOARD = "education_board";
	public static final String PARAM_SCHOOL_COLLEGE_NAME = "school_college_name";
	public static final String PARAM_COURSE_SESSION_ALT = "course_session";
	public static final String PARAM_COURSE_CATEGORY_ALT = "course_category";
	public static final String PARAM_COURSE_ALT = "course";
	public static final String PARAM_REGISTRATION_FEES_ALT = "registration_fees";
	public static final String PARAM_COURSE_FEES_ALT = "course_fees";
	public static final String PARAM_REGISTRATION_PAYMENT = "registration_payment";
	public static final String PARAM_REFERRED_BY_NAME = "referred_by_name";
	public static final String PARAM_CREATED_DATE = "created_date";
	public static final String PARAM_CITY = "city";

	public static final String PARAM_COURSE_DURATION = "course_duration";
	public static final String PARAM_SESSION_YEAR = "session_year";
	// course_name
	public static final String PARAM_COURSE_NAME = "course_name";

	public static final String TEMPLATE_BROCHURE_REQUEST = "templete/brochure";

	public static final String TEMPLATE_REMINDER_2026 = "reminder_temp_2026";

	public static final String LINK_KEY = "link";

	public static final String TEMPLATE_CAMPUS_VISIT_2026 = "campus_visit_06feb2026";

	// Virtual counselling
	public static final String PARAM_MEET_LINK = "meetLink";

	// Counsellor info template
	public static final String PARAM_COUNSELLOR_NAME = "counsellorName";
	public static final String PARAM_STUDENT_NAME_ALT = "studentName";
	public static final String PARAM_STUDENT_CONTACT = "studentContact";
	public static final String PARAM_MEETING_LINK = "meetingLink";

	public static final String TEMPLATE_REGISTRATION_CONFIRMATION = "apply_now_06feb2026";

}
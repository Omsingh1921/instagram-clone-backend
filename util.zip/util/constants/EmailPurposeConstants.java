package com.renaissance.app.util.constants;

public final class EmailPurposeConstants {

    private EmailPurposeConstants() {}

    public static final String REGISTRATION_CONFIRMATION = "registration confirmation";
    public static final String CONDITIONAL_OFFER = "conditional offer";

    public static final String ENQUIRY_FORM = "enquiry form";
    public static final String ENQUIRY_FORM_ALT1 = "enquity form";
    public static final String ENQUIRY_FORM_ALT2 = "enquiry";
    public static final String ENQUIRY_FORM_ALT3 = "enquity";

    public static final String FEES_CALCULATOR = "fees calculator";
    public static final String FEES_CALCULATOR_ALT1 = "fee calculator";
    public static final String FEES_CALCULATOR_ALT2 = "fees enquiry";

    public static final String GRIEVANCE = "register your grievance";
    public static final String GRIEVANCE_ALT1 = "grievance";
    public static final String GRIEVANCE_ALT2 = "submit grievance";

    public static final String ONLINE_VIRTUAL_COUNSELLING = "online virtual counselling";
    public static final String ONLINE_VIRTUAL_COUNSELLING_ALT1 = "online virtual councelling";
    public static final String ONLINE_VIRTUAL_COUNSELLING_ALT2 = "virtual counselling";
    public static final String ONLINE_VIRTUAL_COUNSELLING_ALT3 = "virtual councelling";

    public static final String IN_HOUSE_INTERNSHIP = "in house internship";
    public static final String IN_HOUSE_INTERNSHIP_ALT1 = "in-house internship";
    public static final String IN_HOUSE_INTERNSHIP_ALT2 = "inhouse internship";

    public static final String CAMPUS_TOUR = "campus tour";
    public static final String CAMPUS_TOUR_ALT1 = "campus visit";

    public static final String CONTACT_US = "contact us";
    public static final String CONTACT_US_ALT1 = "contact query";
    public static final String CONTACT_US_ALT2 = "contact";

    public static final String CAREER_VACANCY = "career and vacancies";
    public static final String CAREER_VACANCY_ALT1 = "career & vacancies";
    public static final String CAREER_VACANCY_ALT2 = "career vacancy";
    public static final String CAREER_VACANCY_ALT3 = "career opportunities";
}

package com.renaissance.app.util;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;

public class DateTimeUtil {

    public static Date addMilliseconds(Date date, long milliseconds) {
        return new Date(date.getTime() + milliseconds);
    }

    public static boolean isExpired(Date expiration) {
        return expiration.before(new Date());
    }
    
    public static Map<String, String> formatDateAndTime(LocalDate date, LocalTime time) {

        String formattedDate = date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String formattedTime = time.format(DateTimeFormatter.ofPattern("hh:mm a"));

        return Map.of(
                "date", formattedDate,
                "time", formattedTime
        );
    }

}
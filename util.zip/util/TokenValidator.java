package com.renaissance.app.util;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.renaissance.app.exception.UnauthorizedException;
import com.renaissance.app.model.enums.OtpType;
import com.renaissance.app.model.enums.TokenType;
import com.renaissance.app.util.constants.AppConstants;

@Component
public class TokenValidator {

    @Autowired private JwtUtils jwtUtils;

    public void validateAuthToken(String token, Set<OtpType> allowedOtpTypes) {
        if (token == null) throw new UnauthorizedException(AppConstants.MISSING_TOKEN);
        if (jwtUtils.isTokenExpired(token)) throw new UnauthorizedException(AppConstants.TOKEN_EXPIRED);

        TokenType tokenType = jwtUtils.extractTokenType(token);
        OtpType otpType = jwtUtils.extractOtpType(token);

        if (tokenType != TokenType.AUTH_TOKEN || !allowedOtpTypes.contains(otpType)) {
            throw new UnauthorizedException(AppConstants.INVALID_TOKEN_TYPE_FOR_VERIFICATION);
        }
    }
}

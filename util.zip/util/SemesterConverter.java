package com.renaissance.app.util;

import com.renaissance.app.model.enums.Semester;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false)
public class SemesterConverter implements AttributeConverter<Semester, Integer> {

    @Override
    public Integer convertToDatabaseColumn(Semester semester) {
        return semester == null ? null : semester.getValue();
    }

    @Override
    public Semester convertToEntityAttribute(Integer dbValue) {
        return Semester.fromValue(dbValue);
    }
}

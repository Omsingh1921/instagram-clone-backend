package com.renaissance.app.util;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.renaissance.app.config.DepartmentMailCredentials;
import com.renaissance.app.config.DynamicMailSenderFactory;
import com.renaissance.app.kafka.EmailAttachment;
import com.renaissance.app.model.EmailTemplate;
import com.renaissance.app.repository.EmailTemplateRepository;

import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;	

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailSenderService {
	
//	
	@Value("${app.hr.email:hr@renaissance.ac.in}")
	private String hrEmail;

    private final EmailTemplateRepository templateRepository;
    private final EmailTemplateEngine templateEngine;
    private final DepartmentMailCredentials mailCredentials;
    private final DynamicMailSenderFactory mailSenderFactory;

//    private final JavaMailSender defaultMailSender;

    @Value("${spring.mail.host}")
    private String smtpHost;

    @Value("${spring.mail.port}")
    private int smtpPort;

    @Value("${spring.mail.tls}")
    private boolean tls;
    
    @Value("${spring.mail.sender-name}")
    private String senderName;


    /**
     * Generic DB-template-based email sender with dynamic SMTP account.
     * This is invoked by Kafka consumer, NOT by controllers.
     */
    public void sendTemplateEmail(String templateKey, String toEmail, Map<String, String> variables) {

        EmailTemplate template = templateRepository
                .findByTemplateKeyAndActiveTrue(templateKey)
                .orElseThrow(() -> new IllegalArgumentException("Email template not found: " + templateKey));
        
        
        String subject = templateEngine.render(template.getSubject(), variables);
        String body = templateEngine.render(template.getHtmlTemplate(), variables);

        DepartmentMailCredentials.Credential creds =
                mailCredentials.get(template.getSmtpCredentialKey());

        if (!template.getFromEmail().equalsIgnoreCase(creds.getUsername())) {
            throw new IllegalStateException("FROM email (" + template.getFromEmail() +
                    ") does not match SMTP username (" + creds.getUsername() + ")");
        }

        JavaMailSender sender = mailSenderFactory.create(
                smtpHost, smtpPort, creds.getUsername(), creds.getPassword(), tls
        );

        try {
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(toEmail);
//            helper.setFrom(creds.getUsername());
            helper.setFrom(
            	    creds.getUsername(),
            	    senderName
            	);

            helper.setSubject(subject);
            helper.setText(body, true);

            sender.send(message);

        } catch (Exception e) {
            throw new RuntimeException("Failed to send template email (" + templateKey + ") to " + toEmail, e);
        }
    }


    public void sendTemplateEmailWithAttachment(
            String templateKey,
            String toEmail,
            Map<String, String> variables,
            List<EmailAttachment> attachments
    ) {

        EmailTemplate template = templateRepository
                .findByTemplateKeyAndActiveTrue(templateKey)
                .orElseThrow(() ->
                        new IllegalArgumentException("Email template not found: " + templateKey));
        

        String subject = templateEngine.render(template.getSubject(), variables);
        String body = templateEngine.render(template.getHtmlTemplate(), variables);

        DepartmentMailCredentials.Credential creds =
                mailCredentials.get(template.getSmtpCredentialKey());
       

        if (!template.getFromEmail().equalsIgnoreCase(creds.getUsername())) {
            throw new IllegalStateException(
                    "FROM email (" + template.getFromEmail() +
                    ") does not match SMTP username (" + creds.getUsername() + ")"
            );
        }

        JavaMailSender sender = mailSenderFactory.create(
                smtpHost,
                smtpPort,
                creds.getUsername(),
                creds.getPassword(),
                tls
        );

        try {
            MimeMessage message = sender.createMimeMessage();

            // true = multipart → REQUIRED for attachments
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(toEmail);
//            helper.setFrom(creds.getUsername());
            helper.setFrom(
            	    creds.getUsername(),
            	    senderName
            	);
            
            helper.setSubject(subject);
            helper.setText(body, true);

            // ==========================
            // ATTACHMENTS (THIS IS THE POINT)
            // ==========================
            if (attachments != null && !attachments.isEmpty()) {
                for (EmailAttachment attachment : attachments) {
                    helper.addAttachment(
                            attachment.fileName(),
                            new ByteArrayResource(attachment.data()),
                            attachment.contentType()
                    );
                }
            }

            sender.send(message);

            System.err.println("sent successfully");
        } catch (Exception e) {
        	
            throw new RuntimeException(
                    "Failed to send template email (" + templateKey + ") to " + toEmail,
                    e
            );
        }
    }
    
    public void sendReturnMail(
            String templateKey,
            Map<String, String> variables
    ) {
        sendReturnMail(templateKey, variables, List.of());
    }

    public void sendReturnMail(
            String templateKey,
            Map<String, String> variables,
            List<EmailAttachment> attachments
    ) {

        EmailTemplate template = templateRepository
                .findByTemplateKeyAndActiveTrue(templateKey)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Email template not found: " + templateKey));

        // Skip if no return template
        if (template.getReturnTemplate() == null ||
            template.getReturnSubject() == null) {
            return;
        }

        String subject = templateEngine.render(
                template.getReturnSubject(), variables);

        String body = templateEngine.render(
                template.getReturnTemplate(), variables);

        DepartmentMailCredentials.Credential creds =
                mailCredentials.get(template.getSmtpCredentialKey());

        if (!template.getFromEmail()
                .equalsIgnoreCase(creds.getUsername())) {

            throw new IllegalStateException(
                "FROM email does not match SMTP user");
        }

        JavaMailSender sender = mailSenderFactory.create(
                smtpHost,
                smtpPort,
                creds.getUsername(),
                creds.getPassword(),
                tls
        );

        try {
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper =
                    new MimeMessageHelper(message, true);

            // ✅ CONDITIONAL ROUTING
            if ("CAREER_VACANCY".equals(templateKey)||
                    "IN_HOUSE_INTERNSHIP".equals(templateKey)) {
//                helper.setTo(hrEmail); // send to HR only
            	
            	helper.setTo(template.getFromEmail());
            	helper.setCc(hrEmail);
            } else {
                helper.setTo(template.getFromEmail()); // default behavior
            }

            helper.setFrom(
                    creds.getUsername(),
                    senderName
            );

            helper.setSubject(subject);
            helper.setText(body, true);

            if (attachments != null && !attachments.isEmpty()) {
                for (EmailAttachment att : attachments) {
                    helper.addAttachment(
                            att.fileName(),
                            new ByteArrayResource(att.data()),
                            att.contentType()
                    );
                }
            }

            sender.send(message);

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to send return mail for " + templateKey, e);
        }
    }

    public void sendInternalUserLeadMail(String toEmail, Map<String, String> vars) {

        try {

            System.out.println("Sending internal mail to: " + toEmail);

            DepartmentMailCredentials.Credential creds = mailCredentials.get("enquiry");

            System.out.println("SMTP User: " + creds.getUsername());

            JavaMailSender sender = mailSenderFactory.create(
                    smtpHost,
                    smtpPort,
                    creds.getUsername(),
                    creds.getPassword(),
                    tls
            );

            String body = buildInternalLeadHtml(vars);

            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(toEmail);
            helper.setFrom(creds.getUsername());
            helper.setSubject("You have received a new lead");
            helper.setText(body, true);

//            if (hrEmail != null && !hrEmail.isBlank()) {
//                helper.setCc(hrEmail);
//            }

            sender.send(message);

            System.out.println("Mail sent successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    
    
    private String buildInternalLeadHtml(Map<String, String> vars) {
        String userName = safe(vars.get("user_name"));
        String studentName = safe(vars.get("student_name"));
        String fullName = safe(vars.get("full_name"));
        String email = safe(vars.get("email"));
        String mobile = safe(vars.get("mobile_number"));
        String city = safe(vars.get("city"));
        String courseName = safe(vars.get("course_name"));
        String programName = safe(vars.get("program_name"));
        String perDayFee = safe(vars.get("per_day_fee"));
        String feesPerYear = safe(vars.get("fees_per_year"));
        String coursePageLink = safe(vars.get("course_page_link"));

        return """
            <html>
            <body style="font-family: Arial, sans-serif; color: #333; line-height: 1.6; background-color: #f7f7f7; padding: 20px;">
                <div style="max-width: 700px; margin: 0 auto; background: #ffffff; padding: 24px; border-radius: 10px; border: 1px solid #e5e5e5;">
                    <h2 style="margin-top: 0;">Hello %s,</h2>

                    <p>You have received a new lead for your assigned school program.</p>

                    <table style="width: 100%%; border-collapse: collapse; margin-top: 20px;">
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Student Name</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Full Name</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Email</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Mobile Number</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>City</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Course</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Program</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Per Day Fee</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Total Fee</strong></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">%s</td>
                        </tr>
                    </table>

                    <p style="margin-top: 20px;">
                        <strong>Course Page:</strong>
                        <a href="%s" target="_blank">%s</a>
                    </p>

                    <p style="margin-top: 20px;">Please follow up with the student.</p>

                    <p>Regards,<br/>Admissions Team</p>
                </div>
            </body>
            </html>
            """.formatted(
                userName,
                studentName,
                fullName,
                email,
                mobile,
                city,
                courseName,
                programName,
                perDayFee,
                feesPerYear,
                coursePageLink,
                coursePageLink
            );
    }
    
    private String safe(String value) {
        return value == null ? "" : value;
    }

}
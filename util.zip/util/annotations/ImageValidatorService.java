package com.renaissance.app.util.annotations;

import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ImageValidatorService implements ConstraintValidator<ImageValidator, Object> {

    private boolean required;

    private static final Set<String> ALLOWED_CONTENT_TYPES = Set.of(
            "image/jpeg",
            "image/jpg",
            "image/png",
            "image/webp"
    );

    @Override
    public void initialize(ImageValidator annotation) {
        this.required = annotation.required();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {

        if (value == null) {
            return !required;
        }

        // Single file
        if (value instanceof MultipartFile file) {
            return isValidImage(file);
        }

        // List of files
        if (value instanceof List<?> list) {
            for (Object obj : list) {
                if (!(obj instanceof MultipartFile file)) return false;
                if (!isValidImage(file)) return false;
                
            }
            return true;
        }

        return false;
    }

    private boolean isValidImage(MultipartFile file) {

        if (file.isEmpty()) {
            return !required; // empty allowed only if not required
        }

        String contentType = file.getContentType();
        return contentType != null && ALLOWED_CONTENT_TYPES.contains(contentType.toLowerCase());
    }
}

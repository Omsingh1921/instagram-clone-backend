package com.renaissance.app.util;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.renaissance.app.exception.BadRequestException;
import com.renaissance.app.exception.ResourceAlreadyExistException;
import com.renaissance.app.model.EndPoints;
import com.renaissance.app.model.enums.EndpointType;
import com.renaissance.app.repository.EndPointsRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EndpointRegistrar {

    private final EndPointsRepository endPointsRepository;

    @Transactional
    public EndPoints register(String slug, EndpointType type, String referenceId) {
        if (slug.contains("/")) {
            throw new BadRequestException("Top-level endpoint cannot contain '/'");
        }

        endPointsRepository.findBySlug(slug).ifPresent(e -> {
            throw new ResourceAlreadyExistException("Slug already exists: " + slug);
        });

        EndPoints endPoint = EndPoints.builder()
                .slug(slug)
                .type(type)
                .referenceId(referenceId)
                .build();

        return endPointsRepository.save(endPoint);
    }
    public EndPoints registerIfAbsent(
            String slug,
            EndpointType type,
            String referenceId
    ) {
        return endPointsRepository
                .findBySlug(slug)
                .orElseGet(() -> endPointsRepository.save(
                        EndPoints.builder()
                                .slug(slug)
                                .type(type)
                                .referenceId(referenceId)
                                .build()
                ));
    }
}

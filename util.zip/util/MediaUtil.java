package com.renaissance.app.util;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifIFD0Directory;
import com.renaissance.app.service.IS3StorageService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class MediaUtil {

    private static final long MAX_IMAGE_PIXELS = 40_000_000L;
    private static final long MAX_PDF_BYTES = 50L * 1024 * 1024; // 50 MB
    private static final int MAX_PDF_PAGES = 200;

    private final IS3StorageService storageService;

    // ==================== MAIN UPLOAD ====================

    public String processAndUploadMedia(MultipartFile file, String folder) {

        if (file == null || file.isEmpty()) {
            return null;
        }

        String originalName = file.getOriginalFilename();
        if (originalName == null || !originalName.contains(".")) {
            throw new IllegalArgumentException("Invalid filename");
        }

        String baseName = sanitizePublicId(
                originalName.substring(0, originalName.lastIndexOf('.'))
        );

        try {
            byte[] bytes = file.getBytes();
            MediaResult result = processMedia(bytes);

            return storageService.uploadFile(
                    result.bytes(),
                    baseName,
                    folder,
                    result.extension()
            );

        } catch (IOException e) {
            throw new RuntimeException("Media processing failed", e);
        }
    }

    public String processAndUploadMedia(File file, String folder) {

        if (file == null || !file.exists() || file.length() == 0) {
            return null;
        }

        try {
            byte[] bytes = Files.readAllBytes(file.toPath());
            MediaResult result = processMedia(bytes);

            String baseName = sanitizePublicId(
                    file.getName().replaceFirst("[.][^.]+$", "")
            );

            return storageService.uploadFile(
                    result.bytes(),
                    baseName,
                    folder,
                    result.extension()
            );

        } catch (IOException e) {
            throw new RuntimeException("Media processing failed", e);
        }
    }

    // ==================== MEDIA ROUTER ====================

    private MediaResult processMedia(byte[] bytes) throws IOException {
        if (isPdf(bytes)) {
            return processPdf(bytes);
        }
        ImageResult img = processImage(bytes);
        return new MediaResult(img.bytes(), img.extension());
    }

    private boolean isPdf(byte[] bytes) {
        return bytes.length >= 4
                && bytes[0] == '%'
                && bytes[1] == 'P'
                && bytes[2] == 'D'
                && bytes[3] == 'F';
    }

    // ==================== PDF PROCESSING ====================

    private MediaResult processPdf(byte[] bytes) throws IOException {

        if (bytes.length > MAX_PDF_BYTES) {
            throw new IllegalArgumentException("PDF too large");
        }

        try (
            ByteArrayInputStream in = new ByteArrayInputStream(bytes);
            PDDocument doc = PDDocument.load(in, MemoryUsageSetting.setupTempFileOnly())
        ) {
            if (doc.getNumberOfPages() > MAX_PDF_PAGES) {
                throw new IllegalArgumentException("PDF has too many pages");
            }

            doc.setAllSecurityToBeRemoved(true);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            doc.save(baos);

            return new MediaResult(baos.toByteArray(), "pdf");
        }
    }

    // ==================== IMAGE PROCESSING ====================

    private record ImageResult(byte[] bytes, String extension) {}
    private record MediaResult(byte[] bytes, String extension) {}

    private ImageResult processImage(byte[] bytes) throws IOException {

        BufferedImage image = decode(bytes);

        long pixels = (long) image.getWidth() * image.getHeight();
        if (pixels > MAX_IMAGE_PIXELS) {
            throw new IllegalArgumentException(
                    "Image too large: " + image.getWidth() + "x" + image.getHeight()
            );
        }

        image = applyExifOrientation(bytes, image);

        if (image.getColorModel().hasAlpha()) {
            return new ImageResult(encodePng(image), "png");
        }

        BufferedImage rgb = normalizeToRGB(image);
        return new ImageResult(
                encodeProgressiveJpeg(rgb, 0.7f),
                "jpg"
        );
    }

    // ==================== HELPERS ====================

    private String sanitizePublicId(String input) {
        if (input == null || input.isBlank())
            return "file_" + System.currentTimeMillis();

        return input.replaceAll("[^a-zA-Z0-9-_]", "_")
                .replaceAll("_+", "_")
                .replaceAll("^_|_$", "")
                .toLowerCase();
    }

  /**
  * Use metadata-extractor to read EXIF orientation from a fresh stream created from bytes.
  * If metadata is missing or any problem occurs, return original image.
  */
 private BufferedImage applyExifOrientation(byte[] bytes, BufferedImage image) {
     try (ByteArrayInputStream metaStream = new ByteArrayInputStream(bytes)) {
         Metadata metadata = ImageMetadataReader.readMetadata(metaStream);
         Directory directory = metadata.getFirstDirectoryOfType(ExifIFD0Directory.class);
         if (directory == null || !directory.containsTag(ExifIFD0Directory.TAG_ORIENTATION)) {
             return image;
         }

         int orientation;
         try {
             orientation = directory.getInt(ExifIFD0Directory.TAG_ORIENTATION);
         } catch (Exception e) {
             log.debug("Failed to read orientation tag", e);
             return image;
         }

         switch (orientation) {
             case 6: // Rotate 90 CW
                 return rotate(image, 90);
             case 3: // Rotate 180
                 return rotate(image, 180);
             case 8: // Rotate 270 CW
                 return rotate(image, 270);
             default:
                 return image;
         }
     } catch (Exception e) {
         // Something went wrong reading metadata — fallback to original image
         log.debug("Failed to read EXIF metadata; skipping orientation. Reason: {}", e.getMessage());
         return image;
     }
 }
 
private BufferedImage rotate(BufferedImage img, int degrees) {

   double radians = Math.toRadians(degrees);
   double sin = Math.abs(Math.sin(radians));
   double cos = Math.abs(Math.cos(radians));

   int w = img.getWidth();
   int h = img.getHeight();

   int newW = (int) Math.floor(w * cos + h * sin);
   int newH = (int) Math.floor(h * cos + w * sin);

   int type = img.getColorModel().hasAlpha()
           ? BufferedImage.TYPE_INT_ARGB
           : BufferedImage.TYPE_INT_RGB;

   BufferedImage rotated = new BufferedImage(newW, newH, type);
   Graphics2D g = rotated.createGraphics();

   try {
       if (!img.getColorModel().hasAlpha()) {
           g.setColor(Color.WHITE);
           g.fillRect(0, 0, newW, newH);
       }

       g.translate(newW / 2.0, newH / 2.0);
       g.rotate(radians);
       g.translate(-w / 2.0, -h / 2.0);
       g.drawImage(img, 0, 0, null);
   } finally {
       g.dispose();
   }

   return rotated;
}
    private BufferedImage decode(byte[] bytes) throws IOException {
        try (ByteArrayInputStream in = new ByteArrayInputStream(bytes)) {
            BufferedImage image = ImageIO.read(in);
            if (image == null) {
                throw new IOException("Unsupported image format");
            }
            return image;
        }
    }

    private BufferedImage normalizeToRGB(BufferedImage image) {

        if (!image.getColorModel().hasAlpha()
                && image.getType() == BufferedImage.TYPE_INT_RGB) {
            return image;
        }

        BufferedImage rgb = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB
        );

        Graphics2D g = rgb.createGraphics();
        try {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, rgb.getWidth(), rgb.getHeight());
            g.drawImage(image, 0, 0, null);
        } finally {
            g.dispose();
        }
        return rgb;
    }

    private byte[] encodePng(BufferedImage image) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos);
        return baos.toByteArray();
    }

    private byte[] encodeProgressiveJpeg(BufferedImage img, float quality) throws IOException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();

        try (ImageOutputStream ios = ImageIO.createImageOutputStream(baos)) {
            writer.setOutput(ios);
            ImageWriteParam param = writer.getDefaultWriteParam();
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(quality);
            param.setProgressiveMode(ImageWriteParam.MODE_DEFAULT);
            writer.write(null, new IIOImage(img, null, null), param);
            return baos.toByteArray();
        } finally {
            writer.dispose();
        }
    }
    
}
/**
 * 
 */
package com.renaissance.app.dto.request;

import lombok.Data;

@Data
public class RefundRequest {
    private Double amount;
    private String reason;
}

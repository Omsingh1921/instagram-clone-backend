package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TrimValidator
public class ResetPasswordRequest {

    @NotBlank(message = ValidationConstants.NEW_PASSWORD_REQUIRED)
    @Size(
        min = ValidationConstants.PASSWORD_MIN_LENGTH,
        max = ValidationConstants.PASSWORD_MAX_LENGTH,
        message = ValidationConstants.PASSWORD_SIZE_MESSAGE
    )
    @Pattern(
        regexp = ValidationConstants.PASSWORD_PATTERN,
        message = ValidationConstants.PASSWORD_PATTERN_MESSAGE
    )
    private String newPassword;
}

package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class StoryAndPicturesRequest {

	@NotBlank(message = "Title is required")
	@Size(max = 150, message = "Title cannot exceed 150 characters")
	private String title;

	@NotBlank(message = "Preview content is required")
	@Size(max = 500, message = "Preview content cannot exceed 500 characters")
	private String previewContent;

	@NotBlank(message = "Detailed content is required")
	private String detailedContent;

//	@NotBlank(message = "Publisher name is required")
//	@Size(max = 100, message = "Publisher name cannot exceed 100 characters")
//	private String publisher;

	private Boolean isActive;
//
//	@NotBlank(message = "Location is required")
//	@Size(max = 100, message = "Location cannot exceed 100 characters")
//	private String location;

//	private String categoryId;

//	@NotNull(message = "Story date is required")
//	private LocalDate storyDate;
//
//    @NotNull(message = "Story time is required")
//    private LocalTime storyTime;

	@NotNull(message = "Thumbnail file is required")
	  @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile thumbnailFile;

	@NotBlank(message = "Thumbnail alt text is required")
	@Size(max = 255, message = "Alt text cannot exceed 255 characters")
	private String thumbnailAltText;

	@Builder.Default
	@Size(max = 10, message = "You can upload up to 10 gallery images")
	private List<MultipartFile> galleryFiles = new ArrayList<>();

	@Valid
	private SeoConfigRequest seoConfig;
}

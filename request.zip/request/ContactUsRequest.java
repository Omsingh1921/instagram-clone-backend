package com.renaissance.app.dto.request;

import java.util.HashSet;
import java.util.Set;

import com.renaissance.app.model.ContactUs;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ContactUsRequest {

	@NotBlank(message = ValidationConstants.NAME_REQUIRED)
	@Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
	private String name;

	// Multiple phone numbers
	@Builder.Default
	private Set<String> phones = new HashSet<>();

	// Multiple emails
	@Builder.Default
	private Set<ContactUs.Email> emails = new HashSet<>();

	// Multiple addresses
	@Builder.Default
	private Set<ContactUs.Address> addresses = new HashSet<>();

	@Size(max = 1000, message = ValidationConstants.ADDITIONAL_INFO_MAX_LENGTH)
	private String additionalInfo;
}

package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class EligibilityItemsUpdateRequest {

	private String itemId; // 🔴 REQUIRED for update

	private String itemTitle;
	private String itemDescription;
	private MultipartFile mediaFile;
	private String mediaAltText;
}

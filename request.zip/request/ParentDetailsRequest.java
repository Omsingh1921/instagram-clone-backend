package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.UUIDValidator;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ParentDetailsRequest {

	@NotBlank(message = "Father's name is required.")
	@Size(max = 100, message = "Father's name cannot exceed 100 characters.")
	private String fatherName;
	
	@NotBlank
	@UUIDValidator
	private String registrationId;

	@Size(max = 100, message = "Father's occupation cannot exceed 100 characters.")
	private String fatherOccupation;

	@NotBlank(message = "Mother's name is required.")
	@Size(max = 100, message = "Mother's name cannot exceed 100 characters.")
	private String motherName;

	@Size(max = 100, message = "Mother's occupation cannot exceed 100 characters.")
	private String motherOccupation;

	@NotBlank(message = "Parent contact number is required.")
	@Pattern(regexp = "^[0-9]{7,15}$", message = "Parent contact must be between 7 and 15 digits.")
	private String parentContact;
}

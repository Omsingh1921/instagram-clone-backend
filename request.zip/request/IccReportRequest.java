package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class IccReportRequest {

    @NotBlank(message = "Full name is required")
    @Size(max = 100)
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email
    @Size(max = 150)
    private String email;

    @NotBlank(message = "Course category is required")
    @Size(max = 100)
    private String courseCategory;

    @NotBlank(message = "Course is required")
    @Size(max = 100)
    private String course;

    @NotBlank(message = "Description is required")
    @Size(min = 150, message = "Minimum 30 words required")
    private String description;
    // Uploaded image
    @NotNull(message = "Image is required")
    private MultipartFile imageFile;
}

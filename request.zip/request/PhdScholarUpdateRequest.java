package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class PhdScholarUpdateRequest {

    private String name;
    private String title;
    private Integer year;
    private String programId;
    private MultipartFile imageFile;
    private String altText;
    private Boolean isActive;
}
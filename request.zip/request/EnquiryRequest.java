package com.renaissance.app.dto.request;

import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnquiryRequest implements ActivityPayload {

    @NotBlank(message = ValidationConstants.NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
    private String fullName;

    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    @Email(message = ValidationConstants.EMAIL_PATTERN_MESSAGE)
    @Size(max = 150, message = ValidationConstants.EMAIL_MAX_LENGTH)
    private String email;

    @NotBlank(message = ValidationConstants.MOBILE_NUMBER_REQUIRED)
    @Pattern(regexp = ValidationConstants.PHONE_PATTERN, message = ValidationConstants.PHONE_PATTERN_MESSAGE)
    @Size(max = 20, message = ValidationConstants.PHONE_MAX_LENGTH)
    private String contactNumber;

    @Size(max = 100, message = ValidationConstants.CITY_MAX_LENGTH)
    private String city;

    @NotBlank(message = ValidationConstants.COURSE_ID_REQUIRED)
    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String courseId;

    @NotNull(message = ValidationConstants.MSG_NOT_NULL)
    private Boolean isWhatsappSame;
}

package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.CourseDuration;
import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class CourseRequest {

    @NotBlank(message = ValidationConstants.COURSE_NAME_REQUIRED)
    @Size(max = 200, message = ValidationConstants.COURSE_NAME_LENGTH)
    private String name;

    @Pattern(
        regexp = "^[a-z0-9]+(?:-[a-z0-9]+)*$",
        message = ValidationConstants.COURSE_ENDPOINT_INVALID
    )
    private String endpoint;

    @NotNull(message = ValidationConstants.DURATION_REQUIRED)
    private CourseDuration duration;


    @NotNull(message = ValidationConstants.COURSE_START_DATE_REQUIRED)
    private String courseStartDate;

    @NotBlank(message = ValidationConstants.COURSE_TYPE_REQUIRED)
    @Size(max = 500, message = ValidationConstants.COURSE_TYPE_MAX_LENGTH)
    private String courseType;

    private MultipartFile brochureFile;
    
    private MultipartFile feeStructureBrochureFile;

    @Size(max = 500, message = ValidationConstants.SHORT_DESCRIPTION_MAX_LENGTH)
    private String shortDescription;

    @Size(max = 500, message = ValidationConstants.LONG_DESCRIPTION_MAX_LENGTH)
    private String longDescription;

    @NotBlank(message = ValidationConstants.SCHOOL_PROGRAM_ID_REQUIRED)
    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String schoolProgramId;

    private Boolean isActive;

    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile thumbnailFile;

    @Size(max = 300, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String thumbnailAltText;

    // --- Nested sections ---
    @Valid
    private PromoSectionRequest promoSection;

    @Valid
    private UniqueSellingPointRequest uniqueSellingPoint;

    @Valid
    //required
    @NotNull(message = ValidationConstants.ELIGIBILITY_REQUIRED)
    private CourseEligibilityRequest eligibilities;

    @Valid
    @Builder.Default
    private List<FeeRequest> fees = new ArrayList<>();

    @Valid
    @NotNull(message = ValidationConstants.FUTURE_OPPORTUNITY_REQUIRED)
    private FutureOpportunityRequest futureOpportunity;

    @Valid
    @NotNull(message = ValidationConstants.SEO_CONFIG_REQUIRED)
    private SeoConfigRequest seoConfigRequest;

    @Valid
    @Builder.Default
    private List<CourseSubjectBindingRequest> subjects = new ArrayList<>();
    
    @DecimalMin(value = "0.0", inclusive = true, message = "Registration fee cannot be negative")
    @DecimalMax(value = "1000000.0", message = "Registration fee exceeds allowed limit")
    private Double registrationFee;
}

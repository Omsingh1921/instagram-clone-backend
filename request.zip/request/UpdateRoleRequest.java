package com.renaissance.app.dto.request;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateRoleRequest {

    @NotBlank(message = ValidationConstants.ROLE_NAME_REQUIRED)
    @Size(min = 3, max = 50, message = ValidationConstants.ROLE_NAME_SIZE)
    private String role;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    @Size(min = 5, max = 200, message = ValidationConstants.DESCRIPTION_SIZE)
    private String description;
}

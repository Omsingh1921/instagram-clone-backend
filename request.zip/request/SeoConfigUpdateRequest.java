package com.renaissance.app.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SeoConfigUpdateRequest {

    @NotBlank(message = "Meta title is required")
    @Size(max = 255, message = "Meta title must be at most 255 characters")
    private String metaTitle;

    @Size(max = 500, message = "Meta keywords must be at most 500 characters")
    private String metaKeywords;

    @Size(max = 1000, message = "Meta description must be at most 1000 characters")
    private String metaDescription;
}

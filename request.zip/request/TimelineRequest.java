package com.renaissance.app.dto.request;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TimelineRequest {

    @NotNull(message = ValidationConstants.TIMELINE_YEAR_REQUIRED)
    @Min(value = 1900, message = ValidationConstants.TIMELINE_YEAR_INVALID)
    private Integer year;

    private Boolean isActive;
}

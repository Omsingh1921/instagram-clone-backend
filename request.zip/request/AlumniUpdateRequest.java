package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class AlumniUpdateRequest {

	@Size(max = 100, message = ValidationConstants.ALUMNI_NAME_MAX_LENGTH)
	private String name;

	private MultipartFile imageFile; // optional — update only if provided

	@Size(max = 150, message = ValidationConstants.ALUMNI_ALT_TEXT_MAX_LENGTH)
	private String altText;

	private Boolean isActive; // optional — can toggle active status
	
	private Integer year;
	
	private String programId;
	private String courseId;

	@Size(max = 150, message = ValidationConstants.COMPANY_NAME_MAX_LENGTH)
	private String companyName;

	@Size(max = 100, message = ValidationConstants.DESIGNATION_MAX_LENGTH)
	private String designation;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class PaginationRequest {

	@NotNull(message = ValidationConstants.PAGE_SIZE_REQUIRED)
	@Min(value = 1, message = "Page size must be a positive integer greater than 0.")
	@Builder.Default
	private Integer pageSize = 10;
	@Builder.Default
	@NotNull(message = ValidationConstants.PAGE_INDEX_REQUIRED)
	@Min(value = 0, message = "Page number must be 0 or a positive integer.") // if pageNumber is 0-based
	private Integer pageNumber = 0;

	@Pattern(regexp = ValidationConstants.SORT_ORDER_PATTERN, message = ValidationConstants.SORT_ORDER_PATTERN_MESSAGE)
	@Builder.Default
	private String sortDirection = "DESC";

	private String sortKey;
	private String searchValue;

}
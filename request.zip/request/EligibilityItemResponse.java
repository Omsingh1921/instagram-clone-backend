package com.renaissance.app.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EligibilityItemResponse {
    private String itemId;
    private String itemTitle;
    private String itemDescription;
    private String mediaUrl;
}

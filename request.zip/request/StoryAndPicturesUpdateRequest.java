package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StoryAndPicturesUpdateRequest {
//
//    @NotNull(message = "Story ID is required for update")
//    private String id;

    @Size(max = 150, message = "Title cannot exceed 150 characters")
    private String title;

    @Size(max = 500, message = "Preview content cannot exceed 500 characters")
    private String previewContent;

    private String detailedContent;
    
    private Boolean isActive;

//    @Size(max = 100, message = "Publisher name cannot exceed 100 characters")
//    private String publisher;
//
//    @Size(max = 100, message = "Location cannot exceed 100 characters")
//    private String location;

//    @Pattern(
//        regexp = "^[0-9a-fA-F-]{36}$",
//        message = "Invalid category ID format (must be UUID)"
//    )
//    private String categoryId;

//   private LocalDate storyDate;

//    private LocalTime storyTime;

    // Thumbnail is optional during update
    private MultipartFile thumbnailFile;

    @Size(max = 255, message = "Alt text cannot exceed 255 characters")
    private String thumbnailAltText;

    @Builder.Default
    @Size(max = 10, message = "You can upload up to 10 gallery images")
    private List<MultipartFile> galleryFiles = new ArrayList<>();

    // Optional field to track removed gallery image IDs
    private List<String> removedGalleryIds;
    

    private SeoConfigRequest seoConfigRequest;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.GenderType;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FriendRequest {

    @NotBlank(message = "Friend name is required")
    private String name;

    @Email(message = "Invalid friend email format")
    private String email;

    @Pattern(regexp = "^[0-9]{7,15}$", message = "Friend phone number must be between 7 and 15 digits")
    private String phone;
    
    private GenderType gender;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class RefreshTokenRequest {

    @NotBlank(message = ValidationConstants.USERNAME_REQUIRED)
    private String username;

    @NotBlank(message = ValidationConstants.REFRESH_TOKEN_REQUIRED)
    private String refreshToken;
}

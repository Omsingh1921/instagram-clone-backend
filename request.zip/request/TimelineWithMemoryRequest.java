package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class TimelineWithMemoryRequest {

    @NotNull(message = ValidationConstants.TIMELINE_YEAR_REQUIRED)
    @Min(value = 1900, message = ValidationConstants.TIMELINE_YEAR_INVALID)
    private Integer year;

    @NotBlank(message = ValidationConstants.TIMELINE_MEMORY_TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TIMELINE_MEMORY_TITLE_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.TIMELINE_MEMORY_DESCRIPTION_REQUIRED)
    private String description;

    private MultipartFile imageFile;

    @Size(max = 150, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String imageAltText;

    private Boolean isDefault;

    private Boolean isActive;
}

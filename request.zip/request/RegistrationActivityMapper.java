package com.renaissance.app.dto.request;

import com.renaissance.app.model.StudentRegistration;

public final class RegistrationActivityMapper {

    private RegistrationActivityMapper() {}

    public static RegistrationActivityRequest from(StudentRegistration reg) {

        return RegistrationActivityRequest.builder()
                .registrationId(reg.getRegistrationId())
                .fullName(reg.getFullName())
                .email(reg.getEmail())
                .phone(reg.getContactNumber())
                .gender(reg.getGender())
                .city(reg.getCity())
                .state(reg.getState())
                .courseId(
                        reg.getCourse() != null
                                ? reg.getCourse().getCourseId()
                                : null
                )
                .programId(
                        reg.getSchoolProgram() != null
                                ? reg.getSchoolProgram().getProgramId()
                                : null
                )
                .paymentStatus(
                        reg.getPayment() != null
                                ? reg.getPayment().getPaymentStatus().name()
                                : null
                )
                .orderId(
                        reg.getPayment() != null
                                ? reg.getPayment().getTransactionId()
                                : null
                )
                .build();
    }
}

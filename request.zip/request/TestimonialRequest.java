package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class TestimonialRequest {

	@NotBlank(message = ValidationConstants.CONTENT_REQUIRED)
	@Size(max = 1000, message = ValidationConstants.CONTENT_MAX_LENGTH)
	private String content;

	@NotBlank(message = ValidationConstants.AUTHOR_NAME_REQUIRED)
	@Size(max = 100, message = ValidationConstants.AUTHOR_NAME_MAX_LENGTH)
	private String authorName;

	private String email;

	@NotNull(message = ValidationConstants.IMAGE_REQUIRED)
	@ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile authorProfile; // optional

	@NotBlank(message = ValidationConstants.COURSE_ID_REQUIRED)
	@UUIDValidator
	private String courseId;

	@NotBlank(message = ValidationConstants.SCHOOL_PROGRAM_ID_REQUIRED)
	@UUIDValidator
	private String schoolProgramId;
}
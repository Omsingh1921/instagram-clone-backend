package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class FacultyUpdateRequest {

    @Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
    private String name;

    @Size(max = 100, message = ValidationConstants.DESIGNATION_MAX_LENGTH)
    private String designation;

    @Size(max = 1000, message = ValidationConstants.BIO_MAX_LENGTH)
    private String bio;

    @Email(message = ValidationConstants.INVALID_EMAIL)
    private String email;
    
    private Boolean isActive;

    private MultipartFile profileImage;

    @Builder.Default
    @Size(min = 1, message = ValidationConstants.SCHOOL_PROGRAM_ID_REQUIRED)
    private List<@NotBlank String> schoolProgramIds = new ArrayList<>();
}

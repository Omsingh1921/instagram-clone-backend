package com.renaissance.app.dto.request;
import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class SchoolProgramUpdateRequest {

	@NotBlank(message = ValidationConstants.NAME_REQUIRED)
	@Size(max = 200, message = "Name must be at most 200 characters")
	private String name;

	@NotBlank(message = "Endpoint is required")
	@Size(max = 200, message = "Endpoint must be at most 200 characters")
	private String endpoint; // NEW FIELD: unique program slug

	@Size(max = 500, message = ValidationConstants.SHORT_DESCRIPTION_MAX_LENGTH)
	private String shortDescription;
	
	private Boolean isActive;

	@Valid
	@NotNull(message = "PromoSection is required")
	private PromoSectionUpdateRequest promoSection;

	@Valid
	@NotNull(message = "UniqueSellingPoint is required")
	private UniqueSellingPointUpdateRequest uniqueSellingPoint;
	
	@Valid
	private SeoConfigRequest seoConfigRequest;
	
    private MultipartFile icon;
    
    private String iconAltText;

	
	//seo updation leftt
}

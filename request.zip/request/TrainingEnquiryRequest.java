package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class TrainingEnquiryRequest {

    @NotBlank(message = ValidationConstants.NAME_REQUIRED)
    @Size(max = 100)
    private String fullName;

    @NotBlank(message = "Course is required")
    @Size(max = 150)
    private String course;

    @NotBlank(message = "Phone number is required")
    @Size(max = 20)
    private String phone;

    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    @Email(message = ValidationConstants.INVALID_EMAIL)
    @Size(max = 150)
    private String email;

    @NotBlank(message = "City is required")
    @Size(max = 100)
    private String city;
}

package com.renaissance.app.dto.request;


import java.time.DayOfWeek;
import java.time.LocalTime;

import org.springframework.format.annotation.DateTimeFormat;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounsellorAvailabilityRequest {

    @NotNull(message = ValidationConstants.AVAILABILITY_DAY_REQUIRED)
    private DayOfWeek dayOfWeek;

    @NotNull(message = ValidationConstants.AVAILABILITY_START_TIME_REQUIRED)
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime startTime;

    @NotNull(message = ValidationConstants.AVAILABILITY_END_TIME_REQUIRED)
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime endTime;

    @AssertTrue(message = ValidationConstants.AVAILABILITY_TIME_ORDER_INVALID)
    public boolean isEndTimeAfterStartTime() {
        return startTime != null && endTime != null && endTime.isAfter(startTime);
    }
}

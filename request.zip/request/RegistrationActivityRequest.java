package com.renaissance.app.dto.request;

import com.renaissance.app.service.ActivityPayload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegistrationActivityRequest implements ActivityPayload {

    private String registrationId;

    private String fullName;
    private String email;
    private String phone;
    private String gender;

    private String city;
    private String state;

    private String courseId;
    private String programId;

    private String paymentStatus;
    private String orderId;
}

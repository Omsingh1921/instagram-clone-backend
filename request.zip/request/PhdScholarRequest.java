package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class PhdScholarRequest {

    @NotBlank(message = ValidationConstants.FULL_NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.NAME_LENGTH_100)
    private String name;

    @NotBlank(message = "Title is required.")
    @Size(max = 200, message = "Title cannot exceed 200 characters.")
    private String title;

    @NotNull(message = "Year is required.")
    @Min(value = 1900, message = "Year must be valid.")
    @Max(value = 2100, message = "Year must be valid.")
    private Integer year;

    @NotBlank(message = ValidationConstants.PROGRAM_ID_REQUIRED)
    @UUIDValidator
    private String programId;

    @NotNull(message = "Image is required.")
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile imageFile;

    @Size(max = 255, message = "Alt text cannot exceed 255 characters.")
    private String altText;

    private Boolean isActive;
}
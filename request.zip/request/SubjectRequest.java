package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class SubjectRequest {

    @NotBlank(message = ValidationConstants.SUBJECT_NAME_REQUIRED)
    @Size(max = 200, message = ValidationConstants.SUBJECT_NAME_LENGTH)
    private String name;
    
    private Boolean isActive;
    
    private MultipartFile imageFile;
}

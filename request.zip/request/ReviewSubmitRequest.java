package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewSubmitRequest {

    @NotBlank(message = ValidationConstants.REGISTRATION_ID_REQUIRED)
    @UUIDValidator
    private String registrationId;
}

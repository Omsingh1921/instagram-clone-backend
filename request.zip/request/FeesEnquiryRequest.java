package com.renaissance.app.dto.request;

import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class FeesEnquiryRequest  implements ActivityPayload{

    @NotBlank(message = ValidationConstants.FULL_NAME_REQUIRED)
    @Size(min = 3, max = 100, message = ValidationConstants.FULL_NAME_SIZE)
    private String fullName;

    @Email(message = ValidationConstants.INVALID_EMAIL)
    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    private String email;

    @NotBlank(message = ValidationConstants.CONTACT_REQUIRED)
    @Pattern(
        regexp = "^[0-9]{10}$",
        message = ValidationConstants.CONTACT_INVALID
    )
    private String contactNumber;

    @NotNull(message = ValidationConstants.WHATSAPP_SAME_REQUIRED)
    private Boolean isWhatsappSame;

    @NotBlank(message = ValidationConstants.SCHOOL_PROGRAM_ID_REQUIRED)
    @UUIDValidator
    private String schoolProgramId;

    @NotBlank(message = ValidationConstants.COURSE_ID_REQUIRED)
    @UUIDValidator
    private String courseId;
}

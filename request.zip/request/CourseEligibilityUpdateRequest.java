package com.renaissance.app.dto.request;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CourseEligibilityUpdateRequest {

    /**
     * ID of the existing CourseEligibility to update.
     */
    @NotBlank(message = "Eligibility ID is required.")
    private String eligibilityId;

    /**
     * Title of the eligibility.
     */
    private String eligibilityTitle;

    /**
     * Description of the eligibility.
     */
    private String description;

    /**
     * List of asset update requests.
     * Each can represent an existing asset (with ID) or a new one (without ID).
     */
    @Valid
    private List<EligibilityItemsUpdateRequest> items; // renamed from assets
}

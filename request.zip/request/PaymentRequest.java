package com.renaissance.app.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentRequest {

	@NotBlank(message = "Phone number is required.")
	@Pattern(regexp = "^(\\+\\d{1,3}[- ]?)?\\d{10}$", message = "Invalid phone number format. Must be 10 digits or a valid international format.")
	private String phoneNumber;

	@NotNull(message = "Amount is required.")
	@Positive(message = "Amount must be greater than zero.")
	private Double amount;

	@NotBlank(message = "Transaction ID is required.")
	@Size(max = 100, message = "Transaction ID must not exceed 100 characters.")
	private String transactionId;
}

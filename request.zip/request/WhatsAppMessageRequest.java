package com.renaissance.app.dto.request;

import java.util.Map;

import lombok.Builder;
import lombok.Data;
@Data
@Builder
public class WhatsAppMessageRequest {

    private String to;
    private String templateName;   
    private String namespace;      
    private String mediaUrl;       
    private String fileName;       
    private Map<String, String> params;
    private ButtonPayload button;

    @Data
    @Builder
    public static class ButtonPayload {
        private String url;
        private int index;
    }
}

package com.renaissance.app.dto.request;

import java.time.LocalDate;

import com.renaissance.app.model.enums.Gender;
import com.renaissance.app.model.enums.VerificationType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StudentVerificationRequest {

    @NotBlank(message = "Student full name is required.")
    @Size(max = 150)
    private String studentFullName;

    @NotBlank(message = "Enrollment number is required.")
    @Size(max = 50)
    private String enrollmentNumber;

    @Size(max = 15)
    private String rollNumber;

    private LocalDate dateOfBirth;

    @NotNull(message = "Verification type is required.")
    private VerificationType verificationType;

    @NotNull(message = "Gender is required.")
    private Gender gender;
}

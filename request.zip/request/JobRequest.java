package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.ExperienceLevel;
import com.renaissance.app.model.enums.JobType;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class JobRequest {

    @NotBlank(message = ValidationConstants.JOB_NAME_REQUIRED)
    @Size(max = 200, message = ValidationConstants.JOB_NAME_LENGTH)
    private String jobName;

    @NotBlank(message = ValidationConstants.JOB_DESCRIPTION_REQUIRED)
    private String description;

    @NotNull(message = ValidationConstants.EXPERIENCE_LEVEL_REQUIRED)
    private ExperienceLevel experienceLevel;

    @NotNull(message = ValidationConstants.JOB_TYPE_REQUIRED)
    private JobType jobType;

//    @NotNull(message = ValidationConstants.SALARY_AMOUNT_REQUIRED)
//    @Positive(message = ValidationConstants.SALARY_AMOUNT_POSITIVE)
//    private Double salaryAmount;

//    @NotNull(message = ValidationConstants.SALARY_PERIOD_REQUIRED)
//    private SalaryPeriod salaryPeriod;

    private Boolean isActive;

    private List<String> courseIds;

    private MultipartFile logoFile;
}

package com.renaissance.app.dto.request;

import java.time.LocalDate;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class PressReleaseRequest {

    @NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    private String shortDescription;

    @NotBlank(message = ValidationConstants.PUBLISHER_REQUIRED)
    private String publisher;

    @NotBlank(message = ValidationConstants.MEDIA_DETAIL_LINK_REQUIRED)
    private String mediaDetailLink;

    @NotNull(message = ValidationConstants.CATEGORY_ID_REQUIRED)
    private String categoryId;

    @NotNull(message = ValidationConstants.PUBLISH_DATE_REQUIRED)
    private LocalDate publishDate;

    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile imageFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    private String imageAltText;

    private Boolean isActive;

    @Valid
    private SeoConfigRequest seoConfigRequest;
}

package com.renaissance.app.dto.request;

import java.time.LocalDate;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class PersonalDetailsRequest {

	@UUIDValidator(message = ValidationConstants.INVALID_UUID)
	private String registrationId;

	@NotBlank(message = ValidationConstants.FULL_NAME_REQUIRED)
	private String fullName;

	@NotNull(message = ValidationConstants.DOB_REQUIRED)
	private LocalDate dob;

	@NotBlank(message = ValidationConstants.FATHER_NAME_REQUIRED)
	private String fatherName;

	@NotBlank(message = ValidationConstants.MOTHER_NAME_REQUIRED)
	private String motherName;

	@NotBlank(message = ValidationConstants.CONTACT_REQUIRED)
	private String contactNumber;

	@NotBlank(message = ValidationConstants.PARENT_CONTACT_REQUIRED)
	private String parentsContactNumber;

	@NotBlank(message = ValidationConstants.WHATSAPP_REQUIRED)
	private String whatsappNumber;

	@NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
	@Email(message = ValidationConstants.INVALID_EMAIL)
	private String email;

	@NotBlank(message = ValidationConstants.CATEGORY_REQUIRED)
	private String categoryCaste;

	@NotBlank(message = ValidationConstants.GENDER_REQUIRED)
	private String gender;

	@NotNull(message = ValidationConstants.PROGRAM_REQUIRED)
	private String interestedProgramId;

    @NotNull(message = ValidationConstants.PASSING_YEAR_REQUIRED)
    private Integer session;

	@NotNull(message = ValidationConstants.COURSE_REQUIRED)
	private String selectedCourseId;

	private boolean isWhatsappSameAsContact;
	
	@NotNull(message = "Counsellor name is required")
	private String counselledBy;
	
	
}

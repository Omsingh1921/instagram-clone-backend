package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.PlacementType;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class PlacementUpdateRequest {

	@NotNull(message = "Placement ID is required for update")
	private String placementId;

	@Size(max = 100, message = ValidationConstants.STUDENT_NAME_MAX_LENGTH)
	private String studentName;

	@Size(max = 200, message = ValidationConstants.COMPANY_NAME_MAX_LENGTH)
	private String companyName;

	@Positive(message = ValidationConstants.PACKAGE_OFFERED_POSITIVE)
	private Double packageOffered;

	@Size(max = 100, message = ValidationConstants.COUNTRY_MAX_LENGTH)
	private String country;

	private PlacementType placementType; // optional update (DOMESTIC or INTERNATIONAL)

	private MultipartFile profilePhoto; // optional — replaces old one if provided

	private Boolean isActive; // optional — can toggle placement status

	private String schoolProgramId; // optional update
	private String courseId;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class GrievanceRequest  implements ActivityPayload {

    // --- Student Information ---
    @NotBlank(message = ValidationConstants.NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
    private String fullName;

    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    @Email(message = ValidationConstants.INVALID_EMAIL)
    @Size(max = 150, message = ValidationConstants.EMAIL_MAX_LENGTH)
    private String email;

    @Size(max = 20, message = ValidationConstants.PHONE_MAX_LENGTH)
    private String phone;

    @NotBlank(message = ValidationConstants.DEPARTMENT_YEAR_REQUIRED)
    private String departmentAndYear;

    @NotBlank(message = ValidationConstants.ENROLLMENT_OR_ROLL_REQUIRED)
    @Size(max = 100, message = ValidationConstants.ENROLLMENT_OR_ROLL_MAX_LENGTH)
    private String enrollmentOrRollNumber;

    // --- Grievance Details ---
    @NotBlank(message = ValidationConstants.SUBJECT_REQUIRED)
    private String subject;

    @NotBlank(message = ValidationConstants.GRIEVANCE_DETAIL_REQUIRED)
    private String grievanceDetail;

    // --- Declarations (checkboxes) ---
    @NotNull(message = ValidationConstants.INFO_TRUE_CONFIRMATION_REQUIRED)
    private Boolean isInformationTrue;

    @NotNull(message = ValidationConstants.FALSE_REPORTING_ACK_REQUIRED)
    private Boolean acknowledgesFalseReportingPenalty;
}

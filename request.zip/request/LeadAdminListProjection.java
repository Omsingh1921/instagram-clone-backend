package com.renaissance.app.dto.request;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class LeadAdminListProjection {

    private String profileId;
    private String name;
    private String email;
    private String phone;

    private String leadSource;
    private String latestActivity;
    private LocalDateTime lastActivityAt;

    private String courseName;
    private String programName;
}

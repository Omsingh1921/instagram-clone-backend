package com.renaissance.app.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StateDto {
    private String id;
    private String name;
}


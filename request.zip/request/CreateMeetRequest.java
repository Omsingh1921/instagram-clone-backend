package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateMeetRequest {

    private String title;

    // yyyy-MM-dd
    private LocalDate date;

    // HH:mm
    private LocalTime startTime;

    // HH:mm
    private LocalTime endTime;

    private List<String> attendeeEmails;
}

package com.renaissance.app.dto.request;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReorderCoursesRequest {
    private List<String> orderedCourseIds;
}

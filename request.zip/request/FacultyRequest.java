package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class FacultyRequest {

    @NotBlank(message = ValidationConstants.NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
    private String name;

    @NotBlank(message = ValidationConstants.DESIGNATION_REQUIRED)
    @Size(max = 100, message = ValidationConstants.DESIGNATION_MAX_LENGTH)
    private String designation;

    @NotBlank(message = ValidationConstants.BIO_REQUIRED)
    @Size(max = 1000, message = ValidationConstants.BIO_MAX_LENGTH)
    private String bio;

    private Boolean isActive;

    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    @Email(message = ValidationConstants.INVALID_EMAIL)
    @Size(max = 100, message = ValidationConstants.EMAIL_MAX_LENGTH)
    private String email;

    @NotNull(message = ValidationConstants.PROFILE_IMAGE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile profileImage;

    @Valid
    @Size(min = 1, message = ValidationConstants.SCHOOL_PROGRAM_ID_REQUIRED)
    private List<String> schoolProgramIds;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.StudentType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FeeUpdateRequest {
    private String feeId; // for existing fees
    private Double totalFee;
    private StudentType studentType;
}
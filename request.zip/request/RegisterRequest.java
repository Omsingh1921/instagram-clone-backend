package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class RegisterRequest {

    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    @Pattern(
        regexp = ValidationConstants.EMAIL_PATTERN,
        message = ValidationConstants.EMAIL_PATTERN_MESSAGE
    )
    private String email;

    @NotBlank(message = ValidationConstants.PASSWORD_REQUIRED)
    @Pattern(
        regexp = ValidationConstants.PASSWORD_PATTERN,
        message = ValidationConstants.PASSWORD_PATTERN_MESSAGE
    )
    private String password;
}

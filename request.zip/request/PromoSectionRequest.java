package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class PromoSectionRequest {

    @NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    @Size(max = 2000, message = ValidationConstants.DESCRIPTION_LENGTH_2000)
    private String description;

    @NotNull(message = ValidationConstants.MEDIA_FILE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile mediaFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    @Size(max = 300, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String mediaAltText;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.DocumentType;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class CreatePolicyDocumentRequest {

    @NotNull(message = ValidationConstants.DOCUMENT_TYPE_REQUIRED)
    private DocumentType type;

    @NotBlank(message = ValidationConstants.DOCUMENT_CONTENT_REQUIRED)
    private String content; // replaces title + description + image
}

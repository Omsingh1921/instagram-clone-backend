package com.renaissance.app.dto.request;

import java.util.List;

import com.renaissance.app.model.enums.AcademicYear;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CourseSubjectBindingRequest {
   
	 @NotEmpty(message = ValidationConstants.SUBJECT_IDS_REQUIRED)
    private List<String> subjectId;

	@NotNull(message = ValidationConstants.ACADEMIC_YEAR_REQUIRED)
	private AcademicYear year;
	
	@Min(value = 1, message = ValidationConstants.SEMESTER_MIN_INVALID)
	@Max(value = 10, message = ValidationConstants.SEMESTER_MAX_INVALID)
	private Integer semester;

}

package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class AddressDetailsRequest {

    @NotBlank(message = ValidationConstants.REGISTRATION_ID_REQUIRED)
    @UUIDValidator
    private String registrationId;

    @NotBlank(message = ValidationConstants.COUNTRY_REQUIRED)
    private String country;

    @NotBlank(message = ValidationConstants.STATE_REQUIRED)
    private String state;

    @NotBlank(message = ValidationConstants.CITY_REQUIRED)
    private String city;

    @NotBlank(message = ValidationConstants.PINCODE_REQUIRED)
    private String pincode;
}

package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.PlacementType;
import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecruitmentPartnerRequest {

	@NotEmpty(message = "Partner name is required")
	@Size(max = 200, message = "Partner name cannot exceed 200 characters")
	private String name;

	private PlacementType type;

	// multipart file of the logo
	@ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile logo;

	// List of SchoolProgram IDs associated with this partner
	@NotEmpty(message = "At least one school program must be selected")
	private List<String> schoolProgramIds;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class OpportunityItemRequest {

    @NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    @Size(max = 1000, message = ValidationConstants.DESCRIPTION_LENGTH_1000)
    private String description;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.CasteCategoryType;
import com.renaissance.app.util.annotations.TrimValidator;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@TrimValidator
public class WhatsappEnquiryRequest {

    @NotBlank(message = "Full name is required.")
    @Size(max = 100, message = "Full name cannot exceed 100 characters.")
    private String fullName;

    @NotBlank(message = "Email is required.")
    @Email(message = "Please enter a valid email address.")
    @Size(max = 120, message = "Email cannot exceed 120 characters.")
    private String email;

    @NotBlank(message = "Date of birth is required.")
    @Pattern(
        regexp = "^\\d{4}-\\d{2}-\\d{2}$",
        message = "Date of birth must be in the format yyyy-MM-dd."
    )
    private String dob;

    @NotBlank(message = "Gender is required.")
    private String gender;

    @NotBlank(message = "WhatsApp contact is required.")
    @Pattern(
        regexp = "^(\\+\\d{1,3}[- ]?)?\\d{10}$",
        message = "WhatsApp contact must be a valid 10-digit number, optionally prefixed with country code."
    )
    private String whatsappContact;

    @NotNull(message = "Caste category is required.")
    private CasteCategoryType category;

    @NotBlank(message = "Father's name is required.")
    @Size(max = 100, message = "Father's name cannot exceed 100 characters.")
    private String fatherName;

    @NotBlank(message = "Parent contact number is required.")
    @Pattern(
        regexp = "^(\\+\\d{1,3}[- ]?)?\\d{10}$",
        message = "Parent contact must be a valid 10-digit number, optionally prefixed with country code."
    )
    private String parentsContactNumber;

    @NotBlank(message = "Permanent address is required.")
    @Size(max = 255, message = "Permanent address cannot exceed 255 characters.")
    private String permanentCity;

    @NotBlank(message = "Current address is required.")
    @Size(max = 255, message = "Current address cannot exceed 255 characters.")
    private String currentCity;

    @NotBlank(message = "State is required.")
    @Size(max = 100, message = "State name cannot exceed 100 characters.")
    private String currentState;

    @NotBlank(message = "PIN code is required.")
    @Pattern(
        regexp = "^[1-9][0-9]{5}$",
        message = "PIN code must be a valid 6-digit Indian postal code."
    )
    private String currentPinCode;

    @NotNull(message = "Current education type is required.")
    private String currentEducation;

    @NotBlank(message = "School name is required.")
    @Size(max = 150, message = "School name cannot exceed 150 characters.")
    private String schoolName;
    
    //school program name
    @NotBlank(message = "School program name is required.")
    @Size(max = 150, message = "School program name cannot exceed 150 characters.")
    private String schoolProgramName;
    
    //course name
    @NotBlank(message = "Course name is required.")
    @Size(max = 150, message = "Course name cannot exceed 150 characters.")
    private String courseName;

    @NotBlank(message = "Counsellor name is required.")
    @Size(max = 100, message = "Counsellor name cannot exceed 100 characters.")
    private String counsellerName;
}

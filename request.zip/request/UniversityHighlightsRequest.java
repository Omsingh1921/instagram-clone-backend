package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UniversityHighlightsRequest {

	@NotBlank(message = ValidationConstants.TITLE_REQUIRED)
	@Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
	private String title;

	@NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
	@Size(max = 500, message = ValidationConstants.DESCRIPTION_MAX_LENGTH)
	private String description;

	@ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile media; // file upload

	private String url;
	
}
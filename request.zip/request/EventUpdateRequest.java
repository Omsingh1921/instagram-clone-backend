package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class EventUpdateRequest {

    // ---------- Basic ----------
    private String title;
    private String previewContent;
    private String detailedContent;
    private Boolean isActive;
    private String organizer;
    private LocalDate startDate;
    private LocalDate endDate;

    @Size(max = 200, message = ValidationConstants.VENUE_MAX_LENGTH)
    private String venue;

    // ---------- Media ----------
    private MultipartFile thumbnailFile;
    private String thumbnailAltText;

    private MultipartFile coverImageFile;
    private String coverImageAltText;

    @Size(max = 10, message = ValidationConstants.GALLERY_LIMIT)
    @Builder.Default
    private List<MultipartFile> galleryFiles = new ArrayList<>();

    private List<String> removedGalleryImages;

    // ---------- About Event ----------
    private MultipartFile aboutTheEventMediaFile;
    private String aboutTheEventAltText;

    @Valid
    private List<EventAboutPointUpdateRequest> aboutTheEventContent;

    // ---------- Guests ----------
    @Valid
    private List<EventGuestUpdateRequest> chiefGuests;

    // ---------- SEO ----------
    @Valid
    private SeoConfigRequest seoConfigRequest;
}

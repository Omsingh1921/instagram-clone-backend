package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdatePermissionRequest {
	@NotBlank(message = ValidationConstants.PERMISSION_ID_REQUIRED)
	@UUIDValidator(message = ValidationConstants.INVALID_UUID)
	private String permissionId;

	private Boolean isCreated;
	private Boolean isRead;
	private Boolean isUpdate;
	private Boolean isDelete;
}
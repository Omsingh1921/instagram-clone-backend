package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class InHouseInternshipRequest  implements ActivityPayload{

    @NotBlank(message = ValidationConstants.NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
    private String name;

    @NotBlank(message = ValidationConstants.BATCH_REQUIRED)
    private String batch;

    @NotBlank(message = ValidationConstants.COURSE_ID_REQUIRED)
    private String courseId;
    
    @NotBlank(message = ValidationConstants.PHONE_REQUIRED)
    private String phoneNumber;
    
    //email
    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    @Size(max = 100, message = ValidationConstants.EMAIL_MAX_LENGTH)
    private String email;

    @JsonIgnore
    private MultipartFile resumeFile; // Optional file upload
    
}

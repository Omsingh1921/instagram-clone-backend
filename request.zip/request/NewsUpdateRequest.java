package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class NewsUpdateRequest {

    @NotBlank(message = ValidationConstants.NEWS_ID_REQUIRED)
    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String newsId;

    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @Size(max = 500, message = ValidationConstants.PREVIEW_CONTENT_MAX_LENGTH)
    private String previewContent;

    private String detailedContent;

    private String authorName;

    private Boolean isActive;

    private Boolean isFeaturedNews;

    private LocalDate publishDate;

    // ---------- Media ----------
    private MultipartFile thumbnailFile;

    @Size(max = 255, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String thumbnailAltText;

    private MultipartFile coverImageFile;

    @Size(max = 255, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String coverImageAltText;

    @Builder.Default
    @Size(max = 10, message = "A maximum of 10 related media files is allowed.")
    private List<MultipartFile> relatedMediaFiles = new ArrayList<>();

    // IDs of old media files to remove (if applicable)
    private List<String> removedRelatedMedia;

//    // ---------- Category ----------
//    @NotBlank(message = ValidationConstants.CATEGORY_ID_REQUIRED)
//    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
//    private String categoryId;

    // ---------- SEO ----------
    @Valid
    private SeoConfigRequest seoConfigRequest;
}

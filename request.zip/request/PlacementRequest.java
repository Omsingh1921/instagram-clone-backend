package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.PlacementType;
import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class PlacementRequest {

	@NotBlank(message = ValidationConstants.STUDENT_NAME_REQUIRED)
	@Size(max = 100, message = ValidationConstants.STUDENT_NAME_MAX_LENGTH)
	private String studentName;

	@NotBlank(message = ValidationConstants.COMPANY_NAME_REQUIRED)
	@Size(max = 200, message = ValidationConstants.COMPANY_NAME_MAX_LENGTH)
	private String companyName;

	@NotNull(message = ValidationConstants.PACKAGE_OFFERED_REQUIRED)
	@Positive(message = ValidationConstants.PACKAGE_OFFERED_POSITIVE)
	private Double packageOffered;

	@NotBlank(message = ValidationConstants.COUNTRY_REQUIRED)
	@Size(max = 100, message = ValidationConstants.COUNTRY_MAX_LENGTH)
	private String country;

	@NotNull(message = ValidationConstants.COMPANY_PLACE_TYPE_REQUIRED)
	private PlacementType placementType; // DOMESTIC or INTERNATIONAL

	@NotNull(message = ValidationConstants.PROFILE_PHOTO_REQUIRED)
	@ImageValidator(message =  "unsupported media type")
	private MultipartFile profilePhoto; // file upload

	@NotBlank(message = "School Program ID is required")
	private String schoolProgramId;

	@NotBlank(message = "Course ID is required")
	private String courseId;

	private Boolean isActive;
}

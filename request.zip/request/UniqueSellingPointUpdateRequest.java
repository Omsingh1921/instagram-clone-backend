package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UniqueSellingPointUpdateRequest {
	
//    /**
//     * ID of the existing CourseEligibility to update.
//     */
//    @NotBlank(message = "Usp ID is required.")
//    private String uspId;
//

	@NotBlank(message = ValidationConstants.NAME_REQUIRED)
	@Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
	private String title;

	@Size(max = 2000, message = ValidationConstants.DESCRIPTION_LENGTH_2000)
	private String description;

	@Builder.Default
	@Size(max = 8, message = "A program can have a maximum of 8 unique selling features.")
	private List<FeatureUpdateRequest> features = new ArrayList<>();
}

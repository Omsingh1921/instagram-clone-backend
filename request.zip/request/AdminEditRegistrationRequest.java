package com.renaissance.app.dto.request;

import java.time.LocalDate;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class AdminEditRegistrationRequest {

    // -------- PERSONAL --------

    @Size(min = 2, max = 100, message = ValidationConstants.FULL_NAME_INVALID)
    private String fullName;

    private LocalDate dob;
    
    private String counselledBy;

    @Pattern(
        regexp = "MALE|FEMALE|OTHER",
        message = ValidationConstants.GENDER_INVALID
    )
    private String gender;

    @Email(message = ValidationConstants.INVALID_EMAIL)
    private String email;

    @Pattern(
        regexp = "^[6-9]\\d{9}$",
        message = ValidationConstants.INVALID_MOBILE
    )
    private String contactNumber;

    @Pattern(
        regexp = "^[6-9]\\d{9}$",
        message = ValidationConstants.INVALID_MOBILE
    )
    private String whatsappNumber;

    @Size(max = 100)
    private String fatherName;

    @Size(max = 100)
    private String motherName;

    @Pattern(
        regexp = "^[6-9]\\d{9}$",
        message = ValidationConstants.INVALID_MOBILE
    )
    private String parentsContactNumber;

    @Size(max = 50, message = ValidationConstants.CATEGORY_INVALID)
    private String categoryCaste;

    // -------- PROGRAM / COURSE --------

    @UUIDValidator(message = ValidationConstants.PROGRAM_ID_INVALID)
    private String programId;

    @UUIDValidator(message = ValidationConstants.COURSE_ID_INVALID)
    private String courseId;

    // -------- ADDRESS --------

    @Size(max = 100)
    private String country;

    @Size(max = 100)
    private String state;

    @Size(max = 100)
    private String city;

    @Pattern(
        regexp = "^\\d{6}$",
        message = ValidationConstants.INVALID_PINCODE
    )
    private String pincode;

    // -------- EDUCATION --------

    @Size(max = 50)
    private String recentEducation;

    @Size(max = 30)
    private String eduStatus;

    @Size(max = 100, message = ValidationConstants.BOARD_INVALID)
    private String board;

    @Min(value = 1950, message = ValidationConstants.PASSING_YEAR_INVALID)
    @Max(value = 2100, message = ValidationConstants.PASSING_YEAR_INVALID)
    private Integer session;

    @Size(max = 150, message = ValidationConstants.SCHOOL_NAME_INVALID)
    private String schoolOrCollegeName;
}

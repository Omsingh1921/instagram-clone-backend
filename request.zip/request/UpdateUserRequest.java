package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class UpdateUserRequest {

   
	@Size(max = 100, message = ValidationConstants.NAME_LENGTH_100)
	private String name;

	@Size(min = 3, max = 50, message = ValidationConstants.USERNAME_LENGTH)
	private String username;

	@Pattern(
		    regexp = "^[6-9]\\d{9}$",
		    message = "Invalid mobile number"
		)
		private String phoneNumber;
	
	@ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile profilePicture;

	@UUIDValidator
	private String roleId;
	
	private List<String> schoolProgramIds;
    
	private List<String> courseIds;
}

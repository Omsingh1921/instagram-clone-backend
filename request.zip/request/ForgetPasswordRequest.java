package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TrimValidator
public class ForgetPasswordRequest {

	@NotBlank(message = ValidationConstants.USERNAME_REQUIRED)
	private String email;
}

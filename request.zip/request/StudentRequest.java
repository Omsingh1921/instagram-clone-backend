package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class StudentRequest {

    @NotBlank(message = ValidationConstants.STUDENT_NAME_REQUIRED)
    private String name;

    @NotBlank(message = ValidationConstants.COURSE_ID_REQUIRED)
    @UUIDValidator
    private String courseId;
}

package com.renaissance.app.dto.request;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventAboutPointUpdateRequest {

    @Size(max = 1000, message = "Point content too long")
    private String content;

    private Integer displayOrder;
}

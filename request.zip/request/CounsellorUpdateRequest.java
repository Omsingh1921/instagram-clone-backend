package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounsellorUpdateRequest {

    @Size(max = 150, message = ValidationConstants.COUNSELLOR_NAME_MAX_LENGTH)
    private String name;

    @Email(message = ValidationConstants.COUNSELLOR_EMAIL_INVALID)
    @Size(max = 150, message = ValidationConstants.COUNSELLOR_EMAIL_MAX_LENGTH)
    private String email;

    @Size(max = 15, message = ValidationConstants.COUNSELLOR_PHONE_MAX_LENGTH)
    private String phone;

    private Boolean isActive;

    private MultipartFile profilePicture;

    /**
     * Indicates if this counsellor applies to all school programs.
     * Optional — updates only if explicitly provided.
     */
    private Boolean isGeneral;

    /**
     * Indicates if virtual counselling is enabled.
     * Optional — updates only if explicitly provided.
     */
    private Boolean virtualCounsellingEnabled;

    /**
     * List of school program IDs to re-bind.
     * Optional — replaces existing associations if provided.
     */
    @Valid
    private List<String> schoolProgramIds;

    /**
     * List of updated availability slots.
     * Optional — replaces existing slots only if provided.
     */
    @Valid
    private List<CounsellorAvailabilityRequest> availability;
}

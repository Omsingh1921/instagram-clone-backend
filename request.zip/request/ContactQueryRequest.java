package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.ContactQueryType;
import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class ContactQueryRequest  implements ActivityPayload{

    @NotBlank(message = ValidationConstants.CONTACT_NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.CONTACT_NAME_MAX_LENGTH)
    @Pattern(
        regexp = ValidationConstants.NAME_PATTERN,
        message = ValidationConstants.NAME_PATTERN_MESSAGE
    )
    private String name;

    @NotBlank(message = ValidationConstants.CONTACT_EMAIL_REQUIRED)
    @Email(message = ValidationConstants.CONTACT_EMAIL_INVALID)
    private String email;
    
    @NotNull(message = ValidationConstants.CONTACT_QUERY_TYPE_REQUIRED)
    private ContactQueryType queryType;

    @Pattern(
        regexp = ValidationConstants.PHONE_PATTERN,
        message = ValidationConstants.PHONE_PATTERN_MESSAGE
    )
    private String phone;
    
    //city
    @Size(max = 100, message = ValidationConstants.CONTACT_CITY_MAX_LENGTH)
    @NotBlank(message = ValidationConstants.CONTACT_CITY_REQUIRED)
    private String city;

    @Size(max = 1000, message = ValidationConstants.CONTACT_MESSAGE_MAX_LENGTH)
    private String message;
    
//    @NotBlank(message = ValidationConstants.COURSE_ID_REQUIRED)
//    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String courseId;
    
    @AssertTrue(message = ValidationConstants.CONTACT_MESSAGE_REQUIRED_FOR_GENERAL_ENQUIRY)
    public boolean isMessageValidForGeneralEnquiry() {
        if (queryType == null) return false; // prevent NPEs
        if (queryType == ContactQueryType.GENERAL_ENQUIRY) {
            return message != null && !message.isBlank();
        }
        return true; // for ADMISSION_AND_COURSE_ENQUIRY, message can be optional
    }
}

package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.CourseDuration;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class CourseUpdateRequest {

    @Size(max = 200, message = ValidationConstants.COURSE_NAME_LENGTH)
    private String name;

    @Pattern(
        regexp = "^[a-z0-9]+(?:-[a-z0-9]+)*$",
        message = "Endpoint must be URL-safe (lowercase letters, numbers, and hyphens only)."
    )
    private String endpoint;

//    @NotNull(message = ValidationConstants.DURATION_REQUIRED)
    @Enumerated(EnumType.STRING)
    private CourseDuration duration;

    private String courseStartDate; // Optional, old value retained if null

    @Size(max = 500, message = ValidationConstants.COURSE_TYPE_MAX_LENGTH)
    private String courseType;

    private Boolean isActive;

    @Size(max = 500, message = ValidationConstants.SHORT_DESCRIPTION_MAX_LENGTH)
    private String shortDescription;

    private MultipartFile brochureFile; // Optional: only replaces if new file uploaded
    
    private MultipartFile feeStructureBrochureFile; // Optional: only replaces if new file uploaded

    @Size(max = 500, message = ValidationConstants.LONG_DESCRIPTION_MAX_LENGTH)
    private String longDescription;

    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String schoolProgramId; // Optional: only update if provided

    private MultipartFile thumbnailFile; // Optional new thumbnail
    private String thumbnailAltText;     // Optional alt text update

    @Valid
    private PromoSectionUpdateRequest promoSection;

    @Valid
    private UniqueSellingPointUpdateRequest uniqueSellingPoint;

    @Valid
    private CourseEligibilityUpdateRequest eligibilities;

    @Valid
    @Builder.Default
    private List<FeeUpdateRequest> fees = new ArrayList<>();

    @Valid
    private FutureOpportunityUpdateRequest futureOpportunity;

    @Valid
    private SeoConfigRequest seoConfigRequest;

    @Valid
    @Builder.Default
    private List<CourseSubjectBindingRequest> subjects = new ArrayList<>();
    
    @DecimalMin(value = "0.0", inclusive = true, message = "Registration fee cannot be negative")
    @DecimalMax(value = "1000000.0", message = "Registration fee exceeds allowed limit")
    private Double registrationFee;
    
    private Boolean removeFeeStructureBrochure;
}

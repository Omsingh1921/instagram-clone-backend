package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.AcademicYear;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class CourseSubjectUpdateRequest {

    @Size(max = 200, message = ValidationConstants.SUBJECT_NAME_LENGTH)
    private String name;

    @Size(max = 500, message = ValidationConstants.SUBJECT_DESCRIPTION_LENGTH)
    private String description;

    @Min(value = 1, message = ValidationConstants.YEAR_MIN)
    @Max(value = 10, message = ValidationConstants.YEAR_MAX)
    private AcademicYear year;

    @Size(max = 100, message = ValidationConstants.SUBJECT_CODE_LENGTH)
    private String code;

    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String courseId;
}

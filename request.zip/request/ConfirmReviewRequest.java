package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.UUIDValidator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmReviewRequest {
	@UUIDValidator(message = "Invalid registration ID")
//	@NotNull(message = "Registration ID cannot be null")
    private String registrationId;

    // getters & setters
}

package com.renaissance.app.dto.request;

import java.time.LocalDateTime;

import com.renaissance.app.model.enums.LeadStatus;
import com.renaissance.app.util.annotations.TrimValidator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class UpdateLeadRequest {

    private LeadStatus status;
    private String remark;
    private LocalDateTime followUpDate;
}
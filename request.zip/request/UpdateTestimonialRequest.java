package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class UpdateTestimonialRequest {

    @Size(max = 1000, message = ValidationConstants.CONTENT_MAX_LENGTH)
    private String content; // optional

    private MultipartFile authorProfile; // optional

    private String courseId; // optional, may change course association
    
}

package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.renaissance.app.model.enums.GenderType;
import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounsellingSessionCreateRequest  implements ActivityPayload{

    // Counsellor
    @NotBlank(message = ValidationConstants.INVALID_COUNSELLOR_ID)
    @UUIDValidator(message = ValidationConstants.INVALID_COUNSELLOR_ID)
    private String counsellorId;

    @UUIDValidator(message = ValidationConstants.INVALID_PROGRAM_ID)
    private String programId;

    // User
    @NotBlank(message = ValidationConstants.INVALID_USER_NAME)
    private String name;

    @Email(message = ValidationConstants.INVALID_EMAIL)
    @NotBlank(message = ValidationConstants.INVALID_EMAIL)
    private String email;

    @Pattern(
        regexp = "^[0-9]{7,15}$",
        message = ValidationConstants.INVALID_PHONE
    )
    @NotBlank(message = ValidationConstants.INVALID_PHONE)
    private String userPhone;

    @NotNull(message = ValidationConstants.INVALID_GENDER)
    private GenderType gender;

    // Friends
    @Valid
    private List<FriendRequest> friends;

    // Date & Time
    @NotNull(message = ValidationConstants.INVALID_SESSION_DATE)
    private LocalDate sessionDate;

    @NotNull(message = ValidationConstants.INVALID_START_TIME)
    private LocalTime sessionStartTime;

    @NotNull(message = ValidationConstants.INVALID_END_TIME)
    private LocalTime sessionEndTime;
}

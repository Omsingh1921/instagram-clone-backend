
package com.renaissance.app.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentVerificationRequest {

    @NotBlank(message = "Order ID is required.")
    private String orderId;

    @NotBlank(message = "Payment ID is required.")
    private String paymentId;

    @NotBlank(message = "Signature is required.")
    private String signature;
}

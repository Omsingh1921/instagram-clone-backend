package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class UserRequest {

	@NotBlank(message = ValidationConstants.FULL_NAME_REQUIRED)
	@Size(max = 100, message = ValidationConstants.NAME_LENGTH_100)
	private String name;

	@NotBlank(message = ValidationConstants.USERNAME_REQUIRED)
	@Size(min = 3, max = 50, message = ValidationConstants.USERNAME_LENGTH)
	private String username;

	@NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
	@Email(message = ValidationConstants.EMAIL_PATTERN_MESSAGE)
	private String email;
	
//	@NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
//	@Email(message = ValidationConstants.EMAIL_PATTERN_MESSAGE)
	@Pattern(
		    regexp = "^[6-9]\\d{9}$",
		    message = "Invalid mobile number"
		)
		private String phoneNumber;

	@NotNull(message = ValidationConstants.PROFILE_PICTURE_REQUIRED)
	@ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile profilePicture;

	@NotBlank(message = ValidationConstants.ROLE_ID_REQUIRED)
	@UUIDValidator
	private String roleId;
	
	private List<String> courseIds;
	
	private List<String> schoolProgramIds;
}

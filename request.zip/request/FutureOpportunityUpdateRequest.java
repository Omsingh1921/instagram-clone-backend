package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class FutureOpportunityUpdateRequest {

    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title; // Optional — only updated if provided

    @Size(max = 2000, message = ValidationConstants.DESCRIPTION_LENGTH_2000)
    private String description; // Optional — only updated if provided

    private MultipartFile imageFile; // Optional — replaces old image if uploaded

    @Size(max = 300, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String imageAltText; // Optional — replaces old alt text if provided

    @Valid
    @Builder.Default
    @Size(max = 5, message = ValidationConstants.OPPORTUNITIES_MAX_COUNT)
    private List<OpportunityItemUpdateRequest> opportunities = new ArrayList<>(); // Optional — replace or append
}

package com.renaissance.app.dto.request;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentConfirmationRequest {

	@NotNull(message = "Amount paid is required.")
	@Positive(message = "Amount must be greater than zero.")
	private Double amountPaid;

	@NotBlank(message = "Transaction ID is required.")
	@Size(max = 100, message = "Transaction ID cannot exceed 100 characters.")
	private String transactionId;

	@NotBlank(message = "Payment method is required.")
	@Size(max = 100, message = "Payment method cannot exceed 100 characters.")
	private String paymentMethod;

	@Builder.Default
	private LocalDateTime paymentDate = LocalDateTime.now();
}

package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.StudentType;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class FeeRequest {
	
    @NotNull(message = ValidationConstants.TOTAL_FEE_REQUIRED)
    @Positive(message = ValidationConstants.AMOUNT_POSITIVE)
    private Double totalFee;
    
    
    @NotNull(message = ValidationConstants.STUDENT_TYPE_REQUIRED)
    private StudentType studentType;
}

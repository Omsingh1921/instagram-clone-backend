package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ChancellorHighlightRequest {

    @NotBlank(message = "Title is required")
    @Size(max = 200, message = "Title cannot exceed 200 characters")
    private String title;

    // Image is mandatory on CREATE, optional on UPDATE
    private MultipartFile imageFile;

    @Size(max = 300, message = "Alt text cannot exceed 300 characters")
    private String altText;
}

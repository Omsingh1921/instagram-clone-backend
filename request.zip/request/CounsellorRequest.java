package com.renaissance.app.dto.request;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class CounsellorRequest {

    @NotBlank(message = ValidationConstants.COUNSELLOR_NAME_REQUIRED)
    @Size(max = 150, message = ValidationConstants.COUNSELLOR_NAME_MAX_LENGTH)
    private String name;

    @NotBlank(message = ValidationConstants.COUNSELLOR_EMAIL_REQUIRED)
    @Email(message = ValidationConstants.COUNSELLOR_EMAIL_INVALID)
    @Size(max = 150, message = ValidationConstants.COUNSELLOR_EMAIL_MAX_LENGTH)
    private String email;

    @NotBlank(message = ValidationConstants.COUNSELLOR_PHONE_REQUIRED)
    @Pattern(regexp = "^[0-9+\\-()\\s]*$", message = ValidationConstants.COUNSELLOR_PHONE_INVALID)
    @Size(max = 15, message = ValidationConstants.COUNSELLOR_PHONE_MAX_LENGTH)
    private String phone;

    private Boolean isActive;

    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile profilePicture;

    @NotNull(message = ValidationConstants.COUNSELLOR_IS_GENERAL_REQUIRED)
    private Boolean isGeneral;

    @NotNull(message = ValidationConstants.COUNSELLOR_VIRTUAL_ENABLED_REQUIRED)
    private Boolean virtualCounsellingEnabled;

//    @NotEmpty(message = ValidationConstants.COUNSELLOR_PROGRAMS_REQUIRED)
    private List<@NotBlank(message = ValidationConstants.COUNSELLOR_PROGRAM_ID_NOT_BLANK) String> schoolProgramIds;

    @Valid
//    @NotEmpty(message = ValidationConstants.COUNSELLOR_AVAILABILITY_REQUIRED)
    private List<CounsellorAvailabilityRequest> availability;
}

package com.renaissance.app.dto.request;

import java.util.ArrayList;
import java.util.List;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class UniqueSellingPointRequest {

    @NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    @Size(max = 2000, message = ValidationConstants.DESCRIPTION_LENGTH_2000)
    private String description;

    @Valid
    @NotNull(message = ValidationConstants.FEATURES_REQUIRED)
    @Size(min = 3, max = 8, message = ValidationConstants.FEATURES_COUNT_LIMIT)
    @Builder.Default
    private List<FeatureRequest> features = new ArrayList<>();
}

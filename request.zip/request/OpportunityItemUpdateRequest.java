package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class OpportunityItemUpdateRequest {

    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title; // Optional — updates only if provided

    @Size(max = 1000, message = ValidationConstants.DESCRIPTION_LENGTH_1000)
    private String description; // Optional — updates only if provided
}
	
package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.PlacementType;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecruitmentPartnerUpdateRequest {

    @Size(max = 200, message = "Partner name cannot exceed 200 characters")
    private String name;

    private PlacementType type;
    
    private MultipartFile logo;

    // Optional: Update associated schools
    private List<String> schoolProgramIds;
}

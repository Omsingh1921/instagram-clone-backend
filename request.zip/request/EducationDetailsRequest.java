package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class EducationDetailsRequest {

    @NotBlank(message = ValidationConstants.REGISTRATION_ID_REQUIRED)
    @UUIDValidator
    private String registrationId;

    @NotBlank(message = ValidationConstants.RECENT_EDU_REQUIRED)
    private String recentEducation;

    private String eduStatus;

    @NotBlank(message = ValidationConstants.BOARD_REQUIRED)
    private String board;
//
//    @NotNull(message = ValidationConstants.PASSING_YEAR_REQUIRED)
//    private Integer session;

    private String schoolOrCollegeName;
}

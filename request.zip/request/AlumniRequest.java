package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class AlumniRequest {

    @NotBlank(message = ValidationConstants.ALUMNI_NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.ALUMNI_NAME_MAX_LENGTH)
    private String name;

    @NotNull(message = ValidationConstants.ALUMNI_IMAGE_REQUIRED)
    private MultipartFile imageFile; // required

    @NotBlank(message = ValidationConstants.ALUMNI_ALT_TEXT_REQUIRED)
    @Size(max = 150, message = ValidationConstants.ALUMNI_ALT_TEXT_MAX_LENGTH)
    private String altText;
    
    @NotNull(message = "programId is required")
    @UUIDValidator(message = "UUID format must be valid")
    private String programId;
    
    private Integer year;
    
    @NotNull(message = "courseId is required")
    @UUIDValidator(message = "UUID format must be valid")
    private String courseId;

    private Boolean isActive; // optional

    @NotBlank(message = ValidationConstants.COMPANY_NAME_REQUIRED)
    @Size(max = 150, message = ValidationConstants.COMPANY_NAME_MAX_LENGTH)
    private String companyName;

    @NotBlank(message = ValidationConstants.DESIGNATION_REQUIRED)
    @Size(max = 100, message = ValidationConstants.DESIGNATION_MAX_LENGTH)
    private String designation;
}

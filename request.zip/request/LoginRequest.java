package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class LoginRequest {

    @NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
    private String email;

    @NotBlank(message = ValidationConstants.PASSWORD_REQUIRED)
    private String password;
}

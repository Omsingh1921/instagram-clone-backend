package com.renaissance.app.dto.request;



import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateRolePermissionsRequest {

	// Optional – update only if present
    private String roleName;

    // Optional – update only if present
    private String description;
    
    @NotEmpty(message = "Authorities list cannot be empty")
    private List<String> authorities;
}

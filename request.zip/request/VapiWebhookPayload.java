package com.renaissance.app.dto.request;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Loosely-typed VAPI webhook payload DTO.
 *
 * VAPI sends:
 * {
 *   "message": {
 *     "type": "end-of-call-report",
 *     "call": {
 *       "id": "...",
 *       "customer": { "number": "+91XXXXXXXXXX" },
 *       "startedAt": "...",
 *       "endedAt":   "..."
 *     },
 *     "durationSeconds": 120,
 *     "recordingUrl": "...",
 *     "transcript":   "...",
 *     "structuredData": {
 *       "interested":           true,
 *       "interest_level":       "HIGH_INTEREST",
 *       "call_outcome":         "CONNECTED_INTERESTED",
 *       "student_name":         "Rahul Sharma",
 *       "caller_type":          "STUDENT",
 *       "qualification":        "...",
 *       "stream":               "Commerce",
 *       "course":               "BBA",
 *       "city":                 "Indore",
 *       "admission_timeline":   "Is saal",
 *       "scholarship_interest": true,
 *       "followup_preference":  "PHONE_COUNSELLING",
 *       "summary":              "..."
 *     }
 *   }
 * }
 *
 * Using Map<String,Object> for structuredData so we are not brittle to
 * VAPI payload evolution or key renames.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VapiWebhookPayload {

    /** Top-level wrapper sent by VAPI */
    private Message message;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Message {

        /** e.g. "end-of-call-report" — only this type is processed */
        private String type;

        private Call call;

        private Integer durationSeconds;

        private String recordingUrl;

        private String transcript;

        /**
         * Structured output fields from the assistant.
         * Kept as a loose map so any future output keys are preserved
         * in structuredDataJson without requiring code changes.
         */
        private Map<String, Object> structuredData;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Call {

        /** VAPI's call UUID */
        private String id;

        private Customer customer;

        private String startedAt;

        private String endedAt;

        private Double cost;

        private String endedReason;

        private Map<String, Object> metadata;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Customer {

        /** Caller phone number, e.g. "+919876543210" */
        private String number;
    }
}

package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class BlogUpdateRequest {

    @NotBlank(message = ValidationConstants.BLOG_ID_REQUIRED)
    private String id;

    @Size(max = 150, message = ValidationConstants.BLOG_TITLE_MAX_LENGTH)
    private String title; // optional update

    @Size(max = 500, message = ValidationConstants.BLOG_PREVIEW_MAX_LENGTH)
    private String shortDescription; // optional update

    private String detailedContent; // optional update

    @Size(max = 100, message = ValidationConstants.BLOG_AUTHOR_MAX_LENGTH)
    private String authorName; // optional update
    
    @Size(max = 2000, message = ValidationConstants.AUTHOR_BIO_MAX_LENGTH)
    private String authorBio; // optional

    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile authorImageFile; // optional


//    private String categoryId; // optional: reassign category

    private Boolean isActive; // optional toggle

    // --- Media Updates ---
    private MultipartFile thumbnailFile; // optional: new thumbnail
    @Size(max = 150, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String thumbnailAltText; // optional: new alt text

    private MultipartFile coverImageFile; // optional: new cover image
    @Size(max = 150, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String coverImageAltText; // optional: new alt text

    // --- SEO Update ---
    @Valid
    private SeoConfigRequest seoConfigRequest; // optional: partial SEO update
}

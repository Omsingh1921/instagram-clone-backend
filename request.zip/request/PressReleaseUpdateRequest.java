package com.renaissance.app.dto.request;

import java.time.LocalDate;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.TrimValidator;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class PressReleaseUpdateRequest {

    private String title;
    private String shortDescription;
    private String publisher;
    private String mediaDetailLink;
    private String categoryId;
    private LocalDate publishDate;
    private Boolean isActive;

    private MultipartFile imageFile;
    private String imageAltText;

    @Valid
    private SeoConfigRequest seoConfigRequest;
}

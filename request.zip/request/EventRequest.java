package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class EventRequest {

    @NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.PREVIEW_CONTENT_REQUIRED)
    private String previewContent;

    @NotBlank(message = ValidationConstants.DETAILED_CONTENT_REQUIRED)
    private String detailedContent;
    
 // About Event Media requuired field
	@NotNull(message = ValidationConstants.ABOUT_THE_EVENT_MEDIA_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile aboutTheEventMediaFile;

    @Size(max = 255, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    //required
    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    private String aboutTheEventAltText;
    
    private Boolean isActive;

    @NotBlank(message = ValidationConstants.ORGANIZER_REQUIRED)
    @Size(max = 150, message = ValidationConstants.ORGANIZER_NAME_MAX_LENGTH)
    private String organizer;

    @NotNull(message = ValidationConstants.START_DATE_REQUIRED)
    private LocalDate startDate;

    @NotNull(message = ValidationConstants.END_DATE_REQUIRED)
    private LocalDate endDate;

    @NotBlank(message = ValidationConstants.VENUE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.VENUE_MAX_LENGTH)
    private String venue;

    @NotNull(message = ValidationConstants.THUMBNAIL_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile thumbnailFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    private String thumbnailAltText;

    @NotNull(message = ValidationConstants.COVER_IMAGE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile coverImageFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    private String coverImageAltText;

    @Valid
    private SeoConfigRequest seoConfigRequest;
    
    @Valid
    @NotEmpty(message = "About event points are required")
    @Size(min = 1, max = 10, message = "About event must have 1–10 points")
    @Builder.Default
    private List<EventAboutPointRequest> aboutTheEventContent = new ArrayList<>();


    @Size(max = 10, message = "Gallery can have a maximum of 10 images.")
    @Builder.Default
    private List<MultipartFile > galleryFiles = new ArrayList<>();

    @Valid
    @Builder.Default
    private List<EventGuestRequest> chiefGuests = new ArrayList<>();
}

package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FeatureUpdateRequest {
	
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String featureId;

    @NotBlank(message = ValidationConstants.NAME_REQUIRED)
    @Size(max = 100, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    private MultipartFile mediaFile; // New icon upload (optional)
    
    private String existingMediaUrl; // Preserve old icon if not re-uploaded

    @Size(max = 500, message = ValidationConstants.DESCRIPTION_LENGTH_500)
    private String description;

    @Size(max = 300, message = "Alt text must be at most 300 characters.")
    private String mediaAltText; // NEW: accessibility alt text for icon
}

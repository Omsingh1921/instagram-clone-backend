package com.renaissance.app.dto.request;

import com.renaissance.app.model.enums.RegistrationStepType;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegistrationStepRequest {

    @NotNull
    private RegistrationStepType stepType;

    @Valid
    private Object payload;
}

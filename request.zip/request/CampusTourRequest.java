package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.renaissance.app.service.ActivityPayload;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class CampusTourRequest  implements ActivityPayload{

	@NotBlank(message = ValidationConstants.NAME_REQUIRED)
	@Size(max = 100, message = ValidationConstants.NAME_MAX_LENGTH)
	private String name;

	@NotBlank(message = ValidationConstants.EMAIL_REQUIRED)
	@Email(message = ValidationConstants.INVALID_EMAIL)
	@Size(max = 150, message = ValidationConstants.EMAIL_MAX_LENGTH)
	private String email;

	@Size(max = 20, message = ValidationConstants.PHONE_MAX_LENGTH)
	private String phone;

	@NotBlank(message = ValidationConstants.CITY_REQUIRED)
	@Size(max = 100, message = ValidationConstants.CITY_MAX_LENGTH)
	private String city;

	@NotNull(message = ValidationConstants.VISIT_DATE_REQUIRED)
	@FutureOrPresent(message = ValidationConstants.VISIT_DATE_FUTURE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate visitDate;

	@NotNull(message = ValidationConstants.VISIT_TIME_REQUIRED)
	private LocalTime visitTime;

}

package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class NewsRequest {

    @NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.PREVIEW_CONTENT_REQUIRED)
    @Size(max = 500, message = ValidationConstants.PREVIEW_CONTENT_MAX_LENGTH)
    private String previewContent;

    @NotBlank(message = ValidationConstants.DETAILED_CONTENT_REQUIRED)
    private String detailedContent;

    @NotBlank(message = ValidationConstants.AUTHOR_REQUIRED)
    private String authorName;

    @NotNull(message = ValidationConstants.THUMBNAIL_FILE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile thumbnailFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    private String thumbnailAltText;

    @NotNull(message = ValidationConstants.COVER_IMAGE_FILE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile coverImageFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    private String coverImageAltText;

    @Builder.Default
    @Size(max = 10, message = "A maximum of 10 related media files is allowed.")
    private List<MultipartFile> relatedMediaFiles = new ArrayList<>();

    @NotNull(message = ValidationConstants.PUBLISH_DATE_REQUIRED)
    private LocalDate publishDate;

    //  Category ID is now required and must be a valid UUID
//    @NotBlank(message = ValidationConstants.CATEGORY_ID_REQUIRED)
//    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
//    private String categoryId;

    @Builder.Default
    private Boolean isActive = true;

    @Builder.Default
    private Boolean isFeaturedNews = false;

    @Valid
    private SeoConfigRequest seoConfigRequest;
}

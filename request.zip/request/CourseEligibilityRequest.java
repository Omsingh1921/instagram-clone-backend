package com.renaissance.app.dto.request;

import java.util.List;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class CourseEligibilityRequest {

    @NotBlank(message = ValidationConstants.ELIGIBILITY_TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.ELIGIBILITY_TITLE_MAX_LENGTH)
    private String eligibilityTitle;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    @Size(max = 2000, message = ValidationConstants.DESCRIPTION_LENGTH_2000)
    private String description;

    @Valid
    @NotNull(message = ValidationConstants.ELIGIBILITY_ITEMS_REQUIRED)
    @Size(min = 1, message = ValidationConstants.ELIGIBILITY_ITEMS_MIN)
    private List<EligibilityItemsRequest> items;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TrimValidator
public class PermissionRequest {

    @NotBlank(message = ValidationConstants.RESOURCE_REQUIRED)
    @Pattern(
        regexp = "^[a-z]+$",
        message = "Resource must be lowercase letters only (e.g. users, roles)"
    )
    private String resource;

    @NotBlank(message = ValidationConstants.ACTION_REQUIRED)
    @Pattern(
        regexp = "^[a-z]+$",
        message = "Action must be lowercase letters only (e.g. read, create)"
    )
    private String action;
}

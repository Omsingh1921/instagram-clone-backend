package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventGuestUpdateRequest {

    private String name;

    @Size(max = 100, message = ValidationConstants.DESIGNATION_MAX_LENGTH)
    private String designation;

    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile profilePhotoFile;
}

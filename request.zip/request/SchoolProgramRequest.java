package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TrimValidator
public class SchoolProgramRequest {

	@NotBlank(message = ValidationConstants.NAME_REQUIRED)
	@Size(max = 200, message = ValidationConstants.NAME_MAX_LENGTH)
	private String name;

	@NotBlank(message = "Endpoint is required")
	@Size(max = 200, message = "Endpoint must be at most 200 characters")
	private String endpoint; // NEW FIELD: unique program slug

	@Size(max = 500, message = ValidationConstants.SHORT_DESCRIPTION_MAX_LENGTH)
	private String shortDescription;

	// boolean isActive
	private Boolean isActive;

	@ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
	private MultipartFile icon;
	@NotNull(message = "icon-alt-text is required")
	private String iconAltText;

	@Valid
	@NotNull(message = "Promo section required")
	private PromoSectionRequest promoSection;

	@Valid
	@NotNull(message = "Unique selling point is required")
	private UniqueSellingPointRequest uniqueSellingPoint;

	@Valid
	@NotNull(message = "Seo configuration required")
	private SeoConfigRequest seoConfigRequest;
}

package com.renaissance.app.dto.request;

import java.time.LocalDate;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class AdminManualRegistrationRequest {

    // -------- PERSONAL --------
    @NotBlank(message = ValidationConstants.FULL_NAME_REQUIRED)
    private String fullName;

    @NotNull(message = ValidationConstants.DOB_REQUIRED)
    private LocalDate dob;
    

    @NotNull(message = "Counsellor required")
    private String counselledBy;

    @NotBlank(message = ValidationConstants.GENDER_REQUIRED)
//    @Pattern(
//            regexp = "MALE|FEMALE|OTHER",
//            message = ValidationConstants.GENDER_INVALID
//        )
    private String gender;

    @Email(message = ValidationConstants.INVALID_EMAIL)
    @NotBlank(message = ValidationConstants.REQUIRED)
    private String email;

    @NotBlank(message = ValidationConstants.CONTACT_REQUIRED)
    private String contactNumber;

    private String whatsappNumber;
    private String fatherName;
    private String motherName;
    private String parentsContactNumber;
    private String categoryCaste;

    // -------- PROGRAM --------
    @NotBlank(message = ValidationConstants.PROGRAM_REQUIRED)
    private String programId;

    @NotBlank(message = ValidationConstants.COURSE_REQUIRED)
    private String courseId;

    // -------- ADDRESS --------
    @NotBlank(message = ValidationConstants.COUNTRY_REQUIRED)
    private String country;

    @NotBlank(message = ValidationConstants.STATE_REQUIRED)
    private String state;

    @NotBlank(message = ValidationConstants.CITY_REQUIRED)
    private String city;

    @NotBlank(message = ValidationConstants.PINCODE_REQUIRED)
    private String pincode;

    // -------- EDUCATION --------
    @NotBlank(message = ValidationConstants.EDU_STATUS_REQUIRED)
    private String eduStatus;

    private String recentEducation;
    private String board;
    private Integer passingYear;

    @NotBlank(message = ValidationConstants.SCHOOL_REQUIRED)
    private String schoolOrCollegeName;

    // -------- PAYMENT --------
//    private boolean markPaymentSuccess;
//    private Double amountPaid;
}

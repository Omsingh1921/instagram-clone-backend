package com.renaissance.app.dto.request;


import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PromoSectionUpdateRequest {

    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @Size(max = 2000, message = ValidationConstants.DESCRIPTION_LENGTH_2000)
    private String description;

    private MultipartFile mediaFile; // Optional new upload

    private Boolean removeExistingMedia; // True if existing media should be deleted

    @Size(max = 300, message = "Alt text must be at most 300 characters.")
    private String mediaAltText; // NEW FIELD: accessibility alt text
}

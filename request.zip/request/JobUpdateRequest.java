package com.renaissance.app.dto.request;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.model.enums.ExperienceLevel;
import com.renaissance.app.model.enums.JobType;
import com.renaissance.app.model.enums.SalaryPeriod;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class JobUpdateRequest {

    private String jobName;

    private String description;

    private ExperienceLevel experienceLevel;

    private JobType jobType;

    @Positive(message = ValidationConstants.SALARY_AMOUNT_POSITIVE)
    private Double salaryAmount;

    private SalaryPeriod salaryPeriod;

    private Boolean isActive;

    private List<String> courseIds;

    private MultipartFile logoFile;
}

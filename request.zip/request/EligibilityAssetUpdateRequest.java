package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EligibilityAssetUpdateRequest {

    /**
     * ID of the existing asset to update.
     * If null, a new asset will be created.
     */
    private String assetId;

    /**
     * Optional title for the asset.
     */
    @Size(max = 200, message = "Asset title must be at most 200 characters.")
    private String assetTitle;

    /**
     * Optional description for the asset.
     */
    @Size(max = 500, message = "Asset description must be at most 500 characters.")
    private String assetDescription;

    /**
     * Optional new media file to upload or replace existing one.
     */
    private MultipartFile mediaFile;
}

package com.renaissance.app.dto.request;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FaqRequest {

    @NotBlank(message = ValidationConstants.FAQ_QUESTION_REQUIRED)
    @Size(max = 300, message = ValidationConstants.FAQ_QUESTION_MAX_LENGTH)
    private String question;

    @NotBlank(message = ValidationConstants.FAQ_ANSWER_REQUIRED)
    private String answer;
}

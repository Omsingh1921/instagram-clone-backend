package com.renaissance.app.dto.request;

import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.annotations.UUIDValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@TrimValidator
public class UpdatePolicyDocumentRequest {

    @NotBlank(message = ValidationConstants.POLICY_DOCUMENT_ID_REQUIRED)
    @UUIDValidator(message = ValidationConstants.INVALID_UUID)
    private String id;

    @NotBlank(message = ValidationConstants.DOCUMENT_CONTENT_REQUIRED)
    private String content; // replaces title + description + image
}

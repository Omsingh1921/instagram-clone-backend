package com.renaissance.app.dto.request;

import com.renaissance.app.service.ActivityPayload;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GrievanceRequestJson implements ActivityPayload {
    private String name;
    private String email;
    private String phone;
    private String message;
}

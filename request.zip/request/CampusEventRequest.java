package com.renaissance.app.dto.request;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CampusEventRequest {
	@NotBlank(message = ValidationConstants.TITLE_REQUIRED)
    @Size(max = 200, message = ValidationConstants.TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.DESCRIPTION_REQUIRED)
    @Size(max = 1000, message = ValidationConstants.DESCRIPTION_MAX_LENGTH)
    private String description;

    private List<MultipartFile> mediaFiles; // optional uploaded media

    @NotNull(message = ValidationConstants.EVENT_DATE_REQUIRED)
    private LocalDate eventDate;

    private LocalTime eventTime;

    private String categoryId;    // optional if categoryName provided
    @Size(max = 100, message = ValidationConstants.CATEGORY_NAME_MAX_LENGTH)
    private String categoryName;
}

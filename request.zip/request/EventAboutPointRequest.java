package com.renaissance.app.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventAboutPointRequest {

    @NotBlank(message = "Point content is required")
    private String content;

    @NotNull(message = "Display order is required")
    private Integer displayOrder;
}

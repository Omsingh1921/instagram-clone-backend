package com.renaissance.app.dto.request;

import org.springframework.web.multipart.MultipartFile;

import com.renaissance.app.util.annotations.ImageValidator;
import com.renaissance.app.util.annotations.TrimValidator;
import com.renaissance.app.util.constants.ValidationConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TrimValidator
public class BlogRequest {

    @NotBlank(message = ValidationConstants.BLOG_TITLE_REQUIRED)
    @Size(max = 150, message = ValidationConstants.BLOG_TITLE_MAX_LENGTH)
    private String title;

    @NotBlank(message = ValidationConstants.BLOG_PREVIEW_REQUIRED)
    @Size(max = 500, message = ValidationConstants.BLOG_PREVIEW_MAX_LENGTH)
    private String shortDescription; // short snippet

    @NotBlank(message = ValidationConstants.BLOG_DETAIL_REQUIRED)
    private String detailedContent; // full description

    @NotBlank(message = ValidationConstants.BLOG_AUTHOR_REQUIRED)
    @Size(max = 100, message = ValidationConstants.BLOG_AUTHOR_MAX_LENGTH)
    private String authorName;
    
    @Size(max = 2000, message = ValidationConstants.AUTHOR_BIO_MAX_LENGTH)
    private String authorBio;

    @NotNull(message = ValidationConstants.AUTHOR_IMAGE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile authorImageFile;



    private Boolean isActive; // optional — defaults to true if not provided

    @Valid
    @NotNull(message = ValidationConstants.SEO_CONFIG_REQUIRED)
    private SeoConfigRequest seoConfigRequest;
    
    // --- THUMBNAIL ---
    @NotNull(message = ValidationConstants.THUMBNAIL_FILE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile thumbnailFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    @Size(max = 150, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String thumbnailAltText;

    // --- COVER IMAGE ---
    @NotNull(message = ValidationConstants.COVER_IMAGE_FILE_REQUIRED)
    @ImageValidator(message = ValidationConstants.INSUPPORTED_MEDIA_TYPE)
    private MultipartFile coverImageFile;

    @NotBlank(message = ValidationConstants.ALT_TEXT_REQUIRED)
    @Size(max = 150, message = ValidationConstants.ALT_TEXT_MAX_LENGTH)
    private String coverImageAltText;
}
